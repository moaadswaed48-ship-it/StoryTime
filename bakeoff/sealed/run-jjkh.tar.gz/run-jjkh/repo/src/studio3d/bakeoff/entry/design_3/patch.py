"""Design 3: a small patch of the garden under the film's evening light, for the design stills.

Stand-in set only (the film's set belongs to the film builder): grass, a soft dark hedge, a dusk sky, a low golden
sun from the left and a peach rim from behind.
"""
import math

import bpy
import numpy as np
from mathutils import Vector

import hh_geom as g


def _mat_attr(name, rough=0.55, glow=0.0, spec=0.3):
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    nt = m.node_tree
    b = nt.nodes['Principled BSDF']
    at = nt.nodes.new('ShaderNodeAttribute')
    at.attribute_name = 'col'
    nt.links.new(at.outputs['Color'], b.inputs['Base Color'])
    b.inputs['Roughness'].default_value = rough
    b.inputs['Specular IOR Level'].default_value = spec
    if glow > 0:
        tr = nt.nodes.new('ShaderNodeBsdfTranslucent')
        nt.links.new(at.outputs['Color'], tr.inputs['Color'])
        mx = nt.nodes.new('ShaderNodeMixShader')
        mx.inputs['Fac'].default_value = glow
        nt.links.new(b.outputs[0], mx.inputs[1])
        nt.links.new(tr.outputs[0], mx.inputs[2])
        nt.links.new(mx.outputs[0], nt.nodes['Material Output'].inputs['Surface'])
    return m


def _mesh(name, verts, faces, mat, col=None):
    me = bpy.data.meshes.new(name)
    me.from_pydata(np.asarray(verts, dtype=np.float64).tolist(), [], faces.tolist() if hasattr(faces, 'tolist') else faces)
    me.update()
    me.shade_smooth()
    if col is not None:
        a = me.attributes.new('col', 'FLOAT_COLOR', 'POINT')
        a.data.foreach_set('color', np.asarray(col, dtype=np.float32).ravel())
    me.materials.append(mat)
    o = bpy.data.objects.new(name, me)
    bpy.context.scene.collection.objects.link(o)
    return o


def grass(n_near=11000, n_far=16000, clear=0.105, seed=21):
    """Blades as one mesh. Short inside `clear` (the character stands there), taller around, sparser far away."""
    rng = np.random.default_rng(seed)
    r1 = np.sqrt(rng.random(n_near)) * 0.55
    r2 = 0.5 + np.sqrt(rng.random(n_far)) * 2.3
    r = np.concatenate([r1, r2])
    a = rng.uniform(0, 2 * math.pi, len(r))
    x, y = r * np.cos(a), r * np.sin(a)
    n = len(r)
    h = rng.uniform(0.022, 0.050, n) * (1 + 0.5 * smooth(0.5, 2.0, r))
    h = np.where(r < clear, rng.uniform(0.008, 0.016, n), h)
    h = np.where((r >= clear) & (r < clear + 0.05), h * 0.6, h)
    w = rng.uniform(0.0028, 0.0046, n) * (1 + 1.6 * smooth(0.5, 2.0, r))
    face = rng.uniform(0, 2 * math.pi, n)
    lean_dir = rng.uniform(0, 2 * math.pi, n)
    lean = rng.uniform(0.05, 0.55, n)
    ts = np.array([0.0, 0.38, 0.72, 1.0])
    wf = np.array([1.0, 0.85, 0.55, 0.06])
    verts = np.zeros((n, 4, 2, 3))
    for i, (t, wk) in enumerate(zip(ts, wf)):
        cx = x + np.cos(lean_dir) * lean * h * t * t
        cy = y + np.sin(lean_dir) * lean * h * t * t
        cz = h * t * (1 - 0.25 * lean * t)
        dx, dy = np.cos(face) * w * wk * 0.5, np.sin(face) * w * wk * 0.5
        verts[:, i, 0] = np.stack([cx - dx, cy - dy, cz], 1)
        verts[:, i, 1] = np.stack([cx + dx, cy + dy, cz], 1)
    base = np.arange(n)[:, None] * 8
    quads = np.concatenate([base + np.array([2 * i, 2 * i + 1, 2 * i + 3, 2 * i + 2])[None, :] for i in range(3)])
    tone = rng.random(n)
    c0, c1, c2 = g.lin('#3f6a1f'), g.lin('#7fa236'), g.lin('#b9b657')
    tip = np.where(tone[:, None] < 0.75, c1 + (c2 - c1) * (tone[:, None] / 0.75) * 0.5, c2)
    col = np.zeros((n, 4, 2, 4))
    for i, t in enumerate(ts):
        cc = g.lin('#26401a') * (1 - t) ** 2 + (c0 * (1 - t) + tip * t) * (1 - (1 - t) ** 2)
        col[:, i, :, :3] = cc[:, None, :]
    col[..., 3] = 1
    return _mesh('Patch.grass', verts.reshape(-1, 3), quads, _mat_attr('Patch.grass', 0.5, glow=0.38), col.reshape(-1, 4))


def smooth(a, b, x):
    return g.smoothstep(a, b, x)


def build_patch(seed=21):
    sc = bpy.context.scene
    # ground
    m = bpy.data.materials.new('Patch.ground')
    m.use_nodes = True
    nt = m.node_tree
    b = nt.nodes['Principled BSDF']
    nz = nt.nodes.new('ShaderNodeTexNoise')
    nz.inputs['Scale'].default_value = 9.0
    nz.inputs['Detail'].default_value = 5.0
    ramp = nt.nodes.new('ShaderNodeValToRGB')
    ramp.color_ramp.elements[0].position = 0.3
    ramp.color_ramp.elements[0].color = (*g.lin('#2c3a17'), 1)
    ramp.color_ramp.elements[1].position = 0.7
    ramp.color_ramp.elements[1].color = (*g.lin('#4f5e25'), 1)
    nt.links.new(nz.outputs['Fac'], ramp.inputs['Fac'])
    nt.links.new(ramp.outputs['Color'], b.inputs['Base Color'])
    b.inputs['Roughness'].default_value = 0.9
    s = 14.0
    _mesh('Patch.ground', [(-s, -s, 0), (s, -s, 0), (s, s, 0), (-s, s, 0)], [(0, 1, 2, 3)], m)
    grass(seed=seed)
    # a soft dark hedge far behind, only ever seen out of focus
    rng = np.random.default_rng(seed + 1)
    hm = bpy.data.materials.new('Patch.hedge')
    hm.use_nodes = True
    hb = hm.node_tree.nodes['Principled BSDF']
    hn = hm.node_tree.nodes.new('ShaderNodeTexNoise')
    hn.inputs['Scale'].default_value = 5.0
    hr = hm.node_tree.nodes.new('ShaderNodeValToRGB')
    hr.color_ramp.elements[0].color = (*g.lin('#1c2f18'), 1)
    hr.color_ramp.elements[1].color = (*g.lin('#4d6a2a'), 1)
    hm.node_tree.links.new(hn.outputs['Fac'], hr.inputs['Fac'])
    hm.node_tree.links.new(hr.outputs['Color'], hb.inputs['Base Color'])
    hb.inputs['Roughness'].default_value = 0.8
    for i in range(11):
        v, f = g.ellipsoid_mesh(rng.uniform(0.6, 1.1), rng.uniform(0.5, 0.8), rng.uniform(0.55, 1.0), 20, 10)
        o = _mesh('Patch.hedge%d' % i, v, f, hm)
        ang = math.radians(-70 + 140 * i / 10 + rng.uniform(-5, 5))
        rr = rng.uniform(3.2, 4.4)
        o.location = (rr * math.sin(ang), rr * math.cos(ang), rng.uniform(0.1, 0.35))
    return sc


def evening_light(sun_dir=(-0.86, -0.36, 0.17), sun=5.2, rim=2.6, sky=0.15):
    """Dusk: the last low golden sun from the left, a cool sky filling the shadows, a peach rim from behind.
    sun_dir points from the scene toward the sun."""
    sc = bpy.context.scene
    w = bpy.data.worlds.new('Dusk')
    w.use_nodes = True
    nt = w.node_tree
    bg = nt.nodes['Background']
    skyt = nt.nodes.new('ShaderNodeTexSky')
    skyt.sky_type = 'MULTIPLE_SCATTERING'
    skyt.sun_disc = False
    d = g.unit(np.array(sun_dir))
    skyt.sun_elevation = math.asin(d[2])
    skyt.sun_rotation = math.atan2(d[0], d[1]) % (2 * math.pi)
    skyt.aerosol_density = 1.6
    nt.links.new(skyt.outputs['Color'], bg.inputs['Color'])
    bg.inputs['Strength'].default_value = sky
    # what the lens sees: a painted dusk gradient, peach at the horizon to dusty blue above
    geo = nt.nodes.new('ShaderNodeNewGeometry')
    sep = nt.nodes.new('ShaderNodeSeparateXYZ')
    nt.links.new(geo.outputs['Incoming'], sep.inputs[0])
    neg = nt.nodes.new('ShaderNodeMath')
    neg.operation = 'MULTIPLY'
    neg.inputs[1].default_value = -1.0
    nt.links.new(sep.outputs['Z'], neg.inputs[0])
    ramp = nt.nodes.new('ShaderNodeValToRGB')
    e = ramp.color_ramp.elements
    e[0].position, e[0].color = 0.0, (*g.lin('#ffd09a'), 1)
    e[1].position, e[1].color = 0.55, (*g.lin('#4d6aa8'), 1)
    for pos, col in ((0.07, '#f7b592'), (0.18, '#c59bb8'), (0.32, '#7f8cc0')):
        el = ramp.color_ramp.elements.new(pos)
        el.color = (*g.lin(col), 1)
    nt.links.new(neg.outputs[0], ramp.inputs['Fac'])
    bg2 = nt.nodes.new('ShaderNodeBackground')
    bg2.inputs['Strength'].default_value = 0.85
    nt.links.new(ramp.outputs['Color'], bg2.inputs['Color'])
    lp = nt.nodes.new('ShaderNodeLightPath')
    mix = nt.nodes.new('ShaderNodeMixShader')
    nt.links.new(lp.outputs['Is Camera Ray'], mix.inputs['Fac'])
    nt.links.new(bg.outputs[0], mix.inputs[1])
    nt.links.new(bg2.outputs[0], mix.inputs[2])
    nt.links.new(mix.outputs[0], nt.nodes['World Output'].inputs['Surface'])
    sc.world = w

    def sun_lamp(name, direction, energy, colour, angle):
        ld = bpy.data.lights.new(name, 'SUN')
        ld.energy = energy
        ld.angle = math.radians(angle)
        ld.color = tuple(g.lin(colour))
        o = bpy.data.objects.new(name, ld)
        sc.collection.objects.link(o)
        o.rotation_euler = (-Vector(tuple(g.unit(np.array(direction))))).to_track_quat('-Z', 'Y').to_euler()
        return o
    key = sun_lamp('Dusk.sun', sun_dir, sun, '#ffa257', 3.0)
    back = sun_lamp('Dusk.rim', (0.55, 0.78, 0.30), rim, '#ffc9a6', 6.0)
    return key, back


def render_settings(samples=24, res=(1280, 720)):
    sc = bpy.context.scene
    c = sc.cycles
    sc.render.engine = 'CYCLES'
    c.device = 'CPU'
    c.samples = samples
    c.use_adaptive_sampling = True
    c.adaptive_threshold = 0.02
    c.use_denoising = True
    c.denoiser = 'OPENIMAGEDENOISE'
    c.denoising_quality = 'BALANCED'
    c.max_bounces = 6
    c.diffuse_bounces = 3
    c.glossy_bounces = 2
    c.transmission_bounces = 4
    c.transparent_max_bounces = 8
    c.caustics_reflective = False
    c.caustics_refractive = False
    c.sample_clamp_indirect = 6.0
    sc.cycles_curves.shape = 'RIBBONS'
    sc.render.use_persistent_data = True
    sc.render.resolution_x, sc.render.resolution_y = res
    sc.render.resolution_percentage = 100
    sc.view_settings.view_transform = 'AgX'
    sc.view_settings.look = 'AgX - Punchy'
    sc.view_settings.exposure = 0.45
    sc.render.image_settings.file_format = 'PNG'
    sc.render.image_settings.color_mode = 'RGB'
    sc.render.film_transparent = False


def camera(name, loc, target, lens, fstop, focus_point):
    cam = bpy.data.cameras.new(name)
    cam.lens = lens
    cam.sensor_width = 36
    cam.dof.use_dof = True
    cam.dof.aperture_fstop = fstop
    co = bpy.data.objects.new(name, cam)
    bpy.context.scene.collection.objects.link(co)
    co.location = loc
    co.rotation_euler = (Vector(target) - Vector(loc)).to_track_quat('-Z', 'Y').to_euler()
    cam.dof.focus_distance = (Vector(focus_point) - Vector(loc)).length
    cam.clip_start = 0.01
    return co
