"""Little Hedgehog and Mama Hedgehog: builds a character into the current Blender scene (Blender 5.2, Cycles).

Grown from design 3 of the bake-off (the one both judges chose), with what the judges asked for: dark eyes with a
real reflected catchlight (no painted sparkle, nothing emissive), eyes seated deeper, a hood of thick banded quills
around a pale face, a white chest, a closed soft smile, tiny paws with toes on furry arms, a bigger wet nose, a
cowlick on its own pivot (Little only), a sleeping curl and a tight ball pose.

    import hedgehog
    rig = hedgehog.build_hedgehog('little')            # or 'mama'
    rig.place((x, y, z), yaw=90)                       # the ground point under the body
    rig.pose(**hedgehog.POSES['sit_giggle'])           # a whole pose (no scene update is needed: all maths is here)
    rig.look_at(world_point)                           # eyes
    rig.key(frame)                                     # keyframe every control at that frame

The character is a puppet of rigid furry pieces (no skinning, no shape keys), so fur never has to follow a deforming
skin and a frame never depends on the one before it. "L" is the character's side at -X, "R" is +X; he faces -Y.
"""
import math
import os
import sys

import bpy
import numpy as np
from mathutils import Euler, Matrix, Quaternion, Vector

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)
import hh_geom as g  # noqa: E402
import kit  # noqa: E402

RAD = math.radians


def _flat(c, n):
    return g.rgba(np.repeat(np.asarray(c)[None, :], n, 0))


# ------------------------------------------------------------------------------------------------ materials
def mat_skin(name, sss=0.0, sheen=0.4, rough=0.6, coat=0.0):
    """Bare skin, or the skin under fur: colour comes from the 'col' attribute of the mesh."""
    return kit.principled(name, attr='col', rough=rough, spec=0.3, sheen=sheen, coat=coat, coat_rough=0.15, sss=sss)


def mat_fur(name, glow=0.32):
    """Soft fur on thin strands: a matte, slightly velvety surface with light coming through the edges.
    Cheap on purpose (no hair shader): see TECH-NOTES rows 14 and 33."""
    m, nt, b, out = kit.new_mat(name)
    at = nt.nodes.new('ShaderNodeAttribute')
    at.attribute_name = 'col'
    hi = nt.nodes.new('ShaderNodeHairInfo')
    mr = nt.nodes.new('ShaderNodeMapRange')
    mr.inputs['To Min'].default_value = 0.78
    mr.inputs['To Max'].default_value = 1.22
    nt.links.new(hi.outputs['Intercept'], mr.inputs['Value'])
    sc = nt.nodes.new('ShaderNodeVectorMath')
    sc.operation = 'SCALE'
    nt.links.new(at.outputs['Color'], sc.inputs[0])
    nt.links.new(mr.outputs['Result'], sc.inputs['Scale'])
    nt.links.new(sc.outputs['Vector'], b.inputs['Base Color'])
    b.inputs['Roughness'].default_value = 0.72
    b.inputs['Sheen Weight'].default_value = 0.35
    b.inputs['Sheen Roughness'].default_value = 0.4
    b.inputs['Specular IOR Level'].default_value = 0.15
    tr = nt.nodes.new('ShaderNodeBsdfTranslucent')
    nt.links.new(sc.outputs['Vector'], tr.inputs['Color'])
    mx = nt.nodes.new('ShaderNodeMixShader')
    mx.inputs['Fac'].default_value = glow
    nt.links.new(b.outputs[0], mx.inputs[1])
    nt.links.new(tr.outputs[0], mx.inputs[2])
    nt.links.new(mx.outputs[0], out.inputs['Surface'])
    return m


def mat_spines(name, colour, glow=0.24):
    """Banded quills (the idea of design 2): cream root, a brown band, a pale tip that lets low sun through."""
    m, nt, b, out = kit.new_mat(name)
    c = g.lin(colour)
    cream = g.lin('#f3e3c0')
    hi = nt.nodes.new('ShaderNodeHairInfo')
    at = nt.nodes.new('ShaderNodeAttribute')
    at.attribute_type = 'GEOMETRY'
    at.attribute_name = 'rnd'
    sh = nt.nodes.new('ShaderNodeMath')
    sh.operation = 'MULTIPLY_ADD'
    sh.inputs[1].default_value = 0.12
    sh.inputs[2].default_value = -0.06
    nt.links.new(at.outputs['Fac'], sh.inputs[0])
    ad = nt.nodes.new('ShaderNodeMath')
    ad.operation = 'ADD'
    nt.links.new(hi.outputs['Intercept'], ad.inputs[0])
    nt.links.new(sh.outputs[0], ad.inputs[1])
    band = kit.ramp(nt, [(0.0, c * 0.55 + cream * 0.30), (0.26, c * 0.55 + cream * 0.35), (0.40, c * 0.55),
                         (0.70, c * 0.66), (0.84, cream * 0.96), (1.0, cream)])
    nt.links.new(ad.outputs[0], band.inputs['Fac'])
    val = nt.nodes.new('ShaderNodeMath')
    val.operation = 'MULTIPLY_ADD'
    val.inputs[1].default_value = 0.36
    val.inputs[2].default_value = 0.82
    nt.links.new(at.outputs['Fac'], val.inputs[0])
    hsv = nt.nodes.new('ShaderNodeHueSaturation')
    nt.links.new(band.outputs['Color'], hsv.inputs['Color'])
    nt.links.new(val.outputs[0], hsv.inputs['Value'])
    nt.links.new(hsv.outputs['Color'], b.inputs['Base Color'])
    b.inputs['Roughness'].default_value = 0.40
    b.inputs['Specular IOR Level'].default_value = 0.45
    tr = nt.nodes.new('ShaderNodeBsdfTranslucent')
    tint = nt.nodes.new('ShaderNodeMixRGB')
    tint.blend_type = 'MULTIPLY'
    tint.inputs['Fac'].default_value = 1.0
    tint.inputs['Color2'].default_value = (1.0, 0.82, 0.56, 1)
    nt.links.new(hsv.outputs['Color'], tint.inputs['Color1'])
    nt.links.new(tint.outputs['Color'], tr.inputs['Color'])
    mx = nt.nodes.new('ShaderNodeMixShader')
    mx.inputs['Fac'].default_value = glow
    nt.links.new(b.outputs[0], mx.inputs[1])
    nt.links.new(tr.outputs[0], mx.inputs[2])
    nt.links.new(mx.outputs[0], out.inputs['Surface'])
    return m


def mat_eye(name, iris_in='#24140b', iris_out='#352010', dark='#120a08', glow='#4a2e18'):
    """A big dark, wet eye. The whole eyeball is dark brown (no white can show from any angle); a warm brown iris
    with a black round pupil is drawn around the eyeball's own -Y axis, so turning the eyeball moves the gaze.
    Nothing here gives off light: the sparkle is the reflection of kit.eye_light()."""
    m, nt, b, out = kit.new_mat(name)
    Lk = nt.links.new
    tc = nt.nodes.new('ShaderNodeTexCoord')
    nrm = nt.nodes.new('ShaderNodeVectorMath')
    nrm.operation = 'NORMALIZE'
    Lk(tc.outputs['Object'], nrm.inputs[0])
    dot = nt.nodes.new('ShaderNodeVectorMath')
    dot.operation = 'DOT_PRODUCT'
    Lk(nrm.outputs['Vector'], dot.inputs[0])
    dot.inputs[1].default_value = (0, -1, 0)
    t = nt.nodes.new('ShaderNodeMapRange')
    t.clamp = True
    Lk(dot.outputs['Value'], t.inputs['Value'])
    t.inputs['From Min'].default_value = 0.55
    t.inputs['From Max'].default_value = 1.0
    # the pupil is wide (about 36 degrees of the eyeball) and the iris around it is a narrow dark-brown ring: from
    # the side the eye stays one dark, wet bead and never a slit in a bright ring
    r = kit.ramp(nt, [(0.0, dark), (0.30, dark), (0.36, '#1d100a'), (0.44, iris_in), (0.54, iris_out),
                      (0.585, '#050303'), (1.0, '#050303')])
    Lk(t.outputs['Result'], r.inputs['Fac'])
    # the lower half of the iris is a little warmer, as if lit through the cornea from above
    mask = kit.ramp(nt, [(0.36, (0, 0, 0)), (0.43, (1, 1, 1)), (0.53, (1, 1, 1)), (0.585, (0, 0, 0))])
    Lk(t.outputs['Result'], mask.inputs['Fac'])
    sep = nt.nodes.new('ShaderNodeSeparateXYZ')
    Lk(nrm.outputs['Vector'], sep.inputs[0])
    low = nt.nodes.new('ShaderNodeMapRange')
    low.clamp = True
    Lk(sep.outputs['Z'], low.inputs['Value'])
    low.inputs['From Min'].default_value = 0.15
    low.inputs['From Max'].default_value = -0.5
    low.inputs['To Min'].default_value = 0.0
    low.inputs['To Max'].default_value = 0.16
    f = nt.nodes.new('ShaderNodeMath')
    f.operation = 'MULTIPLY'
    Lk(mask.outputs['Color'], f.inputs[0])
    Lk(low.outputs['Result'], f.inputs[1])
    base = nt.nodes.new('ShaderNodeMixRGB')
    Lk(f.outputs[0], base.inputs['Fac'])
    Lk(r.outputs['Color'], base.inputs['Color1'])
    base.inputs['Color2'].default_value = kit.lin4(glow)
    Lk(base.outputs['Color'], b.inputs['Base Color'])
    b.inputs['Roughness'].default_value = 0.07
    b.inputs['Specular IOR Level'].default_value = 0.6
    b.inputs['Coat Weight'].default_value = 0.0
    return m


def mat_nose(name):
    """A wet little nose: dark, smooth, with a clear coat that takes one soft highlight from the eye light."""
    m, nt, b, out = kit.new_mat(name)
    b.inputs['Base Color'].default_value = kit.lin4('#2c1b19')
    b.inputs['Roughness'].default_value = 0.30
    b.inputs['Specular IOR Level'].default_value = 0.5
    b.inputs['Coat Weight'].default_value = 0.5
    b.inputs['Coat Roughness'].default_value = 0.12
    return m


# ------------------------------------------------------------------------------------------------ poses
# Paws are given in the root's space (metres at size 1; z = 0 is the ground) as (x, y, z) or (x, y, z, rx, ry, rz) in
# degrees, or as a 4x4 Matrix. Lids are the elevation of the lid margin in degrees: 0 is the middle of the eye; a
# wide-open eye is about up 52 / lo -50 (the dark lash line of the upper lid just shows along the top of the eye);
# a sleeping eye is up -3 / lo -7 (the lash line is a soft downward arc across the eye); a laughing eye is up 13 /
# lo 15 (the lower lid pushed up: an upward arc).
STAND_PAWS = dict(FL=(-0.024, -0.048, 0.0040), FR=(0.024, -0.048, 0.0040),
                  HL=(-0.031, 0.030, 0.0050, 0, 0, -14), HR=(0.031, 0.030, 0.0050, 0, 0, 14))
SIT_HIND = dict(HL=(-0.031, -0.004, 0.0050, 0, 0, -28), HR=(0.031, -0.004, 0.0050, 0, 0, 28))
POSES = {
    # on all fours, relaxed
    'stand': dict(pitch=6, clear=0.006, head=(4, 0, 0), slide=(0, -0.016, -0.016), jaw=0, lid_up=52, lid_lo=-50,
                  lid_tilt=4, paws=dict(STAND_PAWS)),
    # sitting up, front paws by the cheeks, laughing: who he is
    'sit_giggle': dict(pitch=52, clear=-0.002, head=(6, 10, 9), slide=(0, -0.012, 0.010), jaw=15, lid_up=20,
                       lid_lo=6, lid_tilt=9, ears=(10, 10),
                       paws=dict(FL=(-0.017, -0.026, 0.088, -80, 0, 200), FR=(0.028, -0.019, 0.085, -80, 0, 160),
                                 **SIT_HIND)),
    # sitting up, paws held together at the chest, wide curious eyes
    'sit_curious': dict(pitch=50, clear=-0.002, head=(-3, 8, -7), slide=(0, -0.012, 0.010), jaw=0, lid_up=52,
                        lid_lo=-46, lid_tilt=5, ears=(-8, -8),
                        paws=dict(FL=(-0.011, -0.029, 0.064, 35, 0, -10), FR=(0.010, -0.029, 0.066, 35, 0, 10),
                                  **SIT_HIND)),
    # on all fours, nose lifted, eyes closed in happy arcs: sniffing the evening air
    'sniff': dict(pitch=13, clear=0.006, head=(34, 0, 0), slide=(0, -0.021, -0.006), jaw=0, lid_up=13, lid_lo=15,
                  lid_tilt=4, ears=(-6, -6), nose=1.1,
                  paws=dict(FL=(-0.024, -0.052, 0.0040), FR=(0.024, -0.047, 0.0040),
                            HL=(-0.031, 0.030, 0.0050, 0, 0, -14), HR=(0.031, 0.034, 0.0050, 0, 0, 14))),
    # lying down, chin on the paws, asleep: the cosy curl of the last picture
    'sleep': dict(pitch=1, clear=0.0, squash=(1.07, 0.93, 0.97), head=(-10, 0, 0), slide=(0, -0.012, -0.027), jaw=0,
                  lid_up=-3, lid_lo=-7, lid_tilt=4, ears=(14, 14),
                  paws=dict(FL=(-0.015, -0.072, 0.0040, 0, 0, 12), FR=(0.015, -0.072, 0.0040, 0, 0, -12),
                            HL=(-0.036, 0.016, 0.0050, 0, 0, -40), HR=(0.036, 0.016, 0.0050, 0, 0, 40))),
    # a tight ball: nose tucked under, paws hidden, only quills outside
    'ball': dict(pitch=-22, clear=0.0, squash=(1.04, 0.88, 1.10), head=(-58, 0, 0), slide=(0, 0.006, -0.030), jaw=0,
                 lid_up=-12, lid_lo=-16, ears=(16, 16),
                 paws=dict(FL=(-0.012, -0.022, 0.0040), FR=(0.012, -0.022, 0.0040),
                           HL=(-0.020, 0.012, 0.0050), HR=(0.020, 0.012, 0.0050))),
}
DEFAULTS = dict(pitch=6.0, clear=0.006, head=(0.0, 0.0, 0.0), slide=(0.0, -0.016, -0.016), jaw=0.0, lid_up=52.0,
                lid_lo=-50.0, lid_tilt=4.0, ears=(0.0, 0.0), nose=1.0, nose_rot=(0.0, 0.0), squash=(1.0, 1.0, 1.0),
                cow=0.0)


def paw_matrix(v):
    """(x, y, z[, rx, ry, rz]) or Matrix -> 4x4 Matrix in root space (no scale)."""
    if isinstance(v, Matrix):
        return v
    rot = v[3:] if len(v) > 3 else (0, 0, 0)
    return Matrix.Translation(Vector(v[:3])) @ Euler([RAD(a) for a in rot], 'XYZ').to_matrix().to_4x4()


def mix_paw(a, b, t):
    """Blend two paw placements (tuples or matrices)."""
    A, B = paw_matrix(a), paw_matrix(b)
    la, qa, _ = A.decompose()
    lb, qb, _ = B.decompose()
    return Matrix.Translation(la.lerp(lb, t)) @ qa.slerp(qb, t).to_matrix().to_4x4()


def mix_pose(a, b, t):
    """Blend two pose dictionaries (missing entries take the defaults)."""
    out = {}
    for k in set(a) | set(b) | set(DEFAULTS):
        if k == 'paws':
            continue
        va, vb = a.get(k, DEFAULTS.get(k)), b.get(k, DEFAULTS.get(k))
        if va is None or vb is None:
            continue
        if isinstance(va, (tuple, list)) or isinstance(vb, (tuple, list)):
            va = va if isinstance(va, (tuple, list)) else (va, va)
            vb = vb if isinstance(vb, (tuple, list)) else (vb, vb)
            out[k] = tuple(x + (y - x) * t for x, y in zip(va, vb))
        else:
            out[k] = va + (vb - va) * t
    pa, pb = a.get('paws') or {}, b.get('paws') or {}
    out['paws'] = {k: mix_paw(pa.get(k, STAND_PAWS[k]), pb.get(k, STAND_PAWS[k]), t) for k in STAND_PAWS}
    return out


class Hedgehog:
    """Handles of one built character. See the top of this file."""

    def __init__(self, P):
        self.P = P
        self.o = {}
        self.loc = Vector((0, 0, 0))
        self.yaw = 0.0
        self.lean = (0.0, 0.0)
        self.stretch = (1.0, 1.0, 1.0)
        self.M_body = Matrix.Identity(4)
        self.M_head = Matrix.Identity(4)

    # -------------------------------------------------------------------------------------------- the ground point
    def place(self, loc=None, yaw=None, lean=None, stretch=None):
        """Move the whole character: loc is the ground point under the body, yaw turns him (degrees; 0 faces -Y,
        90 faces +X), lean = (nose-up tip, roll to his right) in degrees about the ground point, stretch scales
        the whole puppet from the ground (squash and stretch)."""
        if loc is not None:
            self.loc = Vector(loc)
        if yaw is not None:
            self.yaw = yaw
        if lean is not None:
            self.lean = lean
        if stretch is not None:
            self.stretch = stretch
        r = self.o['root']
        r.location = self.loc
        r.rotation_euler = (-RAD(self.lean[0]), RAD(self.lean[1]), RAD(self.yaw))
        s = self.P['size']
        r.scale = (s * self.stretch[0], s * self.stretch[1], s * self.stretch[2])

    def M_root(self):
        r = self.o['root']
        return Matrix.Translation(r.location) @ r.rotation_euler.to_matrix().to_4x4() @ Matrix.Diagonal((*r.scale, 1.0))

    # -------------------------------------------------------------------------------------------- posing
    def pose(self, pitch=6.0, clear=0.006, head=(0.0, 0.0, 0.0), slide=(0.0, -0.016, -0.016), jaw=0.0,
             lid_up=52.0, lid_lo=-50.0, lid_tilt=4.0, ears=(0.0, 0.0), nose=1.0, nose_rot=(0.0, 0.0),
             squash=(1.0, 1.0, 1.0), cow=0.0, paws=None, gaze=None, lift=0.0):
        """pitch: body nose-up in degrees (6 on all fours, about 50 sitting up). clear: gap under the body.
        head = (nod up, turn toward +X, tilt top toward +X) in degrees, in the root's axes. slide moves the head
        on the body. jaw in degrees. ears = (L, R) degrees outward: positive droops, negative perks up.
        nose: scale; nose_rot = (up, side) degrees for a twitch. squash scales the body (x, y, z) for breathing and
        roundness. cow: cowlick tipped back in degrees. lift raises the body above its resting height (a hop).
        Lids and paws as described above POSES. gaze: a world point for the eyes (None: straight ahead)."""
        o, P = self.o, self.P
        hp = Vector(P['hip'])
        Rh = Matrix.Rotation(-RAD(pitch), 4, 'X')
        S = Matrix.Diagonal((squash[0], squash[1], squash[2], 1.0))
        M0 = Matrix.Translation((0, hp[1], 0)) @ Rh @ S @ Matrix.Translation(-hp)
        row = np.array(M0[2])
        z = self._body_verts @ row[:3] + row[3]
        hz = clear - float(z.min()) + lift
        o['hip'].location = (0, hp[1], hz)
        o['hip'].rotation_euler = (-RAD(pitch), 0, 0)
        o['hip'].scale = squash
        self.M_body = Matrix.Translation((0, hp[1], hz)) @ Rh @ S @ Matrix.Translation(-hp)
        o['neck'].rotation_euler = (RAD(pitch), 0, 0)
        o['head'].location = slide
        he = Euler((-RAD(head[0]), RAD(head[2]), RAD(head[1])), 'YXZ')
        o['head'].rotation_euler = he
        self.M_head = (self.M_body @ Matrix.Translation(Vector(P['neck'])) @ Matrix.Rotation(RAD(pitch), 4, 'X')
                       @ Matrix.Translation(Vector(slide)) @ he.to_matrix().to_4x4())
        o['jaw'].rotation_euler = (RAD(jaw), 0, 0)
        o['nose'].scale = (nose, nose, nose)
        o['nose'].rotation_euler = (-RAD(nose_rot[0]), 0, RAD(nose_rot[1]))
        self.lids(lid_up, lid_lo, lid_tilt)
        o['earL'].rotation_euler = (0, -RAD(ears[0]), 0)
        o['earR'].rotation_euler = (0, RAD(ears[1]), 0)
        if 'cowlick' in o:
            o['cowlick'].rotation_euler = (-RAD(cow), 0, 0)
        if paws:
            self.set_paws(paws)
        self.look_at(gaze)

    def set_paws(self, paws):
        for k, v in paws.items():
            self.place_paw(k, v)

    def place_paw(self, key, v):
        """Put a paw at a point of the root's space, whatever it is parented to."""
        paw = self.o['paw' + key]
        s = self.P['paw_hind'] if key[0] == 'H' else self.P['paw_front']
        M = paw_matrix(v) @ Matrix.Diagonal((s, s, s, 1.0))
        if key[0] == 'F':
            M = self.M_body.inverted() @ M
            # the elbow: out to the side, a little back and down, so the bent arm shows beside the chest or cheek
            S = Vector(self._anchor[key])
            d = M.translation - S
            dist = max(d.length, 1e-6)
            dn = d / dist
            out = Vector((-0.8 if key == 'FL' else 0.8, 0.35, -0.45)).normalized()
            out = out - dn * out.dot(dn)
            out = out.normalized() if out.length > 1e-6 else Vector((0, 0, -1))
            bend = max(math.sqrt(max(0.0, 0.023 ** 2 - (dist * 0.5) ** 2)), 0.008)
            self.o['elbow' + key].location = S + d * 0.5 + out * bend
        paw.matrix_basis = M

    def head_point(self, local):
        """A point of head space -> root space (valid after pose())."""
        return self.M_head @ Vector(local)

    def paw_on_face(self, side, az, el, out=0.004, roll=0.0, tip=0.0):
        """A paw laid on the face with its palm toward the fur: at the direction (az, el) in degrees from the head's
        centre (az to the given side, 'L' or 'R'), `out` metres above the head's surface, fingers pointing up
        (roll turns them, tip leans the palm). Used for covering the eyes. Returns a root-space matrix."""
        s = -1.0 if side == 'L' else 1.0
        a, e = RAD(az), RAD(el)
        d = Vector((s * math.sin(a) * math.cos(e), -math.cos(a) * math.cos(e), math.sin(e)))
        sdf = lambda q: g.head_base(q, self.P)  # noqa: E731
        surf = Vector(g.march(sdf, (0, 0, 0), np.array([[d.x, d.y, d.z]]), 0.09)[0])
        nrm = Vector(g.grad(sdf, np.array([[surf.x, surf.y, surf.z]]))[0])
        p = surf + nrm * out
        zax = nrm                                   # the paw's top faces away from the face
        up = Vector((0, 0, 1))
        yax = -(up - zax * up.dot(zax)).normalized()   # toes (the paw's -Y) point up
        xax = yax.cross(zax).normalized()
        R = Matrix((xax, yax, zax)).transposed().to_4x4()
        R = R @ Matrix.Rotation(RAD(roll), 4, 'Z') @ Matrix.Rotation(RAD(tip), 4, 'X')
        return self.M_head @ (Matrix.Translation(p) @ R)

    def paw_over_eye(self, side, lens, gap=0.0025, roll=0.0, shift=(0.0, 0.0)):
        """A paw held over an eye so that it hides the eye from the lens: the palm is centred on the line from the
        eye to the world point `lens`, just clear of the face, and faces half toward the eye and half toward the
        skin under it; toes up. shift = (to the paw's own right, up) in metres slides it in its own plane.
        Returns a root-space matrix (valid after pose())."""
        P = self.P
        e = Vector(self._eyes[side])
        d = ((self.M_root() @ self.M_head).inverted() @ Vector(lens) - e).normalized()
        sdf = lambda q: g.head_base(q, P)  # noqa: E731
        surf = Vector(g.march(sdf, tuple(e), np.array([[d.x, d.y, d.z]]), 0.06)[0])
        rim = P['eye_r'] * (P['lid_k'] + 0.03)
        zax = (d + e.normalized()).normalized()        # the paw's top: between "toward the lens" and "off the face"
        dist = min(max((surf - e).length, rim), rim * 1.5) + gap + 0.0040 * P['paw_front'] / max(zax.dot(d), 0.5)
        up = Vector((0, 0, 1))
        yax = -(up - zax * up.dot(zax)).normalized()   # toes (the paw's -Y) point up
        xax = yax.cross(zax).normalized()
        p = e + d * dist + xax * shift[0] - yax * shift[1]
        R = Matrix((xax, yax, zax)).transposed().to_4x4() @ Matrix.Rotation(RAD(roll), 4, 'Z')
        return self.M_head @ (Matrix.Translation(p) @ R)

    def lids(self, up=52.0, lo=-50.0, tilt=4.0):
        """up / lo: one number for both eyes or (L, R). tilt lowers the outer corners (soft, sweet); negative
        lowers the inner corners (cross, determined)."""
        up = up if isinstance(up, (tuple, list)) else (up, up)
        lo = lo if isinstance(lo, (tuple, list)) else (lo, lo)
        for i, (side, s) in enumerate((('L', -1), ('R', 1))):
            self.o['up' + side].rotation_euler = (-RAD(up[i]), s * RAD(tilt), 0)
            self.o['lo' + side].rotation_euler = (-RAD(lo[i]), 0, 0)

    def look_at(self, target=None, diverge=2.5, limit=28.0):
        """Aim both eyes at a world point (None: straight ahead of the head). Both eyes meet on the target but for
        2.5 degrees. The gaze never leaves the head's forward direction by more than `limit` degrees (turn the
        head toward the target instead)."""
        MW = self.M_root() @ self.M_head
        if target is None:
            target = MW @ Vector((0, -0.8, 0))
        ahead = (MW.to_3x3() @ Vector((0, -1, 0))).normalized()
        for side, s in (('L', -1), ('R', 1)):
            MS = MW @ Matrix.Translation(Vector(self._eyes[side])) @ Matrix.Rotation(RAD(s * self.P['eye_toe']), 4, 'Z')
            inv = MS.inverted()
            d = (inv @ Vector(target)).normalized()
            fwd = (inv.to_3x3() @ ahead).normalized()
            ang = fwd.angle(d, 0.0)
            if ang > RAD(limit):
                d = fwd.slerp(d, RAD(limit) / ang).normalized()
            self.o['ball' + side].rotation_quaternion = Quaternion((0, 0, 1), RAD(s * diverge)) @ d.to_track_quat('-Y', 'Z')

    # -------------------------------------------------------------------------------------------- queries (world)
    def world(self, head_local):
        return self.M_root() @ self.M_head @ Vector(head_local)

    def nose_tip(self):
        c, r = self.P['nose_c'], self.P['nose_r']
        return self.world((c[0], c[1] - r[1], c[2]))

    def eyes_mid(self):
        return self.world((0.0, self._eyes['L'][1] - 0.008, self._eyes['L'][2]))

    def body_point(self, local=(0, 0, 0)):
        return self.M_root() @ self.M_body @ Vector(local)

    # -------------------------------------------------------------------------------------------- keys
    def controls(self):
        ks = ['root', 'hip', 'neck', 'head', 'jaw', 'nose', 'ballL', 'ballR', 'upL', 'upR', 'loL', 'loR', 'earL', 'earR',
              'pawFL', 'pawFR', 'pawHL', 'pawHR']
        if 'cowlick' in self.o:
            ks.append('cowlick')
        return [self.o[k] for k in ks]

    def key(self, frame):
        """Keyframe every control at this frame (call after place / pose / look_at / your own edits)."""
        for name in ('root', 'hip', 'head', 'pawFL', 'pawFR', 'pawHL', 'pawHR'):
            ob = self.o[name]
            ob.keyframe_insert('location', frame=frame)
            ob.keyframe_insert('rotation_euler', frame=frame)
        for name in ('elbowFL', 'elbowFR'):
            self.o[name].keyframe_insert('location', frame=frame)
        self.o['root'].keyframe_insert('scale', frame=frame)
        self.o['hip'].keyframe_insert('scale', frame=frame)
        self.o['nose'].keyframe_insert('scale', frame=frame)
        for name in ('neck', 'jaw', 'nose', 'upL', 'upR', 'loL', 'loR', 'earL', 'earR'):
            self.o[name].keyframe_insert('rotation_euler', frame=frame)
        if 'cowlick' in self.o:
            self.o['cowlick'].keyframe_insert('rotation_euler', frame=frame)
        for name in ('ballL', 'ballR'):
            self.o[name].keyframe_insert('rotation_quaternion', frame=frame)

    def eye_objects(self):
        """The objects that receive the catchlight lamp: both eyeballs and the nose."""
        return [self.o['ballL'], self.o['ballR'], self.o['nose_mesh']]


# ------------------------------------------------------------------------------------------------ the build
def build_hedgehog(variant='little', name=None, fur=1.0, seed=3):
    """Build Little Hedgehog (or 'mama') into the current scene and return its Hedgehog handle.
    fur scales the number of strands (1.0 is the design); strands get thicker as they get fewer, so the coat
    stays closed. Use about 0.4 when he is small in the picture."""
    P = g.params(variant)
    for k in ('n_face', 'n_head_spines', 'n_body_fur', 'n_body_under', 'n_body_spines'):
        P[k] = max(200, int(P[k] * fur))
    thick = 1.0 / math.sqrt(max(fur, 0.05))
    name = name or ('Mama' if variant == 'mama' else 'Little')
    rig = Hedgehog(P)
    o = rig.o
    N = lambda s: name + '.' + s  # noqa: E731

    def strands(nm, data, mat, parent, loc=(0, 0, 0), scale_r=True):
        if scale_r and thick != 1.0:
            data = dict(data)
            data['rad'] = np.asarray(data['rad']) * thick
        return kit.curves(nm, data, mat, parent, loc)

    under = mat_skin(N('under'), sss=0.0, sheen=0.5, rough=0.7)
    skin = mat_skin(N('skin'), sss=0.35, sheen=0.5, rough=0.55)
    wet = mat_skin(N('mouth'), sss=0.0, sheen=0.0, rough=0.45, coat=0.15)
    furm = mat_fur(N('fur'))
    spm = mat_spines(N('spines'), P['spine'])
    nosem = mat_nose(N('nose'))
    pawm = mat_skin(N('paw'), sss=0.0, sheen=0.35, rough=0.8)

    root = o['root'] = kit.empty(N('root'), None, (0, 0, 0))
    root.scale = (P['size'],) * 3
    hip = o['hip'] = kit.empty(N('hip'), root, (0, P['hip'][1], 0.05))

    # body
    B = g.build_body(P, seed + 4)
    body = o['body'] = kit.mesh(N('body'), B['verts'], B['faces'], under, hip, B['col'], loc=tuple(-np.array(P['hip'])))
    rig._body_verts = np.asarray(B['verts'], dtype=np.float64)
    o['body_fur'] = strands(N('body_fur'), B['fur'], furm, body)
    o['body_spines'] = strands(N('body_spines'), B['spines'], spm, body)

    # head
    neck = o['neck'] = kit.empty(N('neck'), body, P['neck'])
    head = o['head'] = kit.empty(N('head'), neck, (0, -0.016, -0.016))
    head.rotation_mode = 'YXZ'
    H = g.build_head(P, seed)
    rig._eyes = {k: tuple(float(x) for x in v) for k, v in H['eyes'].items()}
    hm = o['head_mesh'] = kit.mesh(N('head_mesh'), H['verts'], H['faces'], under, head, H['col'])
    o['head_fur'] = strands(N('head_fur'), H['fur'], furm, hm)
    o['head_spines'] = strands(N('head_spines'), H['spines'], spm, hm)
    o['whiskers'] = kit.curves(N('whiskers'), H['whiskers'], furm, hm)
    if 'cowlick' in H:
        cw = o['cowlick'] = kit.empty(N('cowlick'), head, tuple(H['cowlick']['pivot']))
        o['cowlick_spines'] = kit.curves(N('cowlick_spines'), H['cowlick'], spm, cw)

    # mouth: the lower jaw is the lower slice of the snout; it swings down on a hinge. Closed, it is a soft smile.
    hinge = np.array(P['hinge'])
    jaw = o['jaw'] = kit.empty(N('jaw'), head, tuple(hinge))
    J = g.build_jaw(P, seed + 2)
    jm = o['jaw_mesh'] = kit.mesh(N('jaw_mesh'), J['verts'], J['faces'], under, jaw, J['col'], loc=tuple(-hinge))
    o['jaw_fur'] = strands(N('jaw_fur'), J['fur'], furm, jm)
    ym = 0.5 * (P['jaw_back'] + P['jaw_front']) + 0.004
    tv, tf = g.ellipsoid_mesh(0.0040, 0.0056, 0.0016, 28, 14)
    tc = np.array([0.0, ym, float(g.cut_z(np.array(ym), P)) - 0.0002])
    o['tongue'] = kit.mesh(N('tongue'), tv, tf, wet, jaw, _flat(g.lin('#d98088'), len(tv)), loc=tuple(tc - hinge),
                           subsurf=1)
    bv, bf = g.uv_sphere(0.0078, 20, 10)
    o['mouth_back'] = kit.mesh(N('mouth_back'), bv, bf, wet, head, _flat(g.lin(g.MOUTH) * 0.8, len(bv)),
                               loc=(0.0, P['jaw_back'] - 0.003, float(g.cut_z(np.array(P['jaw_back']), P)) - 0.001))

    # nose
    nose = o['nose'] = kit.empty(N('nose'), head, P['nose_c'])
    nv, nf = g.ellipsoid_mesh(*P['nose_r'], segs=36, rings=20)
    nv[:, 2] *= 1.0 + 0.12 * np.clip(nv[:, 2] / P['nose_r'][2], -1, 0)      # a slightly flatter underside
    o['nose_mesh'] = kit.mesh(N('nose_mesh'), nv, nf, nosem, nose, subsurf=1)

    # eyes: a socket (fixed), an eyeball (gaze) and two furry lids each
    # lids are a touch warmer and darker than the fur around them, and their margins carry a dark lash line: a
    # closed eye is a dark curved line on a soft lid, never a blank pale disc
    lidc, margin = g.mix(g.lin(P['face']), g.lin('#c9a27a'), np.array(0.30)), g.lin('#22140f')
    lashm = kit.principled(N('lash'), color='#1c110d', rough=0.55, spec=0.25)
    lid_rng = np.random.default_rng(seed + 40)
    r = P['eye_r']
    em = mat_eye(N('eye'))
    for side, s in (('L', -1), ('R', 1)):
        sock = o['sock' + side] = kit.empty(N('sock' + side), head, tuple(H['eyes'][side]))
        sock.rotation_euler = (0, 0, RAD(s * P['eye_toe']))
        ev, ef = g.uv_sphere(r, 56, 28)
        ball = o['ball' + side] = kit.mesh(N('ball' + side), ev, ef, em, sock, subsurf=1)
        ball.rotation_mode = 'QUATERNION'
        for key, upper in (('up', True), ('lo', False)):
            lv, lf, lw = g.lid_wedge(r, upper, k=P['lid_k'])
            col = g.rgba(g.mix(np.repeat(lidc[None, :], len(lv), 0), margin, lw))
            lid = o[key + side] = kit.mesh(N(key + side), lv, lf, under, sock, col)
            o[key + side + '_fur'] = strands(N(key + side + '_fur'),
                                             g.lid_fur(r, upper, P['lid_k'], max(500, int(2000 * fur)), lid_rng, lidc,
                                                       margin),
                                             furm, lid)
            if upper:
                path, rad = g.lid_lash(r, P['lid_k'])
                tv, tf = kit.tube(path, rad, 8)
                kit.mesh(N('lash' + side), tv, tf, lashm, lid)

    # ears: pink skin that lets light through, fine fuzz on the back
    for side, s in (('L', -1), ('R', 1)):
        EA = g.build_ear(P, s, seed + 50)
        c = g.mirror(P['ear_c'], s)
        piv = o['ear' + side] = kit.empty(N('ear' + side), head, tuple(c - np.array([0, 0, P['ear_r'][2] * 0.7])))
        em_o = kit.mesh(N('ear_mesh' + side), EA['verts'], EA['faces'], skin, piv, EA['col'],
                        loc=(0, 0, P['ear_r'][2] * 0.7), subsurf=1)
        em_o.rotation_euler = (0, RAD(s * 24), RAD(s * 28))
        kit.curves(N('ear_fur' + side), EA['fur'], furm, em_o)

    # paws and the short furry legs that follow them
    PW = g.build_paw(P, seed + 60, n_fur=max(350, int(1100 * fur)))
    anchors = dict(FL=g.mirror(P['shoulder'], -1), FR=g.mirror(P['shoulder'], 1),
                   HL=g.mirror(P['thigh'], -1), HR=g.mirror(P['thigh'], 1))
    limb_col = '#f6ecd8'
    rig._anchor = {k: tuple(float(x) for x in v) for k, v in anchors.items()}

    def limb(nm, length, radius, n_fur, fur_len, parent, loc, target, sd):
        LB = g.build_limb(P, length, radius, limb_col, sd, n_fur=max(300, int(n_fur * fur)), fur_len=fur_len)
        leg = kit.mesh(N(nm), LB['verts'], LB['faces'], under, parent, LB['col'], loc=loc)
        strands(N(nm + '_fur'), LB['fur'], furm, leg)
        c = leg.constraints.new('STRETCH_TO')
        c.target = target
        c.rest_length = length
        c.volume = 'NO_VOLUME'
        return leg
    for i, (key, anc) in enumerate(anchors.items()):
        front = key[0] == 'F'
        paw = o['paw' + key] = kit.mesh(N('paw' + key), PW['verts'], PW['faces'], pawm, body if front else root,
                                        PW['col'], subsurf=1)
        strands(N('paw' + key + '_fur'), PW['fur'], furm, paw)
        if front:       # an arm of two furry pieces with an elbow between them
            elbow = o['elbow' + key] = kit.empty(N('elbow' + key), body, tuple(anc))
            limb('arm' + key, 0.021, 0.0064, 1300, 0.0050, body, tuple(anc), elbow, seed + 20 + i)
            limb('fore' + key, 0.021, 0.0058, 1300, 0.0046, elbow, (0, 0, 0), paw, seed + 30 + i)
        else:
            limb('leg' + key, 0.03, 0.0078, 2600, 0.0064, body, tuple(anc), paw, seed + 20 + i)

    rig.place((0, 0, 0), 0.0)
    rig.pose(**POSES['stand'])
    return rig
