"""Design proposal 2: the evening light of the film and a simple patch of the garden to stand the hero in.

Made for stills of the character, but each piece is a plain function the film can reuse:
  build_evening_light()   dusk sky for the light, a painted dusk gradient for what the lens sees, a low warm sun
  add_fill(), add_eye_light(), aim()   the warm bounce beside the lens and the catchlight for eyes and nose
  build_patch()           soil, pebbles, backlit grass tufts behind the hero, bushes with gaps of sky
  add_camera(), render_settings(), add_bloom()
"""
import math
import os
import random
import sys

import bpy
import numpy as np
from mathutils import Vector

HERE = os.path.dirname(os.path.abspath(__file__))
_BL = os.path.abspath(os.path.join(HERE, '..', '..', '..', 'blender'))
if _BL not in sys.path:
    sys.path.insert(0, _BL)
import lib  # noqa: E402
from lib import lin  # noqa: E402

# ---------------------------------------------------------------------------------------------- light


def build_evening_light(sun_az=64.0, sun_el=8.0, sun_w=9.0, sky=0.055, exposure_of_view=0.95):
    """The last golden light. sun_az is measured from +Y toward +X (the lens looks along +Y, so 55 puts the sun
    behind the hero and to frame right). Returns (sun object, unit vector toward the sun)."""
    sc = bpy.context.scene
    w = bpy.data.worlds.new('Dusk')
    w.use_nodes = True
    nt = w.node_tree
    bg = nt.nodes['Background']
    tex = nt.nodes.new('ShaderNodeTexSky')
    tex.sky_type = 'MULTIPLE_SCATTERING'
    tex.sun_disc = False
    tex.sun_elevation = math.radians(sun_el)
    tex.sun_rotation = math.radians(sun_az) % (2 * math.pi)
    tex.air_density = 1.0
    tex.aerosol_density = 1.4
    tex.altitude = 200
    nt.links.new(tex.outputs['Color'], bg.inputs['Color'])
    bg.inputs['Strength'].default_value = sky
    # what the lens sees: a painted dusk, apricot at the horizon through rose to a soft blue
    geo = nt.nodes.new('ShaderNodeNewGeometry')
    sep = nt.nodes.new('ShaderNodeSeparateXYZ')
    nt.links.new(geo.outputs['Incoming'], sep.inputs[0])
    neg = nt.nodes.new('ShaderNodeMath')
    neg.operation = 'MULTIPLY'
    neg.inputs[1].default_value = -1.0
    nt.links.new(sep.outputs['Z'], neg.inputs[0])
    ramp = nt.nodes.new('ShaderNodeValToRGB')
    e = ramp.color_ramp.elements
    e[0].position, e[0].color = 0.0, lin('#ffb56a')
    e[1].position, e[1].color = 0.75, lin('#3d5aa0')
    for pos, c in ((0.06, '#f39a7a'), (0.16, '#b98fb8'), (0.36, '#6f7fc0')):
        ramp.color_ramp.elements.new(pos).color = lin(c)
    nt.links.new(neg.outputs[0], ramp.inputs['Fac'])
    bg2 = nt.nodes.new('ShaderNodeBackground')
    bg2.inputs['Strength'].default_value = exposure_of_view
    nt.links.new(ramp.outputs['Color'], bg2.inputs['Color'])
    lp = nt.nodes.new('ShaderNodeLightPath')
    mix = nt.nodes.new('ShaderNodeMixShader')
    nt.links.new(lp.outputs['Is Camera Ray'], mix.inputs['Fac'])
    nt.links.new(bg.outputs[0], mix.inputs[1])
    nt.links.new(bg2.outputs[0], mix.inputs[2])
    nt.links.new(mix.outputs[0], nt.nodes['World Output'].inputs['Surface'])
    sc.world = w
    ld = bpy.data.lights.new('Sun', 'SUN')
    ld.energy = sun_w
    ld.angle = math.radians(3.0)
    ld.color = lin('#ff9447')[:3]
    o = bpy.data.objects.new('Sun', ld)
    lib.link(o)
    az, el = math.radians(sun_az), math.radians(sun_el)
    sdir = Vector((math.sin(az) * math.cos(el), math.cos(az) * math.cos(el), math.sin(el)))
    o.rotation_euler = (-sdir).to_track_quat('-Z', 'Y').to_euler()
    return o, sdir


def aim(o, pos, target):
    o.location = pos
    o.rotation_euler = (Vector(target) - Vector(pos)).to_track_quat('-Z', 'Y').to_euler()


def add_fill(energy=2.4, color='#ffb878', size=(1.4, 0.9)):
    """The warm bounce from the lens side that keeps the shaded face readable (aim() it per shot)."""
    ld = bpy.data.lights.new('Fill', 'AREA')
    ld.shape = 'RECTANGLE'
    ld.size, ld.size_y = size
    ld.energy = energy
    ld.color = lin(color)[:3]
    o = bpy.data.objects.new('Fill', ld)
    lib.link(o)
    return o


def add_eye_light(objects, energy=2.5, size=0.36):
    """A soft round light that only the given objects receive (eyes and nose): the catchlight."""
    ld = bpy.data.lights.new('EyeLight', 'AREA')
    ld.shape = 'DISK'
    ld.size = size
    ld.energy = energy
    ld.color = lin('#fff1dc')[:3]
    o = bpy.data.objects.new('EyeLight', ld)
    lib.link(o)
    coll = bpy.data.collections.new('EyeLit')
    for ob in objects:
        coll.objects.link(ob)
    o.light_linking.receiver_collection = coll
    return o


# ---------------------------------------------------------------------------------------------- the patch


def _grass_material():
    m = lib.principled('G.grass', '#6f9a2c', rough=0.5, spec=0.3)
    nt = m.node_tree
    b = nt.nodes['Principled BSDF']
    out = [n for n in nt.nodes if n.bl_idname == 'ShaderNodeOutputMaterial'][0]
    oi = nt.nodes.new('ShaderNodeObjectInfo')
    cr = nt.nodes.new('ShaderNodeValToRGB')
    e = cr.color_ramp.elements
    e[0].position, e[0].color = 0.0, lin('#4a7420')
    e[1].position, e[1].color = 1.0, lin('#a3aa44')
    cr.color_ramp.elements.new(0.55).color = lin('#74962c')
    nt.links.new(oi.outputs['Random'], cr.inputs['Fac'])
    tc = nt.nodes.new('ShaderNodeTexCoord')
    sep = nt.nodes.new('ShaderNodeSeparateXYZ')
    nt.links.new(tc.outputs['Generated'], sep.inputs[0])
    mx = nt.nodes.new('ShaderNodeMixRGB')
    mx.inputs[1].default_value = lin('#1f3310')
    nt.links.new(sep.outputs['Z'], mx.inputs[0])
    nt.links.new(cr.outputs['Color'], mx.inputs[2])
    nt.links.new(mx.outputs[0], b.inputs['Base Color'])
    warm = nt.nodes.new('ShaderNodeMixRGB')
    warm.blend_type = 'MULTIPLY'
    warm.inputs[0].default_value = 1.0
    warm.inputs[2].default_value = (1.0, 0.95, 0.45, 1.0)
    nt.links.new(mx.outputs[0], warm.inputs[1])
    tr = nt.nodes.new('ShaderNodeBsdfTranslucent')
    nt.links.new(warm.outputs[0], tr.inputs['Color'])
    ms = nt.nodes.new('ShaderNodeMixShader')
    ms.inputs[0].default_value = 0.38
    nt.links.new(b.outputs[0], ms.inputs[1])
    nt.links.new(tr.outputs[0], ms.inputs[2])
    nt.links.new(ms.outputs[0], out.inputs['Surface'])
    return m


def _soil_material():
    m = lib.principled('G.soil', '#4d3a28', rough=0.92, spec=0.2)
    nt = m.node_tree
    b = nt.nodes['Principled BSDF']
    tc = nt.nodes.new('ShaderNodeTexCoord')
    n1 = nt.nodes.new('ShaderNodeTexNoise')
    n1.inputs['Scale'].default_value = 9.0
    n1.inputs['Detail'].default_value = 6.0
    nt.links.new(tc.outputs['Object'], n1.inputs['Vector'])
    cr = nt.nodes.new('ShaderNodeValToRGB')
    e = cr.color_ramp.elements
    e[0].position, e[0].color = 0.30, lin('#4a3524')
    e[1].position, e[1].color = 0.72, lin('#836443')
    cr.color_ramp.elements.new(0.50).color = lin('#624a31')
    nt.links.new(n1.outputs[0], cr.inputs['Fac'])
    n2 = nt.nodes.new('ShaderNodeTexNoise')
    n2.inputs['Scale'].default_value = 2.6
    nt.links.new(tc.outputs['Object'], n2.inputs['Vector'])
    moss = nt.nodes.new('ShaderNodeValToRGB')
    e = moss.color_ramp.elements
    e[0].position, e[0].color = 0.52, (0, 0, 0, 1)
    e[1].position, e[1].color = 0.66, (1, 1, 1, 1)
    nt.links.new(n2.outputs[0], moss.inputs['Fac'])
    mx = nt.nodes.new('ShaderNodeMixRGB')
    mx.inputs[2].default_value = lin('#47532a')
    nt.links.new(moss.outputs['Color'], mx.inputs[0])
    nt.links.new(cr.outputs['Color'], mx.inputs[1])
    nt.links.new(mx.outputs[0], b.inputs['Base Color'])
    n3 = nt.nodes.new('ShaderNodeTexNoise')
    n3.inputs['Scale'].default_value = 260.0
    n3.inputs['Detail'].default_value = 4.0
    nt.links.new(tc.outputs['Object'], n3.inputs['Vector'])
    bump = nt.nodes.new('ShaderNodeBump')
    bump.inputs['Strength'].default_value = 0.55
    bump.inputs['Distance'].default_value = 0.004
    nt.links.new(n3.outputs[0], bump.inputs['Height'])
    nt.links.new(bump.outputs['Normal'], b.inputs['Normal'])
    return m


def _tuft(name, rng, mat, coll, blades=22):
    verts, faces = [], []
    for _ in range(blades):
        ang, rad = rng.uniform(0, 2 * math.pi), 0.03 * math.sqrt(rng.random())
        bx, by = rad * math.cos(ang), rad * math.sin(ang)
        h, w = rng.uniform(0.04, 0.095), rng.uniform(0.0035, 0.006)
        bend, tw, yaw = rng.uniform(0.1, 0.5), rng.uniform(-0.7, 0.7), rng.uniform(0, 2 * math.pi)
        n, base = 5, len(verts)
        for i in range(n + 1):
            t = i / n
            off = bend * h * t * t
            ww = w * (1 - t) ** 0.8 + 0.0003
            a = yaw + tw * t
            cx, cy = bx + math.cos(yaw) * off, by + math.sin(yaw) * off
            px, py = -math.sin(a) * ww / 2, math.cos(a) * ww / 2
            z = h * t * (1 - 0.15 * bend * t)
            verts.append((cx - px, cy - py, z))
            verts.append((cx + px, cy + py, z))
        for i in range(n):
            a = base + 2 * i
            faces.append((a, a + 1, a + 3, a + 2))
    o = lib.mesh_obj(name, verts, faces, mat, None, True, 0)
    bpy.context.scene.collection.objects.unlink(o)
    coll.objects.link(o)
    return o


def _sock(node, name, outputs=True):
    """The enabled socket of that name (some nodes carry one hidden socket per data type)."""
    socks = node.outputs if outputs else node.inputs
    live = [s for s in socks if s.name == name and s.enabled]
    return live[0] if live else socks[name]


def scatter(name, coll, pos, rotz, scale, index):
    """Instances the collection's objects on points (Geometry Nodes): one tuft per point."""
    n = len(pos)
    me = bpy.data.meshes.new(name)
    me.vertices.add(n)
    me.vertices.foreach_set('co', np.ascontiguousarray(pos, dtype=np.float32).ravel())
    rot = np.zeros((n, 3), dtype=np.float32)
    rot[:, 2] = rotz
    me.attributes.new('rot', 'FLOAT_VECTOR', 'POINT').data.foreach_set('vector', rot.ravel())
    me.attributes.new('scl', 'FLOAT', 'POINT').data.foreach_set('value', np.ascontiguousarray(scale, dtype=np.float32))
    me.attributes.new('idx', 'INT', 'POINT').data.foreach_set('value', np.ascontiguousarray(index, dtype=np.int32))
    me.update()
    ng = bpy.data.node_groups.new(name, 'GeometryNodeTree')
    ng.interface.new_socket('Geometry', in_out='INPUT', socket_type='NodeSocketGeometry')
    ng.interface.new_socket('Geometry', in_out='OUTPUT', socket_type='NodeSocketGeometry')
    N, Lk = ng.nodes, ng.links
    gi, go = N.new('NodeGroupInput'), N.new('NodeGroupOutput')
    ci = N.new('GeometryNodeCollectionInfo')
    ci.inputs['Collection'].default_value = coll
    ci.inputs['Separate Children'].default_value = True
    ci.inputs['Reset Children'].default_value = True
    iop = N.new('GeometryNodeInstanceOnPoints')
    iop.inputs['Pick Instance'].default_value = True
    Lk.new(gi.outputs[0], iop.inputs['Points'])
    Lk.new(ci.outputs[0], iop.inputs['Instance'])
    for attr, kind, sock in (('idx', 'INT', 'Instance Index'), ('rot', 'FLOAT_VECTOR', 'Rotation'),
                             ('scl', 'FLOAT', 'Scale')):
        na = N.new('GeometryNodeInputNamedAttribute')
        na.data_type = kind
        na.inputs['Name'].default_value = attr
        Lk.new(_sock(na, 'Attribute'), iop.inputs[sock])
    Lk.new(iop.outputs[0], go.inputs[0])
    o = bpy.data.objects.new(name, me)
    lib.link(o)
    md = o.modifiers.new(name, 'NODES')
    md.node_group = ng
    return o


def _bush(name, center, radius, seed, mat):
    dirs, faces = lib.icosphere_dirs(4)
    rng = np.random.default_rng(seed)
    r = np.ones(len(dirs))
    for _ in range(18):
        c = rng.normal(0, 1, 3)
        c /= np.linalg.norm(c)
        r += 0.26 * np.exp(-(1 - dirs @ c) / 0.035)
    r += 0.03 * np.sin(dirs[:, 0] * 31 + seed) * np.sin(dirs[:, 1] * 27) * np.sin(dirs[:, 2] * 29)
    verts = dirs * (r * radius)[:, None] * np.array([1.0, 1.0, 0.85])
    return lib.mesh_obj(name, verts, faces, mat, None, True, 1, loc=center)


def build_patch(sun_dir, seed=3, grass=True):
    """Soil with pebbles where the hero stands (so his paws and belly stay readable), backlit grass behind him,
    bushes with gaps of dusk sky in the far blur. The hero stands at the origin; lenses look roughly along +Y.
    Grass that would shade him from the low sun is kept short."""
    rng = np.random.default_rng(seed)
    prn = random.Random(seed)
    objs = []
    # ground
    xs, ys = np.linspace(-6.0, 6.0, 97), np.linspace(-2.0, 12.0, 113)
    X, Y = np.meshgrid(xs, ys)
    R = np.sqrt(X ** 2 + Y ** 2)
    Z = 0.010 * np.sin(2.1 * X + 0.6 * Y) * np.cos(1.7 * Y - 0.4 * X) * np.clip((R - 0.25) / 0.5, 0, 1)
    verts = np.stack([X.ravel(), Y.ravel(), Z.ravel()], axis=1)
    nx, ny = len(xs), len(ys)
    faces = [(j * nx + i, j * nx + i + 1, (j + 1) * nx + i + 1, (j + 1) * nx + i)
             for j in range(ny - 1) for i in range(nx - 1)]
    objs.append(lib.mesh_obj('G.ground', verts, faces, _soil_material(), None, True, 0))

    # pebbles
    stone = lib.principled('G.stone', '#6b6055', rough=0.85, spec=0.25)
    bases = [lib.ellipsoid(f'G.pebble{i}', 1.0, 0.8 - 0.1 * i, 0.55, stone, None, (0, 0, 0), 12, 1) for i in range(3)]
    for o in bases:                                    # only their mesh is used, by the copies below
        bpy.context.scene.collection.objects.unlink(o)
    for i in range(46):
        a, rr = prn.uniform(0, 2 * math.pi), prn.uniform(0.10, 0.75)
        x, y = rr * math.cos(a), rr * math.sin(a) * 0.9 - 0.12
        if abs(x) < 0.07 and -0.12 < y < 0.10:
            continue
        o = bpy.data.objects.new(f'G.peb{i}', bases[i % 3].data)
        lib.link(o)
        s = prn.uniform(0.003, 0.010) * (1.6 if prn.random() < 0.08 else 1.0)
        o.scale = (s, s, s)
        o.location = (x, y, s * 0.25)
        o.rotation_euler = (prn.uniform(-0.3, 0.3), prn.uniform(-0.3, 0.3), prn.uniform(0, 6.28))
        objs.append(o)

    # grass
    if grass:
        gm = _grass_material()
        coll = bpy.data.collections.new('G.tufts')
        for i in range(6):
            _tuft(f'G.tuft{i}', prn, gm, coll)
        n = 12000
        x = rng.uniform(-2.4, 2.4, n)
        y = rng.uniform(-1.3, 3.2, n)
        behind = y > 0.13
        side = np.abs(x - 0.08) > 0.42 + 0.6 * np.maximum(0.0, 0.13 - y)
        thin = rng.random(n) < np.where(y < 1.1, 1.0, 0.45)
        keep = (behind | side) & thin
        x, y = x[keep], y[keep]
        scl = (0.45 + 0.55 * np.clip((y - 0.13) / 0.5, 0, 1)) * rng.uniform(0.8, 1.15, len(x))
        scl = np.where(y > 0.13, scl, rng.uniform(0.7, 1.1, len(x)))
        h = np.array([sun_dir[0], sun_dir[1]])
        h = h / np.linalg.norm(h)
        along = x * h[0] + y * h[1]
        across = np.abs(-x * h[1] + y * h[0])
        cap = np.where((along > 0) & (along < 1.3) & (across < 0.22), np.maximum(0.012, 0.11 * along) / 0.095, 9.0)
        scl = np.minimum(scl, cap)
        # a few very short tufts on the soil around him
        m = 170
        a, rr = rng.uniform(0, 2 * math.pi, m), rng.uniform(0.13, 0.7, m)
        x2, y2 = rr * np.cos(a), rr * np.sin(a) - 0.1
        x, y = np.concatenate([x, x2]), np.concatenate([y, y2])
        scl = np.concatenate([scl, rng.uniform(0.12, 0.30, m)])
        pos = np.stack([x, y, np.zeros(len(x))], axis=1)
        objs.append(scatter('G.grass', coll, pos, rng.uniform(0, 6.283, len(x)), scl, rng.integers(0, 6, len(x))))

    # bushes far behind, with gaps where the dusk sky shows
    leaf = lib.principled('G.leaf', '#2c4a1c', rough=0.7, sheen=0.2, sheen_rough=0.5, spec=0.2)
    nt = leaf.node_tree
    tc = nt.nodes.new('ShaderNodeTexCoord')
    nz = nt.nodes.new('ShaderNodeTexNoise')
    nz.inputs['Scale'].default_value = 14.0
    nt.links.new(tc.outputs['Object'], nz.inputs['Vector'])
    cr = nt.nodes.new('ShaderNodeValToRGB')
    e = cr.color_ramp.elements
    e[0].position, e[0].color = 0.35, lin('#182a0f')
    e[1].position, e[1].color = 0.70, lin('#3b5a1c')
    nt.links.new(nz.outputs[0], cr.inputs['Fac'])
    nt.links.new(cr.outputs['Color'], nt.nodes['Principled BSDF'].inputs['Base Color'])
    for i, (bx, by, bz, br) in enumerate([(-3.4, 6.6, 0.12, 0.62), (-1.7, 6.0, 0.08, 0.50), (0.2, 6.9, 0.10, 0.66),
                                          (1.9, 6.2, 0.06, 0.52), (3.6, 7.0, 0.12, 0.70), (-5.2, 7.4, 0.15, 0.80)]):
        objs.append(_bush(f'G.bush{i}', (bx, by, bz), br, 20 + i, leaf))
    return objs


# ---------------------------------------------------------------------------------------------- camera and render


def add_camera(name, pos, look, lens, fstop, focus_obj=None):
    cam = bpy.data.cameras.new(name)
    cam.lens = lens
    cam.sensor_width = 36
    cam.clip_start = 0.01
    cam.clip_end = 200
    cam.dof.use_dof = True
    cam.dof.aperture_fstop = fstop
    if focus_obj is not None:
        cam.dof.focus_object = focus_obj
    else:
        cam.dof.focus_distance = (Vector(look) - Vector(pos)).length
    o = bpy.data.objects.new(name, cam)
    lib.link(o)
    aim(o, pos, look)
    return o


def render_settings(res=(1280, 720), samples=32, exposure=0.5):
    sc = bpy.context.scene
    sc.render.engine = 'CYCLES'
    c = sc.cycles
    c.device = 'CPU'
    c.samples = samples
    c.use_adaptive_sampling = True
    c.adaptive_threshold = 0.02
    c.use_denoising = True
    c.denoiser = 'OPENIMAGEDENOISE'
    c.max_bounces = 8
    c.diffuse_bounces = 3
    c.glossy_bounces = 3
    c.transmission_bounces = 6
    c.transparent_max_bounces = 8
    c.caustics_reflective = False
    c.caustics_refractive = False
    c.sample_clamp_indirect = 6.0
    sc.cycles_curves.shape = 'RIBBONS'
    sc.render.use_persistent_data = True
    sc.render.resolution_x, sc.render.resolution_y = res
    sc.render.resolution_percentage = 100
    sc.render.use_motion_blur = False
    sc.view_settings.view_transform = 'AgX'
    sc.view_settings.look = 'AgX - Punchy'
    sc.view_settings.exposure = exposure
    sc.render.image_settings.file_format = 'PNG'
    sc.render.image_settings.color_mode = 'RGB'
    sc.render.image_settings.color_depth = '8'
    sc.render.film_transparent = False
    sc.render.compositor_device = 'CPU'
    return sc


def add_bloom(threshold=1.3, strength=0.30, size=0.45):
    """A light bloom on the brightest rims (compositor on the processor). Returns True if it could be set up."""
    sc = bpy.context.scene
    sc.render.compositor_device = 'CPU'
    try:
        ng = bpy.data.node_groups.new('Bloom', 'CompositorNodeTree')
        ng.interface.new_socket('Image', in_out='OUTPUT', socket_type='NodeSocketColor')
        rl = ng.nodes.new('CompositorNodeRLayers')
        gl = ng.nodes.new('CompositorNodeGlare')
        go = ng.nodes.new('NodeGroupOutput')
        gl.inputs['Type'].default_value = 'Bloom'
        gl.inputs['Threshold'].default_value = threshold
        gl.inputs['Strength'].default_value = strength
        gl.inputs['Size'].default_value = size
        ng.links.new(rl.outputs['Image'], gl.inputs['Image'])
        ng.links.new(gl.outputs['Image'], go.inputs[0])
        sc.compositing_node_group = ng
        sc.render.use_compositing = True
        return True
    except Exception as ex:  # noqa: BLE001
        print('BLOOM not set up: %r' % (ex,), flush=True)
        try:
            sc.compositing_node_group = None
        except Exception:  # noqa: BLE001
            pass
        return False
