"""Design 3, Little Hedgehog: all the shape maths (numpy only, no Blender).

Units are metres, Z is up, the character faces -Y. Every piece is described in its own local space.
Nothing here is random without a seed: the same call gives the same arrays.
"""
import math

import numpy as np

# ------------------------------------------------------------------------------------------------ small helpers


def lin(h):
    """sRGB hex -> linear RGB (3 floats)."""
    h = h.lstrip('#')
    c = np.array([int(h[i:i + 2], 16) / 255.0 for i in (0, 2, 4)])
    return np.where(c <= 0.04045, c / 12.92, ((c + 0.055) / 1.055) ** 2.4)


def smoothstep(a, b, x):
    t = np.clip((np.asarray(x, dtype=np.float64) - a) / (b - a), 0.0, 1.0)
    return t * t * (3.0 - 2.0 * t)


def mix(a, b, w):
    w = np.asarray(w)[..., None]
    return a * (1.0 - w) + b * w


def unit(v):
    v = np.asarray(v, dtype=np.float64)
    return v / np.maximum(np.linalg.norm(v, axis=-1, keepdims=True), 1e-12)


def sd_sphere(p, c, r):
    return np.linalg.norm(p - np.asarray(c), axis=-1) - r


def sd_ellipsoid(p, c, r):
    r = np.asarray(r, dtype=np.float64)
    q = (p - np.asarray(c)) / r
    k0 = np.linalg.norm(q, axis=-1)
    k1 = np.linalg.norm(q / r, axis=-1)
    return k0 * (k0 - 1.0) / np.maximum(k1, 1e-9)


def sd_roundcone(p, a, b, ra, rb):
    a = np.asarray(a, dtype=np.float64)
    b = np.asarray(b, dtype=np.float64)
    ab = b - a
    h = np.clip(((p - a) @ ab) / (ab @ ab), 0.0, 1.0)
    q = p - (a + h[..., None] * ab)
    return np.linalg.norm(q, axis=-1) - (ra + (rb - ra) * h)


def smin(a, b, k):
    h = np.clip(0.5 + 0.5 * (b - a) / k, 0.0, 1.0)
    return b * (1 - h) + a * h - k * h * (1 - h)


def smax(a, b, k):
    return -smin(-a, -b, k)


def icosphere(level):
    """Unit directions (N,3) and triangles (M,3), outward winding."""
    t = (1.0 + 5.0 ** 0.5) / 2.0
    v = np.array([(-1, t, 0), (1, t, 0), (-1, -t, 0), (1, -t, 0), (0, -1, t), (0, 1, t), (0, -1, -t), (0, 1, -t),
                  (t, 0, -1), (t, 0, 1), (-t, 0, -1), (-t, 0, 1)], dtype=np.float64)
    f = np.array([(0, 11, 5), (0, 5, 1), (0, 1, 7), (0, 7, 10), (0, 10, 11), (1, 5, 9), (5, 11, 4), (11, 10, 2),
                  (10, 7, 6), (7, 1, 8), (3, 9, 4), (3, 4, 2), (3, 2, 6), (3, 6, 8), (3, 8, 9), (4, 9, 5),
                  (2, 4, 11), (6, 2, 10), (8, 6, 7), (9, 8, 1)], dtype=np.int64)
    v = unit(v)
    for _ in range(level):
        e = np.concatenate([f[:, [0, 1]], f[:, [1, 2]], f[:, [2, 0]]])
        es = np.sort(e, axis=1)
        uq, inv = np.unique(es, axis=0, return_inverse=True)
        inv = np.asarray(inv).reshape(-1)
        mid = unit(v[uq[:, 0]] + v[uq[:, 1]])
        n0 = len(v)
        v = np.concatenate([v, mid])
        m = inv.reshape(3, -1) + n0
        a, b, c = f.T
        ab, bc, ca = m
        f = np.concatenate([np.stack([a, ab, ca], 1), np.stack([b, bc, ab], 1), np.stack([c, ca, bc], 1),
                            np.stack([ab, bc, ca], 1)])
    return v, f


def march(sdf, center, dirs, rmax, steps=180, iters=20):
    """Outermost surface point along each ray from center (the shape must be seen whole from center)."""
    center = np.asarray(center, dtype=np.float64)
    n = len(dirs)
    lo = np.zeros(n)
    hi = np.full(n, rmax)
    found = np.zeros(n, dtype=bool)
    prev = rmax
    for r in np.linspace(rmax, 0.0, steps)[1:]:
        inside = sdf(center + dirs * r) < 0
        new = inside & ~found
        lo[new] = r
        hi[new] = prev
        found |= new
        prev = r
        if found.all():
            break
    for _ in range(iters):
        mid = 0.5 * (lo + hi)
        inside = sdf(center + dirs * mid[:, None]) < 0
        lo = np.where(inside, mid, lo)
        hi = np.where(inside, hi, mid)
    return center + dirs * (0.5 * (lo + hi))[:, None]


def grad(sdf, p, eps=2e-4):
    g = np.zeros_like(p)
    for i in range(3):
        d = np.zeros(3)
        d[i] = eps
        g[:, i] = sdf(p + d) - sdf(p - d)
    return unit(g)


def sample_surface(verts, faces, n, rng):
    """n random points on a triangle mesh, spread evenly by area."""
    a, b, c = verts[faces[:, 0]], verts[faces[:, 1]], verts[faces[:, 2]]
    area = 0.5 * np.linalg.norm(np.cross(b - a, c - a), axis=1)
    idx = rng.choice(len(faces), size=n, p=area / area.sum())
    u = rng.random(n)
    v = rng.random(n)
    flip = u + v > 1
    u = np.where(flip, 1 - u, u)
    v = np.where(flip, 1 - v, v)
    return a[idx] + (b[idx] - a[idx]) * u[:, None] + (c[idx] - a[idx]) * v[:, None]


def make_strands(roots, normals, flow, length, lean, k, rng, jitter=0.18, bend=0.25, droop=0.0):
    """Strands (N,k,3). lean 0 = straight out of the skin, 1 = lying along flow. bend curls them further
    along flow toward the tip; droop pulls the tips down."""
    n = len(roots)
    flow = np.asarray(flow, dtype=np.float64)
    if flow.ndim == 1:
        flow = np.repeat(flow[None, :], n, 0)
    t = flow - normals * np.sum(flow * normals, axis=1, keepdims=True)
    tl = np.linalg.norm(t, axis=1, keepdims=True)
    t = t / np.maximum(tl, 1.0)  # never longer than 1; fades where flow is along the normal
    lean = np.asarray(lean, dtype=np.float64) * np.ones(n)
    d = unit(normals * (1 - lean[:, None]) + t * lean[:, None] + rng.normal(0, jitter, (n, 3)))
    s = np.linspace(0.0, 1.0, k)
    length = np.asarray(length, dtype=np.float64) * np.ones(n)
    pts = roots[:, None, :] + d[:, None, :] * (length[:, None, None] * s[None, :, None])
    curl = t * bend + np.array([0.0, 0.0, -droop])
    pts = pts + curl[:, None, :] * (length[:, None, None] * (s ** 2)[None, :, None])
    return pts


def strand_radius(n, k, r_root, r_tip, rng, vary=0.15):
    s = np.linspace(0.0, 1.0, k)
    base = r_root + (r_tip - r_root) * s
    return base[None, :] * (1 + rng.uniform(-vary, vary, (n, 1)))


def uv_sphere(r, segs=32, rings=16):
    """Sphere of radius r; poles on Z."""
    verts = [(0.0, 0.0, r)]
    for i in range(1, rings):
        a = math.pi * i / rings
        for j in range(segs):
            b = 2 * math.pi * j / segs
            verts.append((r * math.sin(a) * math.cos(b), r * math.sin(a) * math.sin(b), r * math.cos(a)))
    verts.append((0.0, 0.0, -r))
    faces = []
    for j in range(segs):
        faces.append((0, 1 + j, 1 + (j + 1) % segs))
    for i in range(rings - 2):
        for j in range(segs):
            a = 1 + i * segs + j
            b = 1 + i * segs + (j + 1) % segs
            faces.append((a, a + segs, b + segs, b))
    last = len(verts) - 1
    base = 1 + (rings - 2) * segs
    for j in range(segs):
        faces.append((last, base + (j + 1) % segs, base + j))
    return np.array(verts), faces


def ellipsoid_mesh(rx, ry, rz, segs=24, rings=12):
    v, f = uv_sphere(1.0, segs, rings)
    return v * np.array([rx, ry, rz]), f


def lid_wedge(r, upper, na=22, nf=18, span=165.0, k=1.05):
    """An eyelid: a slice of a shell around the eyeball. The hinge is the local X axis through the eye centre.
    Its leading edge lies in the horizontal plane (elevation 0); the object is then turned about X to open or close.
    Returns verts, quad faces and an 'edge' weight (1 at the lid margin) for the colour."""
    ro, ri = r * k, r * 1.004
    sgn = 1.0 if upper else -1.0
    verts, wts = [], []

    def pt(rad, al, ph):
        return (rad * math.sin(al), -rad * math.cos(al) * math.cos(ph), rad * math.cos(al) * math.sin(ph))

    alphas = [math.radians(-86 + 172 * i / (na - 1)) for i in range(na)]
    phis = [sgn * math.radians(span * (j / (nf - 1)) ** 1.3) for j in range(nf)]
    lip = sgn * math.radians(-5.0)
    # rows: inner margin, rounded lip, then the outer shell from the margin back
    rows = [[pt(ri, al, 0.0) for al in alphas], [pt((ro + ri) * 0.5, al, lip) for al in alphas]]
    rw = [1.0, 1.0]
    for j, ph in enumerate(phis):
        rows.append([pt(ro, al, ph) for al in alphas])
        rw.append(1.0 if j == 0 else (0.55 if j == 1 else 0.0))
    for row, w in zip(rows, rw):
        verts.extend(row)
        wts.extend([w] * na)
    faces = []
    for j in range(len(rows) - 1):
        for i in range(na - 1):
            a = j * na + i
            q = (a, a + 1, a + na + 1, a + na)
            faces.append(q if upper else q[::-1])
    return np.array(verts), faces, np.array(wts)


def lid_fur(r, upper, k, n, rng, colour):
    """Short sleek fur on the outside of an eyelid (same space as lid_wedge), lying back from the margin."""
    sgn = 1.0 if upper else -1.0
    al = np.arcsin(rng.uniform(-0.985, 0.985, n))
    ph = sgn * np.radians(rng.uniform(1.5, 112.0, n))
    nrm = np.stack([np.sin(al), -np.cos(al) * np.cos(ph), np.cos(al) * np.sin(ph)], 1)
    flow = sgn * np.stack([np.zeros(n), np.sin(ph), np.cos(ph)], 1)
    st = make_strands(nrm * r * k, nrm, flow, 0.0017 * rng.uniform(0.7, 1.1, n), 0.78, 4, rng, jitter=0.10, bend=0.2)
    return dict(pos=st, rad=strand_radius(n, 4, 0.00015, 0.00003, rng),
                col=rgba(colour[None, :] * rng.uniform(0.92, 1.06, (n, 1))))


# ------------------------------------------------------------------------------------------------ the character


def params(variant='little'):
    """Every number of the design in one place. 'mama' is the same build with her differences."""
    P = dict(
        variant=variant, size=1.0,
        face='#e8d2b0', chest='#f2e6cf', spine='#7a5a3e', paw='#5a3a2a', eye='#1c1210',
        skull=(0.0355, 0.0340, 0.0325),
        cheek_c=(0.0190, -0.0110, -0.0130), cheek_r=0.0175,
        sn_a=(0.0, -0.0240, -0.0100), sn_b=(0.0, -0.0460, -0.0050), sn_ra=0.0140, sn_rb=0.0074,
        nose_r=(0.0054, 0.0048, 0.0046),
        eye_r=0.0098, eye_az=29.0, eye_el=13.0, eye_depth=0.72, eye_toe=16.0, lid_k=1.05,
        ear_c=(0.0310, -0.0040, 0.0200), ear_r=(0.0105, 0.0034, 0.0115),
        cut_front=(-0.050, -0.0085), cut_back=(-0.027, -0.0125), cut_curl=0.0032, jaw_back=-0.0210,
        jaw_front=-0.0425, hinge=(0.0, -0.0210, -0.0100),
        body_a=((0.0, 0.0080, 0.0), (0.0460, 0.0520, 0.0430)),
        body_b=((0.0, -0.0220, 0.0020), (0.0380, 0.0360, 0.0370)),
        hip=(0.0, 0.0300, -0.0360), neck=(0.0, -0.0400, 0.0160),
        shoulder=(0.0230, -0.0300, -0.0180), thigh=(0.0270, 0.0200, -0.0240),
        spine_len=0.0150, spine_len_head=0.0135, fur_len=0.0075,
        n_face=52000, n_head_spines=3400, n_body_fur=30000, n_body_under=9000, n_body_spines=7500,
    )
    if variant == 'mama':
        P.update(size=1.5, face='#e2c8a4', spine='#6a4a32', paw='#4a3020',
                 sn_b=(0.0, -0.0530, -0.0045), sn_ra=0.0135, sn_rb=0.0074,
                 eye_r=0.0082, eye_az=31.0, cut_front=(-0.057, -0.0082), jaw_front=-0.0480,
                 body_a=((0.0, 0.0080, 0.0), (0.0500, 0.0540, 0.0450)),
                 body_b=((0.0, -0.0220, 0.0020), (0.0410, 0.0370, 0.0390)))
    a, b = np.array(P['sn_a']), np.array(P['sn_b'])
    ax = unit(b - a)
    P['nose_c'] = tuple(float(x) for x in (b + ax * 0.0056 + np.array([0.0, 0.0, 0.0016])))
    return P


def mirror(c, side):
    return np.array([c[0] * side, c[1], c[2]])


def head_base(p, P):
    d = sd_ellipsoid(p, (0, 0, 0), P['skull'])
    for s in (-1, 1):
        d = smin(d, sd_sphere(p, mirror(P['cheek_c'], s), P['cheek_r']), 0.012)
    d = smin(d, sd_roundcone(p, P['sn_a'], P['sn_b'], P['sn_ra'], P['sn_rb']), 0.010)
    return d


def eye_centres(P):
    """Eye centres in head space (left = -X, right = +X): set a fixed depth under the un-carved surface."""
    out = {}
    for name, s in (('L', -1), ('R', 1)):
        az, el = math.radians(P['eye_az']), math.radians(P['eye_el'])
        d = np.array([s * math.sin(az) * math.cos(el), -math.cos(az) * math.cos(el), math.sin(el)])
        surf = march(lambda q: head_base(q, P), (0, 0, 0), d[None, :], 0.08)[0]
        out[name] = surf - d * P['eye_r'] * P['eye_depth']
    return out


def cut_z(y, P):
    """Height of the mouth line along the snout: rises to the front, and curls up at the corners (a built-in smile)."""
    (yf, zf), (yb, zb) = P['cut_front'], P['cut_back']
    z = zb + (zf - zb) * (y - yb) / (yf - yb)
    k = P['cut_curl'] / (P['jaw_back'] - yb) ** 2
    return z + k * np.maximum(0.0, y - yb) ** 2


def jaw_region(p, P):
    """Negative inside the block of the snout that belongs to the lower jaw."""
    y, z = p[..., 1], p[..., 2]
    below = z - cut_z(y, P)
    back = y - P['jaw_back']
    env = sd_roundcone(p, P['sn_a'], P['sn_b'], P['sn_ra'] + 0.0015, P['sn_rb'] + 0.0040)
    return np.maximum(np.maximum(below, back), env)


def head_upper(p, P, eyes):
    d = head_base(p, P)
    for c in eyes.values():
        d = smax(d, -(np.linalg.norm(p - c, axis=-1) - P['eye_r'] * (P['lid_k'] + 0.03)), 0.0018)
    return smax(d, -jaw_region(p, P), 0.0010)


def jaw_sdf(p, P):
    d = smax(head_base(p, P), jaw_region(p, P), 0.0010)
    return smax(d, P['jaw_front'] - p[..., 1], 0.0030)


def body_sdf(p, P):
    (ca, ra), (cb, rb) = P['body_a'], P['body_b']
    return smin(sd_ellipsoid(p, ca, ra), sd_ellipsoid(p, cb, rb), 0.020)


def rgba(c):
    return np.concatenate([c, np.ones((len(c), 1))], axis=1).astype(np.float32)


def head_fields(p, P, eyes):
    """Colour and fur recipe at points p on the head (head space)."""
    n = len(p)
    d = unit(p)
    hood = d @ unit(np.array([0.0, 0.75, 0.66])) - (0.08 + 0.12 * d[:, 0] ** 2)
    w_spine = smoothstep(-0.02, 0.06, hood)
    w_fringe = smoothstep(-0.24, -0.02, hood) * (1 - w_spine)
    nose = np.array(P['nose_c'])
    dnose = np.linalg.norm(p - nose, axis=1)
    deye = np.minimum(np.linalg.norm(p - eyes['L'], axis=1), np.linalg.norm(p - eyes['R'], axis=1))
    r = P['eye_r']
    face, light, chest = lin(P['face']), lin('#f7ecd6'), lin(P['chest'])
    tan, under, blush = lin('#c49d73'), lin(P['spine']) * 0.45, lin('#f0b29c')
    col = np.repeat(face[None, :], n, 0)
    col = mix(col, light, 0.8 * (1 - smoothstep(0.010, 0.030, dnose)))
    col = mix(col, light, 0.25 * (1 - smoothstep(1.15 * r, 2.0 * r, deye)))
    bl = np.zeros(n)
    for s in (-1, 1):
        bc = np.array([s * 0.0255, -0.0185, -0.0100])
        bl = np.maximum(bl, np.exp(-np.sum((p - bc) ** 2, axis=1) / (2 * 0.0085 ** 2)))
    col = mix(col, blush, 0.42 * bl)
    col = mix(col, chest, 0.8 * smoothstep(-0.012, -0.026, p[:, 2]) * smoothstep(-0.040, -0.026, p[:, 1]))
    col = mix(col, tan, 0.85 * w_fringe)
    col = mix(col, under, w_spine)
    length = 0.0013 + (0.0034 - 0.0013) * smoothstep(0.008, 0.034, dnose)
    fluff = smoothstep(-0.004, -0.020, p[:, 2]) * smoothstep(0.008, 0.020, np.abs(p[:, 0]))
    length = length + 0.0030 * fluff + 0.0036 * w_fringe
    length = length * (0.55 + 0.45 * smoothstep(1.1 * r, 1.8 * r, deye))
    length = np.where(w_spine > 0.5, 0.0040, length)
    flow = unit(p - nose)
    for c in eyes.values():
        de = np.linalg.norm(p - c, axis=1)
        flow = flow + 1.6 * (1 - smoothstep(1.1 * r, 2.0 * r, de))[:, None] * unit(p - c)
    flow = unit(flow + np.array([0.0, 0.5, 0.0]) * w_spine[:, None])
    lean = 0.62 + 0.18 * (1 - smoothstep(0.010, 0.028, dnose)) - 0.14 * fluff
    return dict(col=col, hood=hood, w_spine=w_spine, w_fringe=w_fringe, dnose=dnose, deye=deye, length=length,
                flow=flow, lean=lean)


def build_head(P, seed=3):
    """Head skin mesh, face fur and head spines, all in head space."""
    rng = np.random.default_rng(seed)
    eyes = eye_centres(P)
    dirs, faces = icosphere(6)
    sdf = lambda q: head_upper(q, P, eyes)  # noqa: E731
    v = march(sdf, (0, 0, 0), dirs, 0.085)
    F = head_fields(v, P, eyes)
    inside = head_base(v, P) < -0.0007           # carved surfaces: eye sockets and the roof of the mouth
    roof = inside & (v[:, 2] < cut_z(v[:, 1], P) + 0.002) & (v[:, 1] > P['jaw_front'] + 0.001) & (F['deye'] > P['eye_r'] * 1.3)
    col = F['col'].copy()
    col[roof] = lin('#8c3b3e')
    out = dict(eyes=eyes, verts=v, faces=faces, col=rgba(col))

    # fur: short velvet on the snout, longer on cheeks and at the edge of the spines
    pts = sample_surface(v, faces, int(P['n_face'] * 1.25), rng)
    ok = np.abs(sdf(pts)) < 0.0006
    ok &= head_base(pts, P) > -0.0007
    pts = pts[ok]
    G = head_fields(pts, P, eyes)
    keep = (G['deye'] > P['eye_r'] * (P['lid_k'] + 0.05)) & (G['dnose'] > 0.0042)
    pts = pts[keep]
    G = {k: a[keep] for k, a in G.items()}
    nrm = grad(sdf, pts)
    k = 4
    L = G['length'] * rng.uniform(0.75, 1.15, len(pts))
    st = make_strands(pts, nrm, G['flow'], L, G['lean'], k, rng, jitter=0.16, bend=0.30, droop=0.10)
    out['fur'] = dict(pos=st, rad=strand_radius(len(pts), k, 0.00014, 0.00003, rng),
                      col=rgba(G['col'] * rng.uniform(0.92, 1.06, (len(pts), 1))))

    # spines on the hood
    pts = sample_surface(v, faces, P['n_head_spines'] * 4, rng)
    G = head_fields(pts, P, eyes)
    keep = (G['hood'] > 0.02) & (np.abs(sdf(pts)) < 0.0006)
    pts = pts[keep][:P['n_head_spines']]
    hood = G['hood'][keep][:P['n_head_spines']]
    nrm = grad(sdf, pts)
    L = (0.0062 + (P['spine_len_head'] - 0.0062) * smoothstep(0.02, 0.22, hood)) * rng.uniform(0.85, 1.12, len(pts))
    st = make_strands(pts, nrm, np.array([0.0, 0.95, 0.30]), L, 0.42, 3, rng, jitter=0.13, bend=0.12)
    out['spines'] = dict(pos=st, rad=strand_radius(len(pts), 3, 0.00050, 0.00007, rng),
                         col=rgba(np.ones((len(pts), 3)) * rng.uniform(0.85, 1.1, (len(pts), 1))))

    # whiskers
    wp, wr = [], []
    for s in (-1, 1):
        for i in range(6):
            root = np.array([s * (0.0072 + 0.001 * (i % 2)), -0.0405 + 0.0028 * (i // 2), -0.0085 + 0.0022 * (i % 3)])
            dr = unit(np.array([s * 1.0, -0.25 + 0.2 * rng.random(), -0.10 + 0.25 * rng.random()]))
            ln = 0.014 + 0.007 * rng.random()
            t = np.linspace(0, 1, 6)
            wp.append(root[None, :] + dr[None, :] * (ln * t)[:, None]
                      + np.array([0.0, 0.35, -0.30])[None, :] * (ln * t ** 2)[:, None])
            wr.append(0.00009 + (0.00002 - 0.00009) * t)
    out['whiskers'] = dict(pos=np.array(wp), rad=np.array(wr), col=rgba(np.repeat(lin('#fbf3e2')[None, :], 12, 0)))
    return out


def build_jaw(P, seed=5):
    rng = np.random.default_rng(seed)
    eyes = eye_centres(P)
    dirs, faces = icosphere(5)
    sdf = lambda q: jaw_sdf(q, P)  # noqa: E731
    ym = 0.5 * (P['jaw_back'] + P['jaw_front']) - 0.002
    c = np.array([0.0, ym, cut_z(ym, P) - 0.0045])
    v = march(sdf, c, dirs, 0.05)
    F = head_fields(v, P, eyes)
    inner = head_base(v, P) < -0.0007
    col = mix(F['col'], lin(P['chest']), 0.5 * np.ones(len(v)))
    col[inner] = lin('#8c3b3e')
    out = dict(verts=v, faces=faces, col=rgba(col), centre=c)
    pts = sample_surface(v, faces, 16000, rng)
    ok = (np.abs(sdf(pts)) < 0.0005) & (head_base(pts, P) > -0.0006)
    pts = pts[ok]
    G = head_fields(pts, P, eyes)
    nrm = grad(sdf, pts)
    L = np.minimum(G['length'], 0.0026) * rng.uniform(0.75, 1.1, len(pts))
    st = make_strands(pts, nrm, G['flow'], L, 0.7, 4, rng, jitter=0.15, bend=0.25, droop=0.1)
    fc = mix(G['col'], lin(P['chest']), 0.5 * np.ones(len(pts)))
    out['fur'] = dict(pos=st, rad=strand_radius(len(pts), 4, 0.00016, 0.00003, rng),
                      col=rgba(fc * rng.uniform(0.92, 1.06, (len(pts), 1))))
    return out


def body_fields(p, P):
    n = len(p)
    d = unit(p)
    hood = d @ unit(np.array([0.0, 0.30, 0.954])) + 0.08
    w_spine = smoothstep(-0.03, 0.06, hood)
    w_skirt = smoothstep(-0.30, -0.03, hood) * (1 - w_spine)
    chest, tan, under = lin(P['chest']), lin('#c9a67c'), lin(P['spine']) * 0.45
    col = np.repeat(chest[None, :], n, 0)
    col = mix(col, lin(P['face']), 0.5 * smoothstep(0.1, 0.6, d[:, 1]))   # warmer toward the rump
    col = mix(col, tan, 0.8 * w_skirt)
    col = mix(col, under, w_spine)
    return dict(col=col, hood=hood, w_spine=w_spine, w_skirt=w_skirt)


def build_body(P, seed=7):
    rng = np.random.default_rng(seed)
    dirs, faces = icosphere(5)
    sdf = lambda q: body_sdf(q, P)  # noqa: E731
    v = march(sdf, (0, 0, 0), dirs, 0.09)
    F = body_fields(v, P)
    out = dict(verts=v, faces=faces, col=rgba(F['col']))

    # soft pale fur on the chest, belly and the skirt under the spines; short dark fuzz between the spines
    n1, n2 = P['n_body_fur'], P['n_body_under']
    pts = sample_surface(v, faces, int((n1 + n2) * 1.6), rng)
    G = body_fields(pts, P)
    pale = np.where(G['w_spine'] < 0.5)[0][:n1]
    dark = np.where(G['w_spine'] >= 0.5)[0][:n2]
    idx = np.concatenate([pale, dark])
    pts = pts[idx]
    G = {k: a[idx] for k, a in G.items()}
    nrm = grad(sdf, pts)
    isd = G['w_spine'] >= 0.5
    L = np.where(isd, 0.0045, P['fur_len'] * (1 + 0.35 * G['w_skirt'])) * rng.uniform(0.7, 1.15, len(pts))
    st = make_strands(pts, nrm, np.array([0.0, 0.45, -0.80]), L, 0.50, 4, rng, jitter=0.20, bend=0.30, droop=0.12)
    out['fur'] = dict(pos=st, rad=strand_radius(len(pts), 4, 0.00019, 0.00003, rng),
                      col=rgba(G['col'] * rng.uniform(0.92, 1.06, (len(pts), 1))))

    pts = sample_surface(v, faces, P['n_body_spines'] * 3, rng)
    G = body_fields(pts, P)
    keep = G['hood'] > 0.0
    pts = pts[keep][:P['n_body_spines']]
    hood = G['hood'][keep][:P['n_body_spines']]
    nrm = grad(sdf, pts)
    L = (0.0090 + (P['spine_len'] - 0.0090) * smoothstep(0.0, 0.30, hood)) * rng.uniform(0.85, 1.12, len(pts))
    st = make_strands(pts, nrm, np.array([0.0, 1.0, -0.10]), L, 0.50, 3, rng, jitter=0.13, bend=0.12)
    out['spines'] = dict(pos=st, rad=strand_radius(len(pts), 3, 0.00055, 0.00007, rng),
                         col=rgba(np.ones((len(pts), 3)) * rng.uniform(0.85, 1.1, (len(pts), 1))))
    return out


def build_paw(P):
    """A small dark paw with four round toes; toes point to -Y, the sole is at z = -0.0045."""
    dirs, faces = icosphere(5)

    def sdf(q):
        d = sd_ellipsoid(q, (0, 0, 0), (0.0068, 0.0085, 0.0045))
        for a in (-39, -13, 13, 39):
            ar = math.radians(a)
            d = smin(d, sd_sphere(q, (0.0066 * math.sin(ar), -0.0090 * math.cos(ar) - 0.0012, -0.0008), 0.0019), 0.0012)
        return d
    v = march(sdf, (0, 0, 0), dirs, 0.03)
    paw = lin(P['paw'])
    pad = lin('#7a4e40')
    w = smoothstep(-0.0010, -0.0036, v[:, 2])
    col = mix(np.repeat(paw[None, :], len(v), 0), pad, 0.45 * w)
    return dict(verts=v, faces=faces, col=rgba(col))


def build_limb(P, length=0.03, radius=0.0075, colour=None, seed=11, n_fur=1400):
    """A short leg: a capsule along +Y from its joint (y=0) to y=length, with fur."""
    rng = np.random.default_rng(seed)
    v, f = uv_sphere(1.0, 16, 10)
    v = v[:, [0, 2, 1]] * radius            # poles on Y
    v[:, 1] = np.where(v[:, 1] > 0, v[:, 1] + length - radius, v[:, 1])   # the far tip is at y = length
    f = [tuple(reversed(q)) for q in f]     # swapping two axes flipped the winding
    c = lin(colour or P['face'])
    out = dict(verts=v, faces=f, col=rgba(np.repeat(c[None, :], len(v), 0)))
    th = rng.uniform(0, 2 * math.pi, n_fur)
    yy = rng.uniform(0.0, length - 0.25 * radius, n_fur)      # the round end is furred too (a soft cuff at the paw)
    h = np.maximum(0.0, yy - (length - radius))
    rho = np.sqrt(np.maximum(radius ** 2 - h ** 2, 0.0))
    nrm = np.stack([rho * np.cos(th), h, rho * np.sin(th)], 1) / radius
    pts = np.stack([rho * np.cos(th), yy, rho * np.sin(th)], 1)
    st = make_strands(pts, nrm, np.array([0.0, 1.0, 0.0]), 0.0042 * rng.uniform(0.7, 1.1, n_fur), 0.6, 4, rng)
    out['fur'] = dict(pos=st, rad=strand_radius(n_fur, 4, 0.00018, 0.00003, rng),
                      col=rgba(c[None, :] * rng.uniform(0.92, 1.06, (n_fur, 1))))
    return out


def build_ear(P, side):
    v, f = ellipsoid_mesh(*P['ear_r'], segs=20, rings=12)
    rr = np.sqrt((v[:, 0] / P['ear_r'][0]) ** 2 + (v[:, 2] / P['ear_r'][2]) ** 2)
    front = smoothstep(0.0, -0.4, v[:, 1] / P['ear_r'][1])
    # a shallow dish on the front face
    v[:, 1] += front * (1 - smoothstep(0.0, 0.85, rr)) * P['ear_r'][1] * 0.9
    outer, inner = lin('#cfa684'), lin('#e9a593')
    col = mix(np.repeat(outer[None, :], len(v), 0), inner, front * (1 - smoothstep(0.45, 0.9, rr)))
    return dict(verts=v, faces=f, col=rgba(col))
