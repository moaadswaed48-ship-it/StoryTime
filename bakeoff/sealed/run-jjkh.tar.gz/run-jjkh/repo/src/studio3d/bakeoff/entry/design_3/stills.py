"""Design 3: the three design stills of Little Hedgehog (run through blender.sh).

    blender.sh d3 --sub design_3 --sub-cap 720 -- --python .../design_3/stills.py -- --out WS/out/design_3 \
        [--res 1280x720] [--samples 24] [--only a,b,c] [--fur 1.0] [--family 1]
"""
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import bpy  # noqa: E402
from mathutils import Vector  # noqa: E402

import hedgehog  # noqa: E402
import patch  # noqa: E402

argv = sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else []


def arg(k, d):
    return argv[argv.index('--' + k) + 1] if ('--' + k) in argv else d


def main():
    t0 = time.time()
    out = arg('out', '/tmp')
    res = tuple(int(x) for x in arg('res', '1280x720').split('x'))
    only = arg('only', 'a,b,c').split(',')
    for ob in list(bpy.data.objects):
        bpy.data.objects.remove(ob, do_unlink=True)
    sc = bpy.context.scene
    patch.build_patch()
    patch.evening_light()
    patch.render_settings(int(arg('samples', '24')), res)
    rig = hedgehog.build_hedgehog('little', fur=float(arg('fur', '1.0')))
    root = rig.o['root']
    print('D3 build %.1f s' % (time.time() - t0), flush=True)

    def shoot(tag, cam):
        sc.camera = cam
        t1 = time.time()
        sc.render.filepath = os.path.join(out, 'still_%s.png' % tag)
        bpy.ops.render.render(write_still=True)
        print('D3 still %s %.1f s' % (tag, time.time() - t1), flush=True)

    def report(tag):
        hp = rig.head_point()
        print('D3 %s head %s nose %s body %s pawFL %s pawFR %s' % (
            tag, [round(v, 4) for v in hp], [round(v, 4) for v in rig.head_point(rig.P['nose_c'])],
            [round(v, 4) for v in rig.o['body'].matrix_world.translation],
            [round(v, 4) for v in rig.o['pawFL'].matrix_world.translation],
            [round(v, 4) for v in rig.o['pawFR'].matrix_world.translation]), flush=True)

    # (a) medium shot: sitting up, paws by his cheeks, laughing; three-quarter toward the low sun
    if 'a' in only:
        root.rotation_euler = (0, 0, -0.30)
        rig.pose(**hedgehog.POSES['sit_giggle'])
        hp = rig.head_point()
        cam = patch.camera('CamA', (0.06, -0.47, 0.092), (hp.x * 0.5 + 0.012, 0.0, 0.074), 50, 4.0, rig.eye_point('R'))
        rig.look_at(cam.location + Vector((-0.02, 0, 0.0)))
        report('a')
        shoot('a_medium', cam)

    # (b) close-up of the face: wide curious eyes at the camera, a small open smile
    if 'b' in only:
        root.rotation_euler = (0, 0, -0.25)
        rig.pose(**hedgehog.POSES['sit_curious'])
        hp = rig.head_point()
        cam = patch.camera('CamB', (hp.x + 0.034, hp.y - 0.460, hp.z + 0.024), (hp.x - 0.002, hp.y, hp.z - 0.005), 85, 8.0,
                           rig.eye_point('R') + Vector((0, -0.008, 0)))
        rig.look_at(cam.location)
        report('b')
        shoot('b_face', cam)

    # (c) second pose: on all fours, nose up, eyes closed, sniffing the evening air
    if 'c' in only:
        root.rotation_euler = (0, 0, -1.02)
        rig.pose(**hedgehog.POSES['sniff'])
        hp = rig.head_point()
        cam = patch.camera('CamC', (0.03, -0.43, 0.060), (-0.030, 0.0, 0.055), 50, 4.0, hp)
        report('c')
        shoot('c_sniff', cam)
    # optional test picture (not one of the three stills): the same build as Mama, beside Little
    if arg('family', '0') == '1':
        try:
            root.location = (-0.08, -0.05, 0)
            root.rotation_euler = (0, 0, -0.9)
            rig.pose(**hedgehog.POSES['stand'])
            mama = hedgehog.build_hedgehog('mama', fur=0.7)
            mama.o['root'].location = (0.10, 0.06, 0)
            mama.o['root'].rotation_euler = (0, 0, -0.6)
            mama.pose(**hedgehog.POSES['stand'])
            mama.look_at(rig.head_point())
            rig.look_at(mama.head_point())
            sc.render.resolution_x, sc.render.resolution_y = 640, 360
            sc.cycles.samples = 12
            cam = patch.camera('CamF', (0.0, -0.80, 0.10), (0.02, 0.0, 0.07), 50, 5.6, mama.head_point())
            shoot('test_family', cam)
        except Exception as e:  # a failed test picture must not lose the stills
            print('D3 family failed %r' % (e,), flush=True)
    print('D3 total %.1f s' % (time.time() - t0), flush=True)


main()
