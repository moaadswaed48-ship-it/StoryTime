# PROGRESS (kept current while building)

Roles so far: three designers and two judges chose design 3; one builder made the whole film from it; two reviewers
listed ten blockers; this last pass (the "fix" role) worked through them alone.
Blender budget of the fix pass: 1,440 s (`--sub fix --sub-cap 1440` on every call).

## State: the film is complete and the review's blockers have been worked through

- All seven shots build and draw (`film.py`). Every shot is keyed over its `render_first .. render_last`.
- Sound: `sound.mjs` writes exactly 1,440,000 stereo sample frames at 48 kHz (about -16.7 LUFS, peak -2.5 dB).
  Two cues moved with the picture in the fix pass: Mama's sniffs in S6 (now at 550, 560, 574, 586) and a new
  giggle at 577 for Little's laugh.
- `README.md` is current: what was built, what the review changed, decisions, known flaws, five scores.
- Speed check: the third and last attempt, run after the last change, did NOT pass (predicted 20,484 s, limit
  19,440 s) on a machine that another job was using. See the last section of this file.

## What the fix pass changed (files: `film.py`, `hedgehog.py`, `hh_geom.py`, `garden.py`, `sound.mjs`, `lookdev.py`)

| Blocker | Fix | Picture that shows it (`WS/out/fix/`) |
|---|---|---|
| Closed eyes were blank pale discs (S6 end, S7, S3) | Dark lash line and lash ridge on the lids, lids no paler than the face, sleeping lids meet lower-middle of the eye, less head tip in the sniff | `r4_all.jpg` (S7 625, 684), `r1_s3.jpg` (S3 300) |
| S6 read as looming; Mama faceless, Little cold and sad | Lens behind and beside Mama (40 to 63 degrees off the boot), her face in view, Little's head out of the boot, wide eyes, open laugh, warm light on both, brighter catchlight, boot loop off in this shot | `r3_s6.jpg` (576, 600 at final quality), `r4_all.jpg` (600, 625) |
| S2 peekaboo did not read; stiff body | Paws on the eye-to-lens lines, lids shut under them, one wide eye peeks, cheek paw; rocking and a count-bounce | `r1_s2.jpg` (109, 140, 168, 204), `r4_all.jpg` (140) |
| S2 rubber-glove paws, pale "tusks" at the elbows | Both ends of the arm pieces furred, darker skin under the fur; paws with short fur on the back and bare toes | `r4_all.jpg` (140), `r3_rest.jpg` (140, 168 crops) |
| S3 slit pupils, dozy lids, nose on the eye line | Wide pupil and narrow dark iris, lids at 54 with level corners, smaller lower nose, blink moved off his look at the lens | `r1_s3.jpg`, `r3_rest.jpg` (311 at final quality) |
| S7 was about the watering can; pair small and grey | Pair curled toward each other with faces to the lens, warm pool of light, 20 mm lens starting close and ending 33 cm up, no can in this shot, low far hedges so stars show | `r4_all.jpg` (625, 684) |
| S1 weak opening | Roof tiles, evening air on far ground and hedges, warmer window, owl leaves the picture whole | `r3_rest.jpg` (frame 1), `r1_rest.jpg` (108) |
| S5 black specks; owl easy to miss | Unlit fireflies are not drawn; a light only the owl receives, bigger head turn and ruffle | `r4_all.jpg` (492: eyes shut, owl about 12.6% of the height) |

## What was looked at in the fix pass

- `r1` (640x360, final samples): S2 109/140/168/204, S3 240/300/311, S1 1/108, S5 474, S6 562 to 625, S7 625/650/684.
- `r2` (640x360): S1 1/54, S6 548/562/585/600, S7 684. `r3` (1280x720, final quality): S1 1, S2 140/168, S3 311,
  S6 576/600, S7 672/720. `r4` (640x360, after the last changes): S2 140, S5 492, S6 600/625, S7 625/684.
- Not looked at after the last changes at full size: S4 (only the lids, paws and nose of Little changed there).
- Nothing was watched moving. The motion strips in `WS/out/t/m1` are older than every change above.

## Decisions made in the fix pass

- S6 is not a strict over-the-shoulder shot any more: a view of Mama's back was the reviewers' second blocker.
- S7: 20 mm lens, small rise, the tilt does most of the move; the can and the stone are not built in this shot;
  the far hedge row is half height in this shot.
- S5 samples went from 20 to 17 to pay for the closer hedgehogs in S7 (its picture is mostly wall and sky).
- Eyes are darker than before (a narrow iris): they live by the catchlight, so S6 uses a brighter one at night.

## Ideas for whoever continues (not done)

- Watch the film moving: Mama's count-bounce, the S6 camera drift and Little's laugh were checked on stills only.
- Listen to the sound: it was built by numbers only.
- The boot reads as a clay pot in S4; fur is closer to felt than to the reference; the scurry's paws slide.
- A closed eye still shows the round outline of its socket close up (start of S7).

## Speed check and budgets after the fix pass

- **The speed check did not pass on its third and last attempt**, run after the last change to the film:
  predicted 20,484 s against the 19,440 s limit (5.4% over). Numbers: `WS/gate/bench.json`; pictures of the final
  code: `WS/gate/sheet-3.jpg`. Attempts 1 and 2 (before the fix pass) had passed (16,325 s and 16,969 s).
- Why: the machine was shared during the attempt. A Lighthouse and Chrome job that is not part of this film ran
  beside it. Blender used 1,998 processor-seconds in attempt 3 against 1,946 in attempt 2 (2.7% more work), but
  the clock time was 632 s against 533 s (19% more). The two shots the fix pass hardly touched came out 20 to
  22% slower than in attempt 2 (S3 27.5 s a picture against 22.9; S4 29.5 against 24.1), and S5 took as long with
  17 samples as it had with 20. Taking that 20% off gives an estimate of about 17,000 s for a quiet machine, which
  would pass. This is an estimate, not a measurement: no attempt is left to measure it.
- What follows from the rule: without a pass the film is drawn with its samples multiplied by 19,440 / 20,484
  (0.95), unless the organisers measure again.
- By shot in attempt 3 (seconds a picture, predicted seconds): S1 22.1, 2,396; S2 35.7, 3,434; S3 27.5, 3,311;
  S4 29.5, 2,837; S5 20.8, 2,251; S6 35.7, 3,650; S7 25.4, 2,606.
- Budgets: the fix pass used 1,357 s of its 1,440 s (four of its eight calls ran while the machine was loaded
  and cost two to four times their normal time). The whole team has used 5,410 s of the 9,000 s test budget.
  Speed check: 3 of 3 attempts, 1,682 s of 2,700 s.
- Checked after the speed check: frame 684 was drawn at final quality and compared with frame 720 of the speed
  check. The owl's part of the picture differs by 0.03 of 255 on average (largest 1) and Mama's and Little's faces
  by under 0.5 (firefly light): camera and cast are still from 684.
