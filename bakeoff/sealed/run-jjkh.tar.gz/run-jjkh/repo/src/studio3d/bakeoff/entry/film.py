"""Where Is Little Hedgehog? The 30-second film: seven shots, built and keyed in code (Blender 5.2, Cycles).

Run through the wrapper only (see docs/film/bakeoff/BRIEF.md):

    bash REPO/studio/scripts/bakeoff/blender.sh LABEL -- --python REPO/src/studio3d/bakeoff/entry/film.py -- \
        --out DIR --frames 168 --shots S2 --quality preview --res 640x360

--quality preview halves the samples and thins the fur; it is for looking at staging and movement cheaply.
Every shot builds its own set, cast, light, camera and keys from nothing; no picture depends on another.
"""
import math
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..'))
sys.path.insert(0, HERE)
from common import harness  # noqa: E402

import bpy  # noqa: E402
from mathutils import Vector  # noqa: E402

import critters  # noqa: E402
import garden as G  # noqa: E402
import hedgehog as hh  # noqa: E402
import kit  # noqa: E402
from kit import kf, lerp, pulse, ramp01, settle, smooth  # noqa: E402

RAD = math.radians
TAU = 2 * math.pi

# samples for --quality final, per shot (tuned against the speed check), and the fur share of each character
SAMPLES = dict(S1=13, S2=12, S3=12, S4=15, S5=17, S6=14, S7=14)
EXPOSURE = 0.45
NIGHT_MOON, NIGHT_AMB, NIGHT_WINDOW, NIGHT_GLOW, DUSK_WINDOW, DUSK_GLOW = 2.2, 0.34, 380.0, 3.0, 60.0, 1.25
# where nothing grows: under the boot, the can and the stone
BARE = [(1.28, 0.97, 0.15), (1.38, 1.08, 0.12), (G.CAN[0], G.CAN[1], 0.10), (G.STONE[0], G.STONE[1], 0.07)]


# ================================================================================================ shared pieces
def is_final(ctx):
    return ctx.quality == 'final'


def fur_of(ctx, f):
    return f if is_final(ctx) else max(0.2, f * 0.5)


def frames(ctx):
    return range(ctx.render_first, ctx.render_last + 1)


def build_set(boot=True, can=True, bush=True, house=True, hedge=1.0):
    """Everything that stands in the garden in every shot. Returns handles."""
    out = {}
    G.ground()
    G.stone_wall()
    G.backdrop(low=hedge)
    if house:
        out['window'], out['glow'] = G.house(glow=DUSK_GLOW)
    if bush:
        G.bush()
    if boot:
        out['boot'] = G.old_boot()
    if can:
        G.watering_can()
        out['stone'], out['stone_top'] = critters.build_stone('Stone', (G.STONE[0], G.STONE[1], 0.0))
    return out


def dusk_light(sky, sun=4.8, amb=0.42, fill_at=None, fill=6.0, rim=2.6):
    """Evening: a low golden sun from the left, a peach rim from behind on the other side, a cool sky, and a soft
    warm bounce from the lens side so no face is lost in shade."""
    s = kit.sun_lamp('Sun', G.SUN_DIR, sun, '#ffb070', 3.0)
    kit.sun_lamp('Rim', G.RIM_DIR, rim, '#ffc9a6', 6.0)
    sky.set_night(0.0)
    sky.stars.outputs[0].default_value = 0.0
    sky.amb.outputs[0].default_value = amb
    f = None
    if fill_at is not None:
        pos, tgt = fill_at
        f = kit.area_lamp('Bounce', pos, tgt, fill, '#ffd2ac', size=0.9)
    return s, f


def night_light(sky, st, moon=NIGHT_MOON, amb=NIGHT_AMB, window=NIGHT_WINDOW, glow=NIGHT_GLOW):
    """Night: a soft cool moon from the front left, a deep blue sky with stars, and the window as the warm light."""
    m = kit.sun_lamp('Moon', G.MOON_DIR, moon, '#a9c0ff', 7.0)
    sky.set_night(1.0)
    sky.stars.outputs[0].default_value = 1.0
    sky.amb.outputs[0].default_value = amb
    if 'window' in st:
        st['window'].data.energy = window
        st['glow'].default_value = glow
    return m


def finish(ctx, samples=None, blur=False, bloom=True):
    s = samples or SAMPLES[ctx.id]
    if not is_final(ctx):
        s = max(4, s // 2)
    kit.render_settings(samples=s, exposure=EXPOSURE, blur=blur, quick_bvh=not is_final(ctx))
    if bloom:
        kit.bloom(threshold=1.5, strength=0.22, size=0.35)


def blink_amount(f, at, half=2.6):
    return max([pulse(f, a, half) for a in at] + [0.0])


def with_blink(pose, c, closed=(-12.0, -16.0)):
    """Close the lids of a pose by c (0..1)."""
    if c <= 0:
        return pose
    p = dict(pose)
    up, lo = p.get('lid_up', 52.0), p.get('lid_lo', -50.0)
    up = up if isinstance(up, (int, float)) else up[0]
    lo = lo if isinstance(lo, (int, float)) else lo[0]
    p['lid_up'] = lerp(up, closed[0], c)
    p['lid_lo'] = lerp(lo, closed[1], c)
    return p


def trot(phase, amp=0.016, lift=0.009, base=None, spread=1.0):
    """Paws of a quick diagonal trot (FL with HR, FR with HL). phase in radians."""
    base = base or hh.STAND_PAWS
    out = {}
    for k, off in (('FL', 0.0), ('HR', 0.0), ('FR', math.pi), ('HL', math.pi)):
        b = base[k]
        rot = b[3:] if len(b) > 3 else (0, 0, 0)
        ph = phase + off
        sw = max(0.0, -math.sin(ph))
        out[k] = (b[0] * spread, b[1] - amp * math.cos(ph), b[2] + lift * sw, rot[0] + 28.0 * sw, rot[1], rot[2])
    return out


def hop(u, height=0.022):
    """One little bounce, u in 0..1: crouch, spring, hang, land, settle. Returns (lift, stretch_z)."""
    if u <= 0 or u >= 1:
        return 0.0, 1.0
    if u < 0.22:
        k = u / 0.22
        return 0.0, 1.0 - 0.13 * math.sin(k * math.pi * 0.5)
    if u < 0.78:
        k = (u - 0.22) / 0.56
        return height * 4 * k * (1 - k), 0.87 + 0.21 * kit.ease_out(k / 0.3) - 0.05 * k
    k = (u - 0.78) / 0.22
    return 0.0, 1.0 - 0.13 * math.sin(math.pi * k ** 0.6) * (1 - 0.25 * k) + 0.03 * (1 - k) ** 2


def hops(f, starts, length=11.0, height=0.022):
    lift, st = 0.0, 1.0
    for s in starts:
        a, b = hop((f - s) / length, height)
        if a or b != 1.0:
            lift, st = a, b
    return lift, st


def volume(sz):
    """Whole-puppet squash and stretch that keeps the volume."""
    k = 1.0 / math.sqrt(max(sz, 0.3))
    return (k, k, sz)


def heading(direction):
    """Yaw in degrees so a character (who faces -Y at yaw 0) faces the given (x, y) direction."""
    return math.degrees(math.atan2(direction[0], -direction[1]))


def catch_light(cam, things, dist, night=False):
    recv = []
    for t in things:
        recv += t.eye_objects()
    return kit.eye_light(cam, recv, dist, radiance=38.0 if night else 70.0)


# ================================================================================================ Mama's counting
MAMA_YAW = 15.0


def mama_count(mama, f, look_cam):
    """Mama from the end of S1 through S2 (film frames 60..204): she sits up, hides her eyes behind her paws (her
    lids shut under them), counts with little nods and bounces, peeks with one wide eye at 168, and hides again.
    look_cam is where the lens is: the paws are held on the lines from her eyes to it, so they hide her eyes."""
    sit = ramp01(f, 84, 104)                      # down on all fours -> sitting up
    cover = ramp01(f, 104, 119)                   # paws from the chest to the eyes
    peek = ramp01(f, 152, 163) * (1 - ramp01(f, 183, 192))      # the paw on her L side slides away
    counts = (126, 137, 148)
    nodc = sum(pulse(f, c, 5.0) for c in counts)                # counting nods
    bob = sum(pulse(f, c + 1, 4.5) for c in counts)             # ...and a little bounce of the whole body with each
    twitch = max(pulse(f, 112, 3), pulse(f, 131, 3), pulse(f, 143, 3), pulse(f, 172, 3), pulse(f, 197, 3))
    breath = math.sin(TAU * f / 46.0)
    sway = math.sin(TAU * (f - 119) / 40.0) * cover * (1 - 0.6 * peek)      # she rocks gently while she counts
    shut = ramp01(f, 110, 118)                                  # her lids close as the paws arrive
    open_l = ramp01(f, 155, 161) * (1 - ramp01(f, 185, 191))    # the peeking eye
    base = hh.POSES['stand']
    up = dict(pitch=47, clear=-0.002, head=(-7, 0, 0), slide=(0, -0.014, 0.006), lid_up=50, lid_lo=-50, lid_tilt=4,
              paws=dict(FL=(-0.012, -0.034, 0.064, 35, 0, -10), FR=(0.012, -0.034, 0.066, 35, 0, 10), **hh.SIT_HIND))
    p = hh.mix_pose(base, up, sit)
    hd = list(p['head'])
    hd[0] += -4.0 * cover - 4.0 * nodc + 3.0 * peek + 4.0 * (1 - sit) * math.sin(TAU * f / 60.0)
    hd[1] += -7.0 * peek + 10.0 * (1 - sit) + 2.0 * sway   # she turns a little toward where he went / toward Little in S1
    hd[2] += -5.0 * peek + 2.5 * sway
    p['head'] = tuple(hd)
    p['nose'] = 1.0 + 0.14 * twitch
    p['nose_rot'] = (6.0 * twitch, 5.0 * math.sin(f * 1.9) * twitch)
    p['squash'] = (1.0 + 0.012 * breath + 0.030 * bob, 1.0, 1.0 + 0.012 * breath - 0.034 * bob)
    p['ears'] = (-10.0 * peek + 5.0 * bob, -10.0 * peek + 5.0 * bob)
    p['jaw'] = 0.0
    cl, cr = shut * (1 - open_l), shut
    p['lid_up'] = (lerp(50.0, -12.0, cl) + 4.0 * open_l, lerp(50.0, -12.0, cr))
    p['lid_lo'] = (lerp(-50.0, -16.0, cl), lerp(-50.0, -16.0, cr))
    paws = p.pop('paws')
    mama.place(yaw=MAMA_YAW + 2.5 * sway, lean=(-1.2 * bob + 1.5 * peek, 2.6 * sway - 3.5 * peek))
    mama.pose(**p)
    if cover > 0:
        # a paw in front of each eye, as the lens sees it. The paw on her L side slides out and down to her cheek
        # for the peek.
        onL = mama.paw_over_eye('L', look_cam, roll=-8.0)
        onR = mama.paw_over_eye('R', look_cam, roll=8.0)
        if peek > 0:
            onL = hh.mix_paw(onL, mama.paw_on_face('L', 60.0, -14.0, out=0.0105, roll=-40.0), peek)
        paws['FL'] = hh.mix_paw(paws['FL'], onL, cover)
        paws['FR'] = hh.mix_paw(paws['FR'], onR, cover)
    mama.set_paws(paws)
    if peek > 0.3:
        dart = kf([(160, 0.0), (166, 0.35), (176, 0.35), (181, -0.25), (186, 0.0)], f)
        tgt = Vector(look_cam) + Vector((dart * 1.2, 0.0, 0.02))
        mama.look_at(tgt)


# ================================================================================================ S1 Evening
def shot_s1(ctx):
    st = build_set()
    sky = G.Sky()
    G.grass([dict(rect=(-1.7, -1.1, 0.9, 1.45), n=30000, h=(0.020, 0.040)),
             dict(rect=(-4.5, -3.2, 5.0, 3.35), n=30000, h=(0.030, 0.055))],
            short=[(G.MAMA0[0], G.MAMA0[1], 0.17), (-0.36, 0.22, 0.13)],
            bare=BARE, focus=(-0.4, -0.3), seed=21, flowers=240, no_flowers=[(-0.30, -0.50, 0.60)])
    P0, P1 = Vector((0.95, -2.35, 1.90)), Vector((-0.30, -0.50, 0.105))
    # the last picture looks a little further left than Mama, so the owl has left the picture whole by then
    T0, Tm, T1 = Vector((1.45, 3.4, 2.25)), Vector((0.30, 1.58, 0.62)), Vector((-0.53, 0.15, 0.088))
    dusk_light(sky, fill_at=((0.5, -1.1, 0.5), T1), fill=5.0)
    st['window'].data.energy = DUSK_WINDOW
    mama = hh.build_hedgehog('mama', fur=fur_of(ctx, 0.45))
    little = hh.build_hedgehog('little', fur=fur_of(ctx, 0.45))
    owl = critters.build_owl(fur=fur_of(ctx, 0.6))
    owl.o['root'].scale = (0.9, 0.9, 0.9)
    owl.place(G.OWL_POS, -8.0)
    cam = kit.camera('Cam', 28.0, 11.0)
    catch_light(cam, [mama, little, owl], 0.75)
    LP = Vector((-0.36, 0.22, 0.0))
    hop_at = (66, 80, 94)
    for f in frames(ctx):
        u = smooth(kit.clamp01((f - 1) / 98.0))
        uz = smooth(kit.clamp01((f - 1) / 94.0))
        pos = Vector((lerp(P0.x, P1.x, u ** 1.25), lerp(P0.y, P1.y, u), lerp(P0.z, P1.z, uz)))
        tgt = T0 * (1 - u) ** 2 + Tm * 2 * u * (1 - u) + T1 * u ** 2
        kit.cam_key(cam, f, pos, tgt, focus=max(0.55, (tgt - pos).length), fstop=lerp(11.0, 7.0, u))
        sky.set(f)
        # the owl sleeps
        owl.pose(lid=1.0, sink=0.004, puff=1.0 + 0.02 * math.sin(TAU * f / 52.0), nod=-6.0)
        owl.key(f)
        # Mama
        mama.place((G.MAMA0[0], G.MAMA0[1], 0.0), MAMA_YAW)
        mama_count(mama, f, P1)
        if f < 100:
            mama.look_at(little.eyes_mid() if f > 2 else None)
        mama.key(f)
        # Little bounces on his toes, looking up at Mama
        lift, sz = hops(f, hop_at, 12.0, 0.024)
        air = 1.0 if lift > 0 else 0.0
        p = hh.mix_pose(hh.POSES['stand'], hh.POSES['sit_giggle'], 0.0)
        p.update(pitch=12 + 6 * air, head=(16 + 6 * air, 26, 6 * math.sin(f * 0.35)), jaw=10 + 4 * air, lid_up=54,
                 lid_lo=-36, lid_tilt=3, ears=(-6 + 10 * air, -6 + 10 * air),
                 cow=-settle(f, hop_at[0] + 3, 16, 9, 6) - settle(f, hop_at[1] + 3, 16, 9, 6) - settle(f, hop_at[2] + 3, 16, 9, 6))
        paws = dict(hh.STAND_PAWS)
        if air:
            for k in paws:
                b = paws[k]
                paws[k] = (b[0], b[1], b[2] + lift * 0.75, 18.0, 0, b[5] if len(b) > 3 else 0)
        p['paws'] = paws
        p['lift'] = lift
        little.place(LP, -52.0, stretch=volume(sz))
        little.pose(**with_blink(p, blink_amount(f, (74, 101))))
        little.look_at(mama.eyes_mid())
        little.key(f)
    finish(ctx)


# ================================================================================================ S2 Counting
def shot_s2(ctx):
    st = build_set(boot=False, can=False)
    sky = G.Sky()
    M = Vector((G.MAMA0[0], G.MAMA0[1], 0.0))
    C = Vector((-0.40, -0.62, 0.140))
    v = (Vector((M.x, M.y, 0)) - Vector((C.x, C.y, 0))).normalized()
    r = Vector((v.y, -v.x, 0.0))
    L0 = Vector((C.x, C.y, 0)) + v * 1.22 + r * 0.165
    run_dir = (r * 0.97 + v * 0.10).normalized()
    G.grass([dict(rect=(-1.5, -0.7, 0.6, 1.45), n=26000, h=(0.020, 0.042))],
            short=[(M.x, M.y, 0.18), (L0.x, L0.y, L0.x + run_dir.x * 0.8, L0.y + run_dir.y * 0.8, 0.10)],
            wedges=[(C.x, C.y, v.x, v.y, 17.0, 4.0)], focus=(M.x, M.y), seed=22, flowers=45,
            no_flowers=[(C.x, C.y, M.x, M.y, 0.16)])
    dusk_light(sky, fill_at=((0.25, -0.9, 0.45), (M.x, M.y, 0.12)), fill=5.0)
    # the wall behind her stands in the bush's shade: a low warm bounce off the lawn lifts it
    kit.area_lamp('WallBounce', (-0.75, 0.65, 0.04), (-0.85, 1.45, 0.28), 9.0, '#ffc48a', size=1.3)
    st['window'].data.energy = DUSK_WINDOW
    mama = hh.build_hedgehog('mama', fur=fur_of(ctx, 1.0))
    little = hh.build_hedgehog('little', fur=fur_of(ctx, 0.35))
    cam = kit.camera('Cam', 85.0, 5.6)
    catch_light(cam, [mama, little], 0.85)
    hop_at = (107, 120, 133)
    for f in frames(ctx):
        mama.place(M, MAMA_YAW)
        mama_count(mama, f, C)
        mama.key(f)
        push = ramp01(f, 109, 204)
        pos = C + v * (0.035 * push)
        tgt = Vector((M.x + 0.004, M.y, 0.148))
        kit.cam_key(cam, f, pos, tgt, focus=mama.eyes_mid())
        sky.set(f)
        # Little behind her: two happy bounces, a turn, and away to the right
        lift, sz = hops(f, hop_at, 12.0, 0.026)
        go = ramp01(f, 143, 150)
        dist = 0.0 if f < 147 else 0.019 * (f - 147) * smooth(kit.clamp01((f - 147) / 6.0))
        ph = TAU * (f - 147) / 6.0
        yaw = lerp(-10.0, heading(run_dir), go)
        if f < 147:
            p = dict(hh.POSES['stand'])
            p.update(pitch=12, head=(18, 10, 0), jaw=10, lid_up=54, lid_lo=-36, lift=lift, cow=-settle(f, 124, 16, 9, 6))
        else:
            p = dict(hh.POSES['stand'])
            p.update(pitch=8 + 3 * math.sin(2 * ph), head=(4, -14, 0), paws=trot(ph), lift=0.003 * abs(math.sin(ph)),
                     cow=14 + 8 * math.sin(2 * ph - 1.2))
        little.place(L0 + run_dir * dist, yaw, stretch=volume(sz))
        little.pose(**p)
        little.key(f)
    finish(ctx)


# ================================================================================================ S3 Scurry
RUN_Y = -0.45
S3_CAM_Y = RUN_Y - 0.52
RUN_X0 = -1.78
RUN_V = 0.0178          # metres a frame


def s3_x(f):
    """Little's place along his run: steady until 262, then a quick soft stop by 274."""
    if f <= 262:
        return RUN_X0 + RUN_V * (f - 205)
    t = min(1.0, (f - 262) / 12.0)
    return RUN_X0 + RUN_V * 57 + RUN_V * 12 * (t - 0.5 * t * t)


def shot_s3(ctx):
    st = build_set()
    sky = G.Sky()
    xs = s3_x(274)
    tufts = []
    import numpy as np
    rng = np.random.default_rng(33)
    cam_end = xs + 0.045
    spots = [xc + rng.uniform(-0.05, 0.05) for xc in np.arange(-2.3, 0.5, 0.21)]
    spots = [xx for xx in spots if abs(xx - cam_end) > 0.27] + [cam_end - 0.215, cam_end + 0.235]
    for xx in spots:
        yy = rng.uniform(-0.90, -0.85)
        tufts.append(dict(rect=(xx - 0.022, yy - 0.015, xx + 0.022, yy + 0.015), n=30, h=(0.045, 0.085)))
    G.grass([dict(rect=(-2.7, -0.98, 0.9, -0.30), n=26000, h=(0.008, 0.017)),
             dict(rect=(-2.9, -0.30, 1.4, 0.55), n=20000, h=(0.035, 0.065)),
             dict(rect=(-3.4, 0.55, 2.2, 1.45), n=9000, h=(0.03, 0.05))] + tufts,
            short=[(-2.6, RUN_Y, 0.6, RUN_Y, 0.09)],
            bare=BARE,
            wedges=[(x, S3_CAM_Y, 0.0, 1.0, 37.0, 4.5) for x in (-1.7, -1.3, -0.9, xs + 0.1)], focus=(-1.0, -0.8), seed=23,
            flowers=230, no_flowers=[(cam_end - 0.30, RUN_Y - 0.30, cam_end + 0.30, RUN_Y - 0.30, 0.30),
                                     (-2.6, RUN_Y, 0.6, RUN_Y, 0.12)])
    _, fill = dusk_light(sky, fill_at=((-1.0, -2.0, 0.75), (-1.0, RUN_Y, 0.05)), fill=11.0)
    fill.data.size = 1.8
    st['window'].data.energy = DUSK_WINDOW
    little = hh.build_hedgehog('little', fur=fur_of(ctx, 0.75))
    cam = kit.camera('Cam', 40.0, 4.0)
    catch_light(cam, [little], 0.52)
    stand = hh.POSES['stand']
    look_far = Vector((2.0, 0.6, 0.10))
    for f in frames(ctx):
        x = s3_x(f)
        run = 1.0 - ramp01(f, 262, 272)
        ph = TAU * (f - 205) / 6.0
        # ---- the body: run, then a stop with a little overshoot
        brake = pulse(f, 268, 6.0)                                   # nose dips as he brakes
        rock = settle(f, 270, 9.0, 10.0, 6.0)                         # rocks back and settles
        sniff1 = ramp01(f, 279, 284) * (1 - ramp01(f, 289, 293))
        sniff2 = ramp01(f, 293, 298) * (1 - ramp01(f, 304, 309))
        alert = ramp01(f, 306, 312)
        s1p = max(pulse(f, 283, 2.2), pulse(f, 287, 2.2))
        s2p = max(pulse(f, 297, 2.2), pulse(f, 301, 2.2))
        p = dict(stand)
        p['pitch'] = 8 + 5 * math.sin(2 * ph) * run - 9 * brake + rock + 4 * sniff1 + 5 * sniff2 + 2 * alert
        p['lift'] = 0.006 * abs(math.sin(ph)) * run
        # the sniffs lift his nose only a little: his eyes, smile and nose must all stay in view of the lens
        nod = (2 - 3 * math.sin(2 * ph)) * run - 6 * brake + 13 * sniff1 + 17 * sniff2 + 1 * alert + 2 * s1p + 2 * s2p
        facecam = ramp01(f, 275, 288)                              # after the stop he turns his body toward the lens
        away = ramp01(f, 315, 320)                                 # ...and at the end he looks off to where he will hide
        turn = -36 * run - 16 * (1 - run) * (1 - sniff1) * (1 - sniff2) * (1 - alert) - 20 * sniff1 - 26 * sniff2 \
            + (-18 + 34 * away) * alert
        tilt = 3 * math.sin(ph) * run + 7 * sniff1 - 6 * sniff2 + 5 * alert
        p['head'] = (nod, turn, tilt)
        p['slide'] = (0, -0.016 - 0.005 * (sniff1 + sniff2), -0.016 + 0.008 * (sniff1 + sniff2))
        p['jaw'] = 7 * run + 2 * alert
        p['nose'] = 1.0 + 0.16 * (s1p + s2p)
        p['nose_rot'] = (8 * (s1p + s2p), 0)
        p['ears'] = (5 * math.sin(2 * ph - 0.8) * run - 9 * alert + 6 * brake, 5 * math.sin(2 * ph - 0.8) * run - 9 * alert + 6 * brake)
        p['cow'] = (14 + 8 * math.sin(2 * ph - 1.2)) * run - 26 * pulse(f, 269, 5.0) + settle(f, 273, 14, 9, 7)
        bounce = math.sin(2 * ph - 0.6) * run
        p['squash'] = (1.0, 1.0 + 0.04 * brake + 0.05 * bounce, 1.0 - 0.05 * brake - 0.04 * bounce)
        # eyes wide and round all through; in the second sniff they close for a moment into happy arcs
        bliss = ramp01(f, 296, 299) * (1 - ramp01(f, 302, 306))
        p['lid_up'] = lerp(54, 14, bliss)
        p['lid_lo'] = lerp(lerp(-46, -24, max(sniff1, sniff2)), 15, bliss)
        p['lid_tilt'] = 3
        shuffle = pulse(f, 281, 7.0)
        tr = trot(ph, amp=0.017 * run + 0.006 * shuffle, lift=0.010 * run + 0.005 * shuffle)
        br = dict(hh.STAND_PAWS)
        br['FL'] = (-0.025, -0.058 + 0.012 * (1 - brake), 0.004)
        br['FR'] = (0.025, -0.055 + 0.009 * (1 - brake), 0.004)
        p['paws'] = {k: hh.mix_paw(br[k], tr[k], max(run, shuffle)) for k in tr}
        wob = 3.0 * math.sin(ph) * run
        little.place((x, RUN_Y, 0.0), 90.0 - 46.0 * facecam + 2.5 * math.sin(ph + 1.2) * run, lean=(0.0, wob))
        little.pose(**with_blink(p, blink_amount(f, (247, 318))))
        little.look_at(look_far if away > 0.5 else (cam.location.copy() if alert > 0.3 else None))
        little.key(f)
        # ---- the camera travels beside him, a touch late, and comes to rest after he does
        cx = s3_x(f - 2) + 0.10 if f <= 262 else lerp(s3_x(262 - 2) + 0.10 + RUN_V * (f - 262) * (1 - 0.5 * ramp01(f, 262, 286)),
                                                      xs + 0.045, ramp01(f, 262, 288))
        pos = Vector((cx, S3_CAM_Y + 0.085 * ramp01(f, 264, 294), 0.068))
        tgt = Vector((cx - 0.012, RUN_Y, 0.060))
        kit.cam_key(cam, f, pos, tgt, focus=Vector((x, RUN_Y, 0.05)))
        sky.set(f)
    finish(ctx, blur=True)


# ================================================================================================ S4 Not here
def rot2(v, deg):
    c, si = math.cos(RAD(deg)), math.sin(RAD(deg))
    return Vector((v.x * c - v.y * si, v.x * si + v.y * c, 0.0))


def wrap180(a):
    return (a + 180.0) % 360.0 - 180.0


def shot_s4(ctx):
    import numpy as np
    st = build_set()
    sky = G.Sky()
    A = Vector((G.BOOT_A[0], G.BOOT_A[1], 0.0))
    O = Vector((G.BOOT_O[0], G.BOOT_O[1], 0.0))
    w = rot2(A, -35.0)                               # the lens stands to the left of the way the opening faces
    C = O + w * 1.5 + Vector((0, 0, 0.088))
    v = rot2(-w, 2.5)                                # and looks a little left of the boot
    r = Vector((v.y, -v.x, 0.0))
    sx, sy = G.STONE
    Cg = Vector((C.x, C.y, 0.0))
    # Little's way: in from the left behind the snail, round to the front of the boot, a turn, and in
    pts = [Cg + v * 0.95 - r * 0.50, Cg + v * 1.02 - r * 0.22, Cg + v * 1.10 + r * 0.02, G.boot_point(0.36, 0.11, 0.0),
           G.boot_point(0.24, 0.02, 0.0), G.boot_point(0.07, 0.0, 0.0), G.boot_point(-0.085, 0.0, 0.0)]
    key_f = [332, 348, 362, 374, 385, 396, 420]
    dense = kit.catmull(np.array([tuple(p) for p in pts]), 24)

    def way(f):
        f = min(max(f, key_f[0]), key_f[-1])
        for i in range(len(key_f) - 1):
            if key_f[i] <= f <= key_f[i + 1]:
                u = (i + (f - key_f[i]) / float(key_f[i + 1] - key_f[i])) * 24
                break
        j = min(int(u), len(dense) - 2)
        t = u - j
        return Vector(dense[j] * (1 - t) + dense[j + 1] * t)
    G.grass([dict(rect=(-0.5, -0.45, 2.0, 0.45), n=22000, h=(0.012, 0.028)),
             dict(rect=(-0.2, 0.45, 2.3, 1.45), n=22000, h=(0.018, 0.038))],
            short=[tuple(pts[i])[:2] + tuple(pts[i + 1])[:2] + (0.09,) for i in range(len(pts) - 1)],
            bare=BARE, wedges=[(C.x, C.y, v.x, v.y, 15.0, 4.5)], focus=(sx, sy), seed=24, flowers=70,
            no_flowers=[(C.x, C.y, sx, sy, 0.10)])
    dusk_light(sky, fill_at=(tuple(Cg + r * 0.55 - v * 0.1 + Vector((0, 0, 0.5))), (sx, sy, 0.06)), fill=5.0)
    st['window'].data.energy = DUSK_WINDOW
    snail = critters.build_snail()
    top = st['stone_top']
    face = (-r * 0.94 - v * 0.34)                     # the snail looks to screen left, a little toward the lens
    snail.place((sx, sy, top - 0.0015), heading((face.x, face.y)))
    little = hh.build_hedgehog('little', fur=fur_of(ctx, 0.5))
    cam = kit.camera('Cam', 100.0, 8.0)
    kit.eye_light(cam, snail.eye_objects() + little.eye_objects(), 0.5, radiance=70.0)
    tgt = C + v * 1.0 + Vector((0, 0, -0.010))
    d_snail = (Vector((sx, sy, 0)) - Cg).dot(v)
    d_boot = (O - Cg).dot(v) - 0.06
    f0, f1 = ctx.sync.get('focus_pull_start', 372), ctx.sync.get('focus_pull_end', 396)
    for f in frames(ctx):
        # ---- the snail's eye-stalks follow what scurries past behind it: from the left, over the top, to the right
        sweep = kf([(325, 34.0), (336, 40.0), (346, 26.0), (364, -16.0), (374, -10.0), (420, -12.0)], f)
        sweep_l = kf([(325, 30.0), (340, 38.0), (351, 28.0), (369, -12.0), (380, -6.0), (420, -8.0)], f)
        curl = kf([(325, 14.0), (346, 10.0), (364, -34.0), (376, -26.0), (420, -28.0)], f)
        curl_l = kf([(325, 12.0), (351, 10.0), (369, -30.0), (382, -22.0), (420, -24.0)], f)
        sway = 3.0 * math.sin(TAU * f / 31.0)
        dip = pulse(f, 386, 6.0)
        snail.pose(R=(sweep + sway, -9.0 - 5.0 * math.sin(TAU * f / 40.0)), R2=(curl, -8.0),
                   L=(sweep_l - sway, 10.0 + 5.0 * math.sin(TAU * f / 37.0)), L2=(curl_l, 6.0),
                   ext=(1.0 - 0.4 * dip, 1.0 - 0.25 * pulse(f, 390, 6.0)),
                   shell=(2.0 * math.sin(TAU * f / 50.0) + 4.0 * pulse(f, 366, 9.0), 1.5 * math.sin(TAU * f / 43.0)),
                   stretch=1.0 + 0.03 * math.sin(TAU * f / 60.0))
        snail.key(f)
        # ---- focus: on the snail until 372, on the boot from 396
        k = ramp01(f, f0, f1)
        kit.cam_key(cam, f, C, tgt, focus=lerp(d_snail, d_boot, k), fstop=lerp(8.0, 6.3, k))
        sky.set(f)
        # ---- Little
        pos, nxt, prv = way(f), way(f + 1.0), way(f - 1.0)
        d = nxt - prv
        speed = d.length / 2.0
        into = ramp01(f, 386, 396)
        d = d.normalized() if d.length > 1e-6 else -A
        d = (d * (1 - into) + (-A) * into).normalized()
        ph = TAU * (f - 325) / 6.0
        going = kit.clamp01(speed / 0.010)
        inside = ramp01(f, 394, 410)
        pos.z = G.BOOT_FLOOR * ramp01(f, 388, 398)
        yaw = heading((d.x, d.y))
        glance = pulse(f, 380, 8.0)
        to_cam = wrap180(heading((C.x - pos.x, C.y - pos.y)) - yaw)
        turn = max(-52.0, min(52.0, to_cam)) * glance
        p = dict(hh.POSES['stand'])
        p.update(pitch=8 + 3 * math.sin(2 * ph) * going - 4 * inside, head=(4 + 8 * glance, turn, 0.12 * turn),
                 paws=trot(ph, amp=0.013 * going + 0.004, lift=0.008 * going + 0.002),
                 lift=0.003 * abs(math.sin(ph)) * going, cow=10 * going + 6 * math.sin(2 * ph - 1.0),
                 ears=(4 * math.sin(2 * ph), 4 * math.sin(2 * ph)), jaw=8 * glance, lid_up=54, lid_lo=-38)
        wig = 5.0 * math.sin(TAU * f / 7.0) * inside
        little.place(pos, yaw + wig, lean=(0.0, 3.0 * math.sin(ph) * going + wig * 0.6))
        little.pose(**p)
        if glance > 0.3:
            little.look_at(C)
        little.key(f)
        # the boot rocks a little as he squeezes in
        st['boot'].rotation_euler = (RAD(2.4 * math.sin(TAU * f / 7.0) * inside), 0, 0)
        st['boot'].keyframe_insert('rotation_euler', frame=f)
    finish(ctx)


# ================================================================================================ S5 Night comes
def shot_s5(ctx):
    st = build_set(bush=False)
    sky = G.Sky()
    C = Vector((-0.05, -0.05, 0.085))
    az = RAD(14.0)
    G.grass([dict(rect=(-1.2, -0.10, 1.8, 1.45), n=22000, h=(0.022, 0.050))], bare=BARE,
            wedges=[(C.x, C.y, math.sin(az), math.cos(az), 36.0, 3.0)], focus=(C.x, C.y + 0.4), seed=25)
    sun, _ = dusk_light(sky, sun=4.2, rim=1.5)
    moon = kit.sun_lamp('Moon', G.MOON_DIR, 0.0, '#a9c0ff', 7.0)
    rim = bpy.data.objects['Rim']
    owl = critters.build_owl(fur=fur_of(ctx, 1.0))
    owl.o['root'].scale = (0.9, 0.9, 0.9)
    owl.place(G.OWL_POS, -8.0)
    cam = kit.camera('Cam', 35.0, 8.0)
    kit.eye_light(cam, owl.eye_objects(), 1.55, radiance=32.0)
    ox = G.OWL_POS[0]
    # a soft warm light that only the owl receives (as if from the window): it lifts the owl off the grey wall, so
    # its waking, head turn and blink are seen
    owl_key = kit.area_lamp('OwlKey', (ox - 0.55, 0.55, 0.95), (ox, G.OWL_POS[1], G.OWL_POS[2] + 0.07), 0.0, '#ffdcb4',
                            size=0.5)
    coll = bpy.data.collections.new('OwlLit')
    for ob in bpy.data.objects:
        if ob.name.startswith('Owl') and ob.type in ('MESH', 'CURVES'):
            coll.objects.link(ob)
    owl_key.light_linking.receiver_collection = coll
    flies = G.Fireflies([dict(c=(ox - 0.75, 0.75, 0.22), r=(0.10, 0.08, 0.05), on=474, lamp=0.03),
                         dict(c=(ox + 0.55, 0.95, 0.30), r=(0.12, 0.06, 0.06), on=486, lamp=0.03),
                         dict(c=(ox - 0.20, 0.55, 0.16), r=(0.08, 0.08, 0.04), on=496, lamp=0.03),
                         dict(c=(ox + 0.95, 0.60, 0.20), r=(0.10, 0.07, 0.05), on=503, lamp=0.03),
                         dict(c=(ox - 0.45, 1.20, 0.34), r=(0.10, 0.05, 0.05), on=510, lamp=0.0),
                         dict(c=(ox + 0.25, 0.70, 0.40), r=(0.14, 0.08, 0.06), on=516, lamp=0.0)], seed=5)
    closed_at = ctx.sync.get('owl_blinks', 492)
    for f in frames(ctx):
        t = (f - 421) / 107.0
        # ---- evening becomes night, in one go
        sun.data.energy = 4.2 * (1 - smooth(kit.clamp01(t / 0.68)))
        sun.data.keyframe_insert('energy', frame=f)
        rim.data.energy = 1.5 * (1 - smooth(kit.clamp01(t / 0.68)))
        rim.data.keyframe_insert('energy', frame=f)
        sun.data.color = lerp((1.0, 0.44, 0.16), (1.0, 0.22, 0.06), kit.clamp01(t / 0.68))
        sun.data.keyframe_insert('color', frame=f)
        n = smooth(kit.clamp01((t - 0.04) / 0.78))
        sky.set(f, night=n, stars=kit.clamp01((t - 0.24) / 0.74), amb=lerp(0.42, NIGHT_AMB, n))
        moon.data.energy = NIGHT_MOON * smooth(kit.clamp01((t - 0.08) / 0.72))
        moon.data.keyframe_insert('energy', frame=f)
        wl = smooth(kit.clamp01((t - 0.10) / 0.75))
        st['window'].data.energy = lerp(DUSK_WINDOW, NIGHT_WINDOW, wl)
        st['window'].data.keyframe_insert('energy', frame=f)
        st['glow'].default_value = lerp(DUSK_GLOW, NIGHT_GLOW, wl)
        st['glow'].keyframe_insert('default_value', frame=f)
        owl_key.data.energy = lerp(2.5, 9.0, wl)
        owl_key.data.keyframe_insert('energy', frame=f)
        flies.key(f)
        # ---- the camera: hedgehog height, a slow tilt up to the sky
        pitch = lerp(8.5, 18.5, smooth(t))
        d = Vector((math.sin(az) * math.cos(RAD(pitch)), math.cos(az) * math.cos(RAD(pitch)), math.sin(RAD(pitch))))
        kit.cam_key(cam, f, C, C + d * 3.0, focus=3.2)
        # ---- the owl wakes, turns its head, blinks once (closed at 492), and stays up
        wake = ramp01(f, 452, 468)
        lid = lerp(1.0, 0.16, wake)
        lid = max(lid, pulse(f, closed_at, 6.5) ** 0.35 if abs(f - closed_at) < 6.5 else 0.0)
        if abs(f - closed_at) <= 2:
            lid = 1.0
        turn = kf([(466, 0.0), (482, -46.0), (500, -42.0), (516, -12.0), (528, -14.0)], f) + settle(f, 482, 4.0, 9.0, 5.0)
        owl.pose(turn=turn, tilt=kf([(466, 0.0), (482, 11.0), (516, 3.0)], f), nod=lerp(-6.0, 2.0, wake) - 5.0 * ramp01(f, 498, 518),
                 lid=lid, sink=0.004 * (1 - wake), puff=1.0 + 0.02 * math.sin(TAU * f / 52.0) + 0.10 * pulse(f, 461, 9.0),
                 look=(kf([(466, 0.0), (478, -8.0), (500, -6.0), (520, 0.0)], f), -4.0 * ramp01(f, 498, 518)))
        owl.key(f)
    finish(ctx)


# ================================================================================================ S6 Found you
def shot_s6(ctx):
    st = build_set(bush=False)
    sky = G.Sky()
    A = Vector((G.BOOT_A[0], G.BOOT_A[1], 0.0))          # out of the boot's opening
    R = Vector((-A.y, A.x, 0.0))                          # to its right (the lens side)
    # The lens stands behind Mama's shoulder and well to the side of the boot, so that when she reaches Little her
    # face is seen from the side (her eye and her smile) and his face looks out toward us.
    look = G.boot_point(0.055, 0.0, 0.068)
    cdir = (A * 0.457 + R * 0.89).normalized()            # from the look point back toward the lens
    side = Vector((-cdir.y, cdir.x, 0.0))                 # screen right, on the ground

    def cam_at(f):
        """A slow push-in all through the shot. It starts further behind Mama, looking over her shoulder at the
        boot as she walks in, and drifts round to her side by the time the noses meet."""
        k = smooth(kit.clamp01((f - 529) / 101.0))
        a = RAD(lerp(40.0, 62.8, smooth(kit.clamp01((f - 529) / 66.0))))
        return look + (A * math.cos(a) + R * math.sin(a)) * lerp(1.04, 0.74, k) + Vector((0, 0, lerp(0.100, 0.072, k)))
    Cs, Cm, Ce = cam_at(529), cam_at(562), cam_at(630)

    def spot(beyond, right, z):                           # a point given as the lens sees it
        q = look - cdir * beyond + side * right
        return (q.x, q.y, z)
    night_light(sky, st)
    mama = hh.build_hedgehog('mama', fur=fur_of(ctx, 0.7))
    little = hh.build_hedgehog('little', fur=fur_of(ctx, 0.9))
    cam = kit.camera('Cam', 56.0, 4.0)
    recv = mama.eye_objects() + little.eye_objects()
    kit.eye_light(cam, recv, 0.85, radiance=58.0)          # dark eyes live by their sparkle: keep it clear at night
    # the warm light of the fireflies, from the lens side: both faces are lit warm, and so is the inside of the boot
    kit.area_lamp('Glow', tuple(G.boot_point(0.36, 0.52, 0.30)), tuple(G.boot_point(0.03, 0.0, 0.06)), 4.6, '#ffb46e',
                  size=0.45)
    fl = [dict(c=tuple(G.boot_point(-0.035, -0.015, 0.130)), r=(0.006, 0.006, 0.005), on=548, lamp=0.04),
          dict(c=spot(0.30, -0.17, 0.21), r=(0.05, 0.05, 0.03), on=500, lamp=0.04),
          dict(c=spot(0.16, 0.20, 0.27), r=(0.04, 0.04, 0.03), on=500, lamp=0.04),
          dict(c=spot(0.55, 0.10, 0.31), r=(0.08, 0.05, 0.04), on=500, lamp=0.03),
          dict(c=spot(0.90, -0.30, 0.35), r=(0.10, 0.06, 0.05), on=500, lamp=0.0),
          dict(c=spot(1.15, 0.28, 0.40), r=(0.10, 0.06, 0.05), on=500, lamp=0.0),
          dict(c=spot(0.70, -0.12, 0.26), r=(0.08, 0.06, 0.04), on=500, lamp=0.0),
          dict(c=spot(-0.22, 0.17, 0.115), r=(0.03, 0.03, 0.02), on=500, lamp=0.0)]
    flies = G.Fireflies(fl, seed=6)
    loop = bpy.data.objects.get('Boot.loop')
    if loop is not None:                                   # from this side the pull loop sat right at Mama's mouth
        loop.hide_render = True
    touch = ctx.sync.get('noses_touch', 600)
    yaw_l = heading((A.x, A.y)) + 6.0                     # Little faces out of the boot, a little toward the lens
    mdir = -A * math.cos(RAD(14.0)) + R * math.sin(RAD(14.0))
    yaw_m = heading((mdir.x, mdir.y))                     # Mama faces the boot, angled so we see her from the side

    def little_pose(f):
        out = kf([(529, -0.130), (553, -0.130), (570, -0.064), (588, -0.054), (touch, -0.044), (630, -0.040)], f)
        curl = 1.0 - ramp01(f, 551, 565)                         # rolled up in the dark, then he uncurls to peep
        gig = settle(f, 533, 1.0, 5.0, 7.0) + settle(f, 551, 0.8, 5.0, 6.0) + settle(f, touch + 2, 1.0, 5.5, 9.0)
        laugh = ramp01(f, 570, 577) * (1 - ramp01(f, touch - 6, touch - 1))    # an open-mouth laugh: she found me!
        happy = ramp01(f, touch - 2, touch + 5)
        squeeze = pulse(f, touch + 9, 6.0)                       # after the touch his eyes squeeze shut for a moment
        chat = abs(math.sin(TAU * f / 7.0))
        p = dict(hh.POSES['stand'])
        p.update(pitch=5 + 2 * laugh, head=(9 + 3 * gig + 3 * laugh * chat + 3 * happy, 10 + 4 * gig, 5 * gig + 4 * happy),
                 slide=(0, -0.020, -0.012),
                 jaw=15 * laugh * (0.55 + 0.45 * chat) + 7 * happy * (0.6 + 0.4 * abs(math.sin(TAU * f / 6.0))),
                 lid_up=lerp(54, 14, squeeze), lid_lo=lerp(-46 + 26 * max(laugh, happy), 15, squeeze), lid_tilt=3,
                 ears=(-6 + 8 * happy - 5 * laugh * chat, -6 + 8 * happy - 5 * laugh * chat),
                 nose=1.0 + 0.12 * pulse(f, 578, 3) + 0.12 * pulse(f, 584, 3), cow=6 * gig + 5 * laugh * chat)
        if curl > 0:
            p = hh.mix_pose(p, hh.POSES['ball'], curl)
        pos = G.boot_point(out, 0.0, G.BOOT_FLOOR)
        little.place(pos, yaw_l + 3.0 * gig, lean=(0.0, 4.0 * gig))
        little.pose(**with_blink(p, blink_amount(f, (567, 590))))
        return p

    def mama_base(f):
        reach = ramp01(f, 566, touch - 2)
        nuzzle = ramp01(f, touch + 6, touch + 14)
        twitch = max(pulse(f, 550, 3), pulse(f, 560, 3), pulse(f, 574, 3), pulse(f, 586, 3))
        happy = ramp01(f, touch - 1, touch + 6)
        ph = TAU * f / 14.0
        walk = ramp01(f, 541, 548) * (1 - ramp01(f, touch - 8, touch - 2))
        p = dict(hh.POSES['stand'])
        # her head turns toward the lens as she reaches, so her cheek, eye and smile are in view
        p.update(pitch=6 - 5 * reach, head=(8 - 12 * reach + 2 * math.sin(TAU * f / 9.0) * nuzzle, -6 - 14 * reach,
                                            -3 * reach + 5 * math.sin(TAU * f / 18.0) * nuzzle),
                 slide=(0, -0.016 - 0.010 * reach, -0.016 - 0.004 * reach), nose=1.0 + 0.14 * twitch,
                 nose_rot=(6 * twitch, 0), ears=(-12 + 8 * reach, -12 + 8 * reach), lid_up=lerp(52, 36, happy),
                 lid_lo=lerp(-50, -14, happy), lid_tilt=4, jaw=5 * happy,
                 paws=trot(ph, amp=0.010 * walk, lift=0.006 * walk),
                 squash=(1.0 + 0.012 * math.sin(TAU * f / 44.0), 1.0, 1.0 + 0.012 * math.sin(TAU * f / 44.0)))
        return p

    def solve_mama(f, p):
        """Put Mama so the tip of her nose is exactly on the tip of Little's."""
        tip_l = little.nose_tip()
        mama.place((0, 0, 0), yaw_m)
        mama.pose(**p)
        dz = (tip_l.z - mama.nose_tip().z) / mama.P['size']
        sl = p['slide']
        p['slide'] = (sl[0], sl[1], sl[2] + dz)
        mama.pose(**p)
        tip = mama.nose_tip()
        return Vector((tip_l.x - tip.x, tip_l.y - tip.y, 0.0)), p

    little_pose(touch)
    root_touch, _ = solve_mama(touch, mama_base(touch))
    root_far = root_touch - mdir * 0.34                   # she walks in along the way she faces
    G.grass([dict(rect=(-1.2, -0.35, 2.5, 1.45), n=46000, h=(0.018, 0.040))],
            short=[(root_far.x, root_far.y, root_touch.x, root_touch.y, 0.13),
                   tuple(G.boot_point(0.30, 0.0, 0.0))[:2] + tuple(G.boot_point(0.02, 0.0, 0.0))[:2] + (0.10,)],
            bare=BARE, wedges=[(c.x, c.y, look.x - c.x, look.y - c.y, 27.0, 4.5) for c in (Cs, Cm, Ce)],
            focus=(look.x, look.y), seed=26, flowers=90,
            no_flowers=[(c.x, c.y, look.x, look.y, 0.24) for c in (Cs, Cm, Ce)])
    for f in frames(ctx):
        little_pose(f)
        little.look_at(mama.eyes_mid() if f > 562 else None)
        little.key(f)
        p = mama_base(f)
        if f >= touch:
            rootp, p = solve_mama(f, p)
        else:
            rootp = root_far.lerp(root_touch, kf([(529, 0.0), (541, 0.0), (575, 0.62), (touch, 1.0)], f))
        mama.place(rootp, yaw_m + 2.0 * math.sin(TAU * f / 14.0) * (1 - ramp01(f, touch - 8, touch)))
        mama.pose(**p)
        mama.look_at(little.eyes_mid())
        mama.key(f)
        # the boot wobbles with a giggle
        wob = settle(f, 532, 5.5, 5.0, 6.0) + settle(f, 550, 4.0, 5.0, 5.0) + settle(f, touch + 2, 2.5, 5.5, 8.0)
        st['boot'].rotation_euler = (RAD(wob), 0, 0)
        st['boot'].keyframe_insert('rotation_euler', frame=f)
        kit.cam_key(cam, f, cam_at(f), look, focus=G.boot_point(0.03, 0.0, 0.07))
        sky.set(f)
        flies.key(f)
    finish(ctx)


# ================================================================================================ S7 Goodnight
def shot_s7(ctx):
    st = build_set(can=False, hedge=0.5)      # the can and the stone stand outside this shot's picture
    sky = G.Sky()
    still = ctx.sync.get('still_from', 684)
    sleep = hh.POSES['sleep']
    mama = hh.build_hedgehog('mama', fur=fur_of(ctx, 0.6))
    little = hh.build_hedgehog('little', fur=fur_of(ctx, 0.6))
    # The two lie curled toward each other in front of the boot, heads together and both faces toward the lens:
    # Mama on the left, Little tucked in against her cheek, their noses side by side.
    Mp = G.boot_point(0.30, -0.17, 0.0)
    yaw_m, yaw_l = 50.0, -55.0

    def mama_pose(down):
        p = dict(sleep)
        p.update(head=(lerp(5, -8, down), -24, -6), slide=(0.004, -0.013, lerp(-0.020, -0.027, down)),
                 lid_up=lerp(12, -3, down), lid_lo=lerp(-24, -7, down), lid_tilt=4, ears=(12 + 3 * down, 12 + 3 * down))
        return p

    def little_pose():
        q = hh.mix_pose(sleep, hh.POSES['ball'], 0.18)
        q.update(head=(-6, 24, 8), slide=(0.003, -0.012, -0.027), lid_up=-3, lid_lo=-7, lid_tilt=4, jaw=0)
        return q
    mama.place((0, 0, 0), yaw_m)
    mama.pose(**mama_pose(1.0))
    tm = mama.nose_tip()
    little.place((0, 0, 0), yaw_l)
    little.pose(**little_pose())
    tl = little.nose_tip()
    Lp = Mp + Vector((tm.x - tl.x + 0.012, tm.y - tl.y + 0.004, 0.0))
    nose = Mp + Vector((tm.x, tm.y, 0.0))                 # where the two noses meet (on the ground plan)
    cen = (Mp + Lp) * 0.5 + Vector((0.0, -0.035, 0.0))    # the middle of the pair
    # the camera starts close above them and rises up and back; it settles looking over them at the wall with
    # the owl, the lit window and the stars, with the pair large in the lower part of the picture
    Ps, Ts = Vector((nose.x + 0.01, nose.y - 0.24, 0.24)), Vector((cen.x, cen.y, 0.045))
    Pe = Vector((nose.x + 0.03, nose.y - 0.45, 0.33))
    Te = Pe + Vector((0.04, 2.0, -0.480))
    Pm = (Ps + Pe) * 0.5
    G.grass([dict(rect=(-0.7, 0.10, 3.0, 1.45), n=38000, h=(0.018, 0.040)),
             dict(rect=(-3.5, 1.75, 1.3, 3.4), n=6000, h=(0.03, 0.05))],
            short=[(Mp.x, Mp.y, 0.16), (Lp.x, Lp.y, 0.12)],
            bare=BARE, wedges=[(Ps.x, Ps.y, 0.0, 1.0, 66.0, 1.6), (Pm.x, Pm.y, 0.0, 1.0, 57.0, 2.5),
                               (Pe.x, Pe.y, 0.02, 1.0, 51.0, 6.0)],
            focus=(cen.x, cen.y - 0.15), seed=27, flowers=150, no_flowers=[(cen.x, cen.y, 0.27)])
    night_light(sky, st)
    owl = critters.build_owl(fur=fur_of(ctx, 0.6))
    owl.o['root'].scale = (0.9, 0.9, 0.9)
    owl.place(G.OWL_POS, 10.0)
    cam = kit.camera('Cam', 20.0, 4.0)
    catch_light(cam, [mama, little, owl], 0.6, night=True)
    # a warm pool of light on the sleeping pair (the glow of the window and the fireflies), so they are the warm
    # heart of the picture and never grey
    kit.area_lamp('Glow', (cen.x + 0.42, cen.y - 0.58, 0.66), (cen.x, cen.y, 0.04), 9.0, '#ffb878', size=0.6)
    fl = [dict(c=(cen.x - 0.27, cen.y - 0.02, 0.15), r=(0.05, 0.04, 0.03), on=500, lamp=0.05),
          dict(c=(cen.x + 0.30, cen.y - 0.10, 0.19), r=(0.05, 0.04, 0.03), on=500, lamp=0.045),
          dict(c=(cen.x - 0.55, cen.y + 0.40, 0.32), r=(0.10, 0.07, 0.05), on=500, lamp=0.03),
          dict(c=(cen.x + 0.62, cen.y + 0.25, 0.30), r=(0.10, 0.07, 0.05), on=500, lamp=0.03),
          dict(c=(cen.x + 0.08, cen.y + 0.55, 0.50), r=(0.12, 0.05, 0.05), on=500, lamp=0.0),
          dict(c=(cen.x + 0.95, cen.y + 0.65, 0.44), r=(0.10, 0.06, 0.06), on=500, lamp=0.0),
          dict(c=(cen.x - 0.40, cen.y + 0.80, 0.60), r=(0.12, 0.05, 0.05), on=500, lamp=0.0),
          dict(c=(cen.x - 0.95, cen.y + 0.70, 0.48), r=(0.12, 0.06, 0.06), on=500, lamp=0.0),
          dict(c=(cen.x + 0.45, cen.y + 0.85, 0.72), r=(0.10, 0.05, 0.05), on=500, lamp=0.0)]
    flies = G.Fireflies(fl, seed=8)
    for f in frames(ctx):
        fa = min(f, still)                                   # nothing in the cast moves after `still`
        live = 1.0 - ramp01(fa, still - 16, still - 2)       # breathing eases away before the hold
        br = math.sin(TAU * fa / 44.0) * live
        # Mama: her head sinks, her eyes close
        down = ramp01(fa, 626, 656)
        p = mama_pose(down)
        p['squash'] = (1.07 + 0.012 * br, 0.93, 0.97 + 0.014 * br)
        mama.place(Mp, yaw_m, lean=(0.0, 4.0))
        mama.pose(**p)
        mama.key(f)
        # Little: fast asleep already; one ear flick, the cowlick settles
        flick = pulse(fa, 650, 4.0)
        bl = math.sin(TAU * fa / 36.0 + 1.0) * live
        q = little_pose()
        sq = q.get('squash', (1.07, 0.93, 0.97))
        q.update(squash=(sq[0] + 0.016 * bl, sq[1], sq[2] + 0.02 * bl), ears=(14 - 16 * flick, 14),
                 cow=6 + 3 * math.sin(TAU * fa / 36.0) * live)
        little.place(Lp, yaw_l, lean=(0.0, -5.0))
        little.pose(**q)
        little.key(f)
        # the owl: half asleep, one slow blink, then its eyes stay nearly shut
        ol = kf([(619, 0.50), (640, 0.45), (652, 1.0), (660, 0.62), (still - 4, 0.78)], fa)
        owl.pose(turn=kf([(619, 9.0), (still - 6, 4.0)], fa), nod=-5.0 - 3.0 * ramp01(fa, 640, still - 4), lid=ol, lid_lo=ol * 0.5,
                 sink=0.003 * ramp01(fa, 640, still - 4), puff=1.0 + 0.018 * math.sin(TAU * fa / 52.0) * live)
        owl.key(f)
        # the camera rises up and back, and settles by `still`
        k = smooth(kit.clamp01((f - 622) / float(still - 2 - 622)))
        pos = Ps.lerp(Pe, k)
        pos.z = lerp(Ps.z, Pe.z, smooth(kit.clamp01((f - 622) / float(still - 12 - 622))))
        tgt = Ts.lerp(Te, k ** 1.4)
        if f >= still - 2:
            pos, tgt = Pe, Te
        kit.cam_key(cam, f, pos, tgt, focus=(Vector((cen.x, cen.y - 0.04, 0.05)) - pos).length, fstop=lerp(4.0, 8.0, k))
        sky.set(f)
        flies.key(f, hold=still)
    finish(ctx)


SHOTS = dict(S1=shot_s1, S2=shot_s2, S3=shot_s3, S4=shot_s4, S5=shot_s5, S6=shot_s6, S7=shot_s7)


def build_shot(ctx):
    SHOTS[ctx.id](ctx)


if __name__ == '__main__':
    harness.main(build_shot)
