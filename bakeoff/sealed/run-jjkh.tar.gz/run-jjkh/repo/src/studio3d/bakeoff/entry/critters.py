"""The owl on the wall and the snail on the stone. Both are rigid puppets like the hedgehogs (see hedgehog.py).

    owl = critters.build_owl();      owl.place((x, y, z), yaw);  owl.pose(turn=30, lid=0.2);  owl.key(frame)
    snail = critters.build_snail();  snail.place((x, y, z), yaw); snail.pose(...);            snail.key(frame)

Both face -Y at yaw 0. Their origin is the point they sit on.
"""
import math
import os
import sys

import bpy
import numpy as np
from mathutils import Matrix, Vector

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)
import hh_geom as g  # noqa: E402
import hedgehog as hh  # noqa: E402
import kit  # noqa: E402

RAD = math.radians


def vnoise(p, scale, seed=0.0):
    """Cheap smooth 3D value noise in 0..1 for mottled colours (numpy)."""
    q = np.asarray(p) * scale + seed * 17.13
    i = np.floor(q)
    f = q - i
    f = f * f * (3 - 2 * f)

    def h(ix, iy, iz):
        return np.modf(np.abs(np.sin(ix * 12.9898 + iy * 78.233 + iz * 37.719) * 43758.5453))[0]
    out = 0.0
    for dx in (0, 1):
        for dy in (0, 1):
            for dz in (0, 1):
                w = (f[:, 0] if dx else 1 - f[:, 0]) * (f[:, 1] if dy else 1 - f[:, 1]) * (f[:, 2] if dz else 1 - f[:, 2])
                out = out + w * h(i[:, 0] + dx, i[:, 1] + dy, i[:, 2] + dz)
    return out


# ================================================================================================ the owl
OWL = dict(body_c=(0.0, 0.004, 0.047), body_r=(0.043, 0.040, 0.049), head_c=(0.0, -0.001, 0.094),
           head_r=(0.045, 0.040, 0.036), eye=(0.0165, -0.0285, 0.0045), eye_r=0.0118, disc_r=0.0215)


class Owl:
    def __init__(self):
        self.o = {}

    def place(self, loc, yaw=0.0):
        self.o['root'].location = loc
        self.o['root'].rotation_euler = (0, 0, RAD(yaw))

    def pose(self, turn=0.0, tilt=0.0, nod=0.0, lid=0.3, lid_lo=None, puff=1.0, sink=0.0, look=(0.0, 0.0)):
        """turn/tilt/nod of the head in degrees. lid: 0 wide awake .. 1 closed (upper lid); lid_lo: the same for
        the lower lid (default: follows a little). puff: body scale (breathing, fluffing up). sink: the head
        sinks into the shoulders (metres). look: eyes (right, up) in degrees."""
        o = self.o
        o['body'].scale = (puff, puff, 1.0 + (puff - 1.0) * 0.6)
        o['head'].location = (0, 0, OWL['head_c'][2] - sink)
        o['head'].rotation_euler = (-RAD(nod), RAD(tilt), RAD(turn))
        lo = lid ** 1.5 if lid_lo is None else lid_lo
        up_deg = 52.0 + (-9.0 - 52.0) * lid
        lo_deg = -52.0 + (-11.0 + 52.0) * lo
        for side, s in (('L', -1), ('R', 1)):
            o['up' + side].rotation_euler = (-RAD(up_deg), s * RAD(5.0), 0)
            o['lo' + side].rotation_euler = (-RAD(lo_deg), 0, 0)
            o['ball' + side].rotation_euler = (RAD(look[1]), 0, RAD(look[0]))

    def key(self, frame):
        o = self.o
        o['root'].keyframe_insert('location', frame=frame)
        o['root'].keyframe_insert('rotation_euler', frame=frame)
        o['body'].keyframe_insert('scale', frame=frame)
        o['head'].keyframe_insert('location', frame=frame)
        for k in ('head', 'upL', 'upR', 'loL', 'loR', 'ballL', 'ballR'):
            o[k].keyframe_insert('rotation_euler', frame=frame)

    def eye_objects(self):
        return [self.o['ballL'], self.o['ballR']]

    def head_world(self):
        r = self.o['root']
        return Vector(r.location) + Vector((0, 0, OWL['head_c'][2]))


def _feathers(v, faces, sdf, n, rng, colour_fn, length, lean, flow, rad=(0.00075, 0.00016), k=4, keep=None):
    pts = g.sample_surface(v, faces, int(n * 1.3), rng)
    if keep is not None:
        pts = pts[keep(pts)]
    pts = pts[:n]
    nrm = g.grad(sdf, pts)
    L = (length(pts) if callable(length) else length) * rng.uniform(0.75, 1.15, len(pts))
    fl = flow(pts) if callable(flow) else flow
    st = g.make_strands(pts, nrm, fl, L, lean, k, rng, jitter=0.14, bend=0.25, droop=0.05)
    col = colour_fn(pts) * rng.uniform(0.9, 1.08, (len(pts), 1))
    return dict(pos=st, rad=g.strand_radius(len(pts), k, rad[0], rad[1], rng), col=g.rgba(col))


def build_owl(name='Owl', fur=1.0, seed=11):
    """A small round owl: an egg of soft feathers, a pale heart-shaped face, two big dark amber-brown eyes with
    sleepy feathered lids, a tiny beak, two small ear tufts, folded wings and little feet."""
    rng = np.random.default_rng(seed)
    owl = Owl()
    o = owl.o
    N = lambda s: name + '.' + s  # noqa: E731
    furm = hh.mat_fur(N('feather'), glow=0.22)
    under = hh.mat_skin(N('under'), sheen=0.4, rough=0.75)
    brown, dark, cream, pale = g.lin('#a17f58'), g.lin('#6e533a'), g.lin('#efe2c6'), g.lin('#f8efdb')
    rim = g.lin('#6e5138')
    thick = 1.0 / math.sqrt(max(fur, 0.05))

    root = o['root'] = kit.empty(N('root'))
    # ---- body
    bc, br = np.array(OWL['body_c']), np.array(OWL['body_r'])
    bsdf = lambda q: g.sd_ellipsoid(q, bc, br)  # noqa: E731
    dirs, faces = g.icosphere(4)
    bv = g.march(bsdf, bc, dirs, 0.09)

    def body_col(p):
        d = g.unit(p - bc)
        front = g.smoothstep(-0.10, 0.45, -d[:, 1]) * g.smoothstep(0.92, 0.50, np.abs(d[:, 0]))
        mott = vnoise(p, 260.0, 1.0)
        back = g.mix(brown, dark, 0.7 * g.smoothstep(0.45, 0.75, mott))
        back = g.mix(back, cream, 0.75 * g.smoothstep(0.80, 0.90, vnoise(p, 420.0, 3.0)))
        streak = g.smoothstep(0.62, 0.80, vnoise(p * np.array([1.0, 1.0, 0.35]), 330.0, 5.0))
        breast = g.mix(np.repeat(cream[None, :], len(p), 0), brown, 0.6 * streak)
        return g.mix(back, breast, front)
    body_piv = o['body'] = kit.empty(N('body'), root)
    bm = kit.mesh(N('body_mesh'), bv, faces, under, body_piv, body_col(bv))
    fd = _feathers(bv, faces, bsdf, int(9000 * fur), rng, body_col, 0.0085, 0.84, np.array([0.0, 0.10, -1.0]),
                   rad=(0.0012, 0.00028))
    fd['rad'] = fd['rad'] * thick
    kit.curves(N('body_fur'), fd, furm, bm)
    # ---- wings: two flat pads on the sides with darker feathers
    for s in (-1, 1):
        wc, wr = np.array([s * 0.039, 0.010, 0.050]), np.array([0.011, 0.031, 0.040])
        wsdf = lambda q, wc=wc, wr=wr: g.sd_ellipsoid(q, wc, wr)  # noqa: E731
        d3, f3 = g.icosphere(3)
        wv = g.march(wsdf, wc, d3, 0.09)

        def wing_col(p):
            m = vnoise(p, 300.0, 7.0)
            c = g.mix(dark, brown, 0.6 * m)
            return g.mix(c, cream, 0.7 * g.smoothstep(0.80, 0.90, vnoise(p, 500.0, 9.0)))
        wm = kit.mesh(N('wing%d' % s), wv, f3, under, body_piv, wing_col(wv))
        wd = _feathers(wv, f3, wsdf, int(2200 * fur), rng, wing_col, 0.013, 0.88, np.array([0.0, 0.25, -1.0]),
                       rad=(0.0014, 0.0003), keep=lambda p, s=s: p[:, 0] * s > 0.036)
        wd['rad'] = wd['rad'] * thick
        kit.curves(N('wing_fur%d' % s), wd, furm, wm)
    # ---- feet
    footm = kit.principled(N('foot'), color='#caa468', rough=0.6, spec=0.3)
    for s in (-1, 1):
        for a in (-28, 0, 28):
            ar = RAD(a)
            p0 = np.array([s * 0.014, -0.022, 0.004])
            p1 = p0 + np.array([math.sin(ar) * 0.012, -math.cos(ar) * 0.012, -0.002])
            p2 = p1 + np.array([math.sin(ar) * 0.003, -math.cos(ar) * 0.003, -0.006])
            tv, tf = kit.tube(kit.catmull([p0, p1, p2], 4), 0.0026, 10)
            kit.mesh(N('toe'), tv, tf, footm, root, subsurf=1)

    # ---- head
    hc, hr = np.array(OWL['head_c']), np.array(OWL['head_r'])
    head = o['head'] = kit.empty(N('head'), root, (0, 0, hc[2]))
    hr0 = hr
    eyes = {k: np.array([s * OWL['eye'][0], OWL['eye'][1], OWL['eye'][2]]) for k, s in (('L', -1), ('R', 1))}
    r = OWL['eye_r']

    def hbase(q):
        return g.sd_ellipsoid(q, (0, hc[1], 0), hr0)

    def hsdf(q):
        d = hbase(q)
        for c in eyes.values():
            d = g.smax(d, -(np.linalg.norm(q - c, axis=-1) - r * 1.08), 0.002)
        return d
    d5, f5 = g.icosphere(5)
    hv = g.march(hsdf, (0, hc[1], 0), d5, 0.09)

    def head_col(p):
        de = np.minimum(np.linalg.norm(p - eyes['L'], axis=1), np.linalg.norm(p - eyes['R'], axis=1))
        disc = 1 - g.smoothstep(OWL['disc_r'] * 0.86, OWL['disc_r'], de)
        ring = np.exp(-((de - OWL['disc_r']) / 0.0028) ** 2)
        mott = vnoise(p, 300.0, 2.0)
        crown = g.mix(brown, dark, 0.6 * g.smoothstep(0.45, 0.75, mott))
        crown = g.mix(crown, pale, 0.8 * g.smoothstep(0.78, 0.88, vnoise(p, 520.0, 4.0)))
        chin = g.smoothstep(-0.012, -0.026, p[:, 2]) * g.smoothstep(0.02, -0.01, p[:, 1])
        c = g.mix(crown, cream, 0.7 * chin)
        c = g.mix(c, pale, disc)
        return g.mix(c, rim, 0.75 * ring * (1 - disc * 0.5))

    def head_len(p):
        de = np.minimum(np.linalg.norm(p - eyes['L'], axis=1), np.linalg.norm(p - eyes['R'], axis=1))
        tuft = np.maximum(np.exp(-np.sum((p - np.array([-0.027, 0.000, 0.026])) ** 2, axis=1) / (2 * 0.007 ** 2)),
                          np.exp(-np.sum((p - np.array([0.027, 0.000, 0.026])) ** 2, axis=1) / (2 * 0.007 ** 2)))
        return 0.0038 + 0.0048 * g.smoothstep(OWL['disc_r'] * 0.6, OWL['disc_r'] * 1.3, de) + 0.014 * tuft

    def head_flow(p):
        fl = np.zeros_like(p)
        for c in eyes.values():
            de = np.linalg.norm(p - c, axis=1)
            fl = fl + (1 - g.smoothstep(r, OWL['disc_r'] * 1.4, de))[:, None] * g.unit(p - c) * 2.0
        tuft = np.exp(-(p[:, 2] - 0.026) ** 2 / (2 * 0.008 ** 2)) * g.smoothstep(0.012, 0.024, np.abs(p[:, 0]))
        up = np.stack([np.sign(p[:, 0]) * 0.5, np.full(len(p), 0.2), np.ones(len(p))], 1)
        return g.unit(fl + np.array([0.0, 0.55, -0.5]) + up * 2.5 * tuft[:, None])

    def head_lean(p):
        tuft = np.exp(-(p[:, 2] - 0.026) ** 2 / (2 * 0.008 ** 2)) * g.smoothstep(0.012, 0.024, np.abs(p[:, 0]))
        return 0.78 - 0.45 * tuft
    hm = kit.mesh(N('head_mesh'), hv, f5, under, head, head_col(hv))
    pts = g.sample_surface(hv, f5, int(13000 * fur * 1.25), rng)
    de = np.minimum(np.linalg.norm(pts - eyes['L'], axis=1), np.linalg.norm(pts - eyes['R'], axis=1))
    beak_c = np.array([0.0, hc[1] - hr[1] * 0.93 - 0.004, -0.0050])
    pts = pts[(np.abs(hsdf(pts)) < 0.0006) & (hbase(pts) > -0.0008) & (de > r * 1.10)
              & (np.linalg.norm((pts - beak_c) * np.array([1.0, 1.0, 0.7]), axis=1) > 0.0062)]
    nrm = g.grad(hsdf, pts)
    L = head_len(pts) * rng.uniform(0.75, 1.15, len(pts))
    st = g.make_strands(pts, nrm, head_flow(pts), L, head_lean(pts), 4, rng, jitter=0.13, bend=0.22)
    kit.curves(N('head_fur'), dict(pos=st, rad=g.strand_radius(len(pts), 4, 0.00085, 0.00018, rng) * thick,
                                   col=g.rgba(head_col(pts) * rng.uniform(0.92, 1.06, (len(pts), 1)))), furm, hm)
    # ---- beak
    beakm = kit.principled(N('beak'), color='#e6b95c', rough=0.38, spec=0.4)
    bk_v, bk_f = g.ellipsoid_mesh(0.0052, 0.0072, 0.0092, 24, 16)
    bk_v[:, 0] *= 1.0 - 0.55 * np.clip(-bk_v[:, 2] / 0.0092, 0, 1)        # narrows to a soft point below
    bk_v[:, 1] -= 0.002 * np.clip(-bk_v[:, 2] / 0.0092, 0, 1) ** 2
    bk = kit.mesh(N('beak'), bk_v, bk_f, beakm, head, loc=tuple(beak_c), subsurf=1)
    bk.rotation_euler = (RAD(-14), 0, 0)
    # ---- eyes and lids
    em = hh.mat_eye(N('eye'), iris_in='#4a2c14', iris_out='#6e4a20', dark='#150c08', glow='#7a5526')
    lid_rng = np.random.default_rng(seed + 5)
    lidc = pale * 0.96
    for side, s in (('L', -1), ('R', 1)):
        sock = o['sock' + side] = kit.empty(N('sock' + side), head, tuple(eyes[side]))
        sock.rotation_euler = (0, 0, RAD(s * 7.0))
        ev, ef = g.uv_sphere(r, 32, 16)
        o['ball' + side] = kit.mesh(N('ball' + side), ev, ef, em, sock, subsurf=1)
        for key, upper in (('up', True), ('lo', False)):
            lv, lf, lw = g.lid_wedge(r, upper, k=1.06)
            col = g.rgba(g.mix(np.repeat(lidc[None, :], len(lv), 0), rim, lw * 0.8))
            lid = o[key + side] = kit.mesh(N(key + side), lv, lf, under, sock, col)
            lfd = g.lid_fur(r, upper, 1.06, max(300, int(1100 * fur)), lid_rng, lidc)
            lfd['rad'] = lfd['rad'] * 2.2 * thick
            kit.curves(N(key + side + '_fur'), lfd, furm, lid)
    owl.pose()
    return owl


# ================================================================================================ the snail
class Snail:
    def __init__(self):
        self.o = {}

    def place(self, loc, yaw=0.0):
        self.o['root'].location = loc
        self.o['root'].rotation_euler = (0, 0, RAD(yaw))

    def pose(self, L=(0.0, 0.0), R=(0.0, 0.0), L2=(0.0, 0.0), R2=(0.0, 0.0), ext=(1.0, 1.0), shell=(0.0, 0.0),
             stretch=1.0):
        """L / R: lower joint of each eye-stalk (forward, to its right) in degrees; L2 / R2 the upper joint.
        ext: length of each stalk (1 = out, 0.5 = half drawn in). shell: (rock forward, roll) in degrees.
        stretch: the body reaching forward."""
        o = self.o
        for k, a, b, e in (('L', L, L2, ext[0]), ('R', R, R2, ext[1])):
            o['st' + k].rotation_euler = (RAD(a[0]), RAD(a[1]), 0)
            o['st' + k].scale = (1, 1, e)
            o['st' + k + '2'].rotation_euler = (RAD(b[0]), RAD(b[1]), 0)
        o['shell'].rotation_euler = (RAD(shell[0]), RAD(shell[1]), 0)
        o['body'].scale = (1.0 / math.sqrt(stretch), stretch, 1.0)

    def key(self, frame):
        o = self.o
        for k in ('stL', 'stR', 'stL2', 'stR2', 'shell'):
            o[k].keyframe_insert('rotation_euler', frame=frame)
        for k in ('stL', 'stR', 'body'):
            o[k].keyframe_insert('scale', frame=frame)

    def eye_objects(self):
        return [self.o['beadL'], self.o['beadR']]


def build_snail(name='Snail', seed=5):
    """A garden snail: a soft wet body, a glossy spiral shell with bands, two eye-stalks with bead eyes that each
    bend at two joints, two little feelers and a small smile."""
    rng = np.random.default_rng(seed)
    sn = Snail()
    o = sn.o
    N = lambda s: name + '.' + s  # noqa: E731
    root = o['root'] = kit.empty(N('root'))
    body = o['body'] = kit.empty(N('body'), root)

    # ---- body
    def bsdf(q):
        d = g.sd_roundcone(q, (0, 0.030, 0.0035), (0, 0.004, 0.0068), 0.0030, 0.0078)
        d = g.smin(d, g.sd_roundcone(q, (0, 0.004, 0.0068), (0, -0.020, 0.0085), 0.0078, 0.0062), 0.006)
        d = g.smin(d, g.sd_roundcone(q, (0, -0.020, 0.0085), (0, -0.0275, 0.0135), 0.0062, 0.0056), 0.005)
        skirt = g.sd_ellipsoid(q, (0, 0.002, 0.0010), (0.0105, 0.034, 0.0030))
        d = g.smin(d, skirt, 0.004)
        return g.smax(d, -q[..., 2], 0.0012)
    dirs, faces = g.icosphere(5)
    bv = g.march(bsdf, (0, 0.0, 0.004), dirs, 0.06)
    top, low = g.lin('#a88660'), g.lin('#dcc59c')
    w = g.smoothstep(0.002, 0.012, bv[:, 2])
    mott = vnoise(bv, 900.0, 2.0)
    col = g.mix(np.repeat(low[None, :], len(bv), 0), top, w * (0.75 + 0.25 * mott))
    bodym = kit.noise_mat(N('skin'), [(0.35, (0.82, 0.82, 0.82)), (0.7, (1.0, 1.0, 1.0))], scale=1400.0, detail=3.0,
                          rough=0.32, spec=0.5, bump=0.25, bump_scale=2200.0, attr_mul='col', coat=0.35)
    b = bodym.node_tree.nodes['Principled BSDF']
    b.inputs['Subsurface Weight'].default_value = 0.45
    b.inputs['Subsurface Radius'].default_value = (1.0, 0.6, 0.35)
    b.inputs['Subsurface Scale'].default_value = 0.004
    kit.mesh(N('body_mesh'), bv, faces, bodym, body, col, subsurf=1)
    # a small smile on the front of the head
    hc = np.array([0.0, -0.0275, 0.0135])
    pts = []
    for a in np.linspace(-40, 40, 9):
        d = g.unit(np.array([math.sin(RAD(a)) * 0.9, -math.cos(RAD(a)), -0.42 + 0.20 * (a / 40.0) ** 2]))
        pts.append(g.march(bsdf, hc, d[None, :], 0.02)[0] + d * 0.00015)
    sv, sf = kit.tube(np.array(pts), [0.00012] + [0.00030] * 7 + [0.00012], 6)
    darkm = kit.principled(N('dark'), color='#3a2418', rough=0.5, spec=0.3)
    kit.mesh(N('smile'), sv, sf, darkm, body)

    # ---- shell: a spiral tube in the snail's own Y-Z plane, with the tip pushed out to its right side
    shell = o['shell'] = kit.empty(N('shell'), root, (0.0, 0.0075, 0.0160))
    R0, bb, turns, nth, nph = 0.0150, 0.197, 2.8, 150, 16
    th = np.linspace(0.0, turns * 2 * math.pi, nth)
    rr = R0 * np.exp(-bb * th)
    ang = RAD(-30) - th                      # the mouth of the shell sits low at the front; it winds up the back
    cen = np.stack([0.9 * (R0 - rr), -np.cos(ang) * rr, np.sin(ang) * rr + 0.0140], 1)
    rho = 0.56 * rr
    tan = np.gradient(cen, axis=0)
    tan = tan / np.linalg.norm(tan, axis=1, keepdims=True)
    xax = np.array([1.0, 0.0, 0.0])
    radial = g.unit(cen - np.array([0.0, 0.0, 0.0140]) - xax * cen[:, :1] * np.array([1.0, 0, 0]))
    side = np.cross(tan, radial)
    side = side / np.linalg.norm(side, axis=1, keepdims=True)
    ph = np.linspace(0, 2 * math.pi, nph, endpoint=False)
    rings = cen[:, None, :] + rho[:, None, None] * (np.cos(ph)[None, :, None] * radial[:, None, :]
                                                    + np.sin(ph)[None, :, None] * side[:, None, :])
    sv, sf = kit.loft(list(rings), close_start=True, close_end=True)
    amber, dark, cream = g.lin('#c8894a'), g.lin('#70421f'), g.lin('#f0d9a6')
    tt = np.repeat(th, nph)
    pp = np.tile(ph, nth)
    band = np.exp(-((np.cos(pp) - 0.55) / 0.22) ** 2) + 0.7 * np.exp(-((np.cos(pp) + 0.10) / 0.16) ** 2)
    growth = 0.5 + 0.5 * np.sin(tt * 26.0 + 2.0 * np.sin(pp))
    scol = g.mix(np.repeat(amber[None, :], len(tt), 0), dark, np.clip(band, 0, 1) * 0.85)
    scol = g.mix(scol, cream, 0.35 * g.smoothstep(0.6, 1.0, growth) * (1 - np.clip(band, 0, 1)))
    scol = scol * (0.72 + 0.28 * g.smoothstep(0.0, 4.0, tt))[:, None]          # a little darker near the lip
    scol = np.concatenate([scol, np.repeat(scol[:1], len(sv) - len(scol), 0)])
    shellm = kit.noise_mat(N('shell'), [(0.3, (0.88, 0.88, 0.88)), (0.7, (1.0, 1.0, 1.0))], scale=500.0, detail=4.0,
                           rough=0.22, spec=0.5, bump=0.12, bump_scale=900.0, attr_mul='col', coat=0.6)
    kit.mesh(N('shell_mesh'), sv, sf, shellm, shell, scol, subsurf=1)

    # ---- eye-stalks (two joints each) with bead eyes, and two short feelers
    stalkm = kit.principled(N('stalk'), color='#b79a72', rough=0.35, spec=0.5, coat=0.3, sss=0.4, sss_scale=0.002)
    beadm = kit.principled(N('bead'), color='#120b08', rough=0.08, spec=0.7)
    seg = 0.0105
    for k, s in (('L', -1), ('R', 1)):
        base = (s * 0.0030, -0.0262, 0.0180)
        p1 = o['st' + k] = kit.empty(N('st' + k), body, base)
        tv, tf = kit.tube(np.array([[0, 0, -0.001], [0, 0, seg * 0.5], [0, 0, seg]]), [0.00170, 0.00150, 0.00135], 14)
        kit.mesh(N('st_mesh' + k), tv, tf, stalkm, p1, subsurf=1)
        p2 = o['st' + k + '2'] = kit.empty(N('st2' + k), p1, (0, 0, seg))
        tv, tf = kit.tube(np.array([[0, 0, -0.0006], [0, 0, seg * 0.5], [0, 0, seg]]), [0.00135, 0.00122, 0.00115], 14)
        kit.mesh(N('st_mesh2' + k), tv, tf, stalkm, p2, subsurf=1)
        ev, ef = g.uv_sphere(0.0025, 24, 14)
        o['bead' + k] = kit.mesh(N('bead' + k), ev, ef, beadm, p2, loc=(0, 0, seg + 0.0012), subsurf=1)
        fv, ff = kit.tube(kit.catmull([[0, 0, 0], [0, -0.0025, -0.0006], [0, -0.0046, -0.0018]], 4),
                          np.linspace(0.00085, 0.00068, 9), 12)
        kit.mesh(N('feeler' + k), fv, ff, stalkm, body, loc=(s * 0.0026, -0.0318, 0.0118), subsurf=1)
    sn.pose(L=(8, 8), R=(8, -8))
    return sn


def build_stone(name='Stone', loc=(0, 0, 0), r=(0.075, 0.060, 0.034), seed=9):
    """A rounded garden stone with a mossy top; its top is near z = 2 * r[2] - a little."""
    d, f = g.icosphere(5)
    n1 = vnoise(d, 2.2, seed) - 0.5
    n2 = vnoise(d, 6.0, seed + 3) - 0.5
    v = d * np.array(r) * (1.0 + 0.16 * n1 + 0.06 * n2)[:, None]
    v[:, 2] = np.where(v[:, 2] < 0, v[:, 2] * 0.35, v[:, 2])
    m = kit.noise_mat(name + '.mat', [(0.25, '#6e675c'), (0.5, '#958b7a'), (0.8, '#b7ab95')], scale=60.0, detail=6.0,
                      rough=0.85, spec=0.2, bump=0.45, bump_scale=160.0)
    nt = m.node_tree
    b = nt.nodes['Principled BSDF']
    # moss where the stone faces up
    geo = nt.nodes.new('ShaderNodeNewGeometry')
    sep = nt.nodes.new('ShaderNodeSeparateXYZ')
    nt.links.new(geo.outputs['Normal'], sep.inputs[0])
    nz = nt.nodes.new('ShaderNodeTexNoise')
    nz.inputs['Scale'].default_value = 45.0
    add = nt.nodes.new('ShaderNodeMath')
    add.operation = 'MULTIPLY_ADD'
    add.inputs[1].default_value = 0.9
    nt.links.new(nz.outputs['Fac'], add.inputs[0])
    nt.links.new(sep.outputs['Z'], add.inputs[2])
    mr = nt.nodes.new('ShaderNodeMapRange')
    mr.inputs['From Min'].default_value = 1.20
    mr.inputs['From Max'].default_value = 1.42
    nt.links.new(add.outputs[0], mr.inputs['Value'])
    mixc = nt.nodes.new('ShaderNodeMixRGB')
    src = b.inputs['Base Color'].links[0].from_socket
    nt.links.new(mr.outputs['Result'], mixc.inputs['Fac'])
    nt.links.new(src, mixc.inputs['Color1'])
    mixc.inputs['Color2'].default_value = kit.lin4('#5f7a33')
    nt.links.new(mixc.outputs['Color'], b.inputs['Base Color'])
    ob = kit.mesh(name, v, f, m, None, loc=(loc[0], loc[1], loc[2] + r[2] * 0.35), subsurf=1)
    near = v[(np.abs(v[:, 0]) < r[0] * 0.25) & (np.abs(v[:, 1]) < r[1] * 0.25)]
    return ob, float(near[:, 2].max()) + loc[2] + r[2] * 0.35
