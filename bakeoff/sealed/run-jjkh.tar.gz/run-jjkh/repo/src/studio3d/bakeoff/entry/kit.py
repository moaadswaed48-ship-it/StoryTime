"""Small Blender helpers shared by the film's modules: objects, meshes, strands, materials, easing, keys, camera.

Everything here is mechanics. Blender 5.2 names only (see docs/film/bakeoff/TECH-NOTES.md).
"""
import math

import bpy
import numpy as np
from mathutils import Euler, Matrix, Quaternion, Vector

RAD = math.radians


# ------------------------------------------------------------------------------------------------ colour
def lin(h):
    """sRGB hex -> linear RGB (numpy, 3 floats)."""
    h = h.lstrip('#')
    c = np.array([int(h[i:i + 2], 16) / 255.0 for i in (0, 2, 4)])
    return np.where(c <= 0.04045, c / 12.92, ((c + 0.055) / 1.055) ** 2.4)


def lin4(h, a=1.0):
    c = lin(h)
    return (float(c[0]), float(c[1]), float(c[2]), a)


def rgba(c):
    c = np.asarray(c, dtype=np.float32)
    return np.concatenate([c, np.ones((len(c), 1), dtype=np.float32)], axis=1)


# ------------------------------------------------------------------------------------------------ objects
def link(o):
    bpy.context.scene.collection.objects.link(o)
    return o


def empty(name, parent=None, loc=(0, 0, 0)):
    o = bpy.data.objects.new(name, None)
    o.empty_display_size = 0.01
    link(o)
    o.parent = parent
    o.location = loc
    return o


def mesh(name, verts, faces, mat=None, parent=None, col=None, loc=(0, 0, 0), subsurf=0, smooth=True):
    me = bpy.data.meshes.new(name)
    faces = faces.tolist() if hasattr(faces, 'tolist') else [tuple(f) for f in faces]
    me.from_pydata(np.asarray(verts, dtype=np.float64).tolist(), [], faces)
    me.update()
    if smooth:
        me.shade_smooth()
    if col is not None:
        a = me.attributes.new('col', 'FLOAT_COLOR', 'POINT')
        col = np.asarray(col, dtype=np.float32)
        if col.shape[1] == 3:
            col = rgba(col)
        a.data.foreach_set('color', col.ravel())
    if mat is not None:
        me.materials.append(mat)
    o = bpy.data.objects.new(name, me)
    link(o)
    o.parent = parent
    o.location = loc
    # `subsurf` is accepted and ignored: on this machine every subdivision modifier added about two seconds to the
    # first picture of a shot (about twenty seconds for one hedgehog), so shapes are built fine enough instead.
    return o


def curves(name, data, mat, parent=None, loc=(0, 0, 0)):
    """Strands from data = dict(pos (n,k,3), rad (n,k), col (n,4) per strand, optional rnd (n,))."""
    pos = np.asarray(data['pos'], dtype=np.float32)
    n, k, _ = pos.shape
    hc = bpy.data.hair_curves.new(name)
    hc.add_curves([k] * n)
    hc.position_data.foreach_set('vector', pos.ravel())
    a = hc.attributes.get('radius') or hc.attributes.new('radius', 'FLOAT', 'POINT')
    a.data.foreach_set('value', np.ascontiguousarray(data['rad'], dtype=np.float32).ravel())
    if data.get('col') is not None:
        c = hc.attributes.new('col', 'FLOAT_COLOR', 'CURVE')
        c.data.foreach_set('color', np.ascontiguousarray(data['col'], dtype=np.float32).ravel())
    if data.get('rnd') is not None:
        r = hc.attributes.new('rnd', 'FLOAT', 'CURVE')
        r.data.foreach_set('value', np.ascontiguousarray(data['rnd'], dtype=np.float32).ravel())
    hc.materials.append(mat)
    o = bpy.data.objects.new(name, hc)
    link(o)
    o.parent = parent
    o.location = loc
    return o


# ------------------------------------------------------------------------------------------------ materials
def new_mat(name):
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    nt = m.node_tree
    return m, nt, nt.nodes['Principled BSDF'], nt.nodes['Material Output']


def ramp(nt, stops):
    """Colour ramp from [(pos, rgb or hex)]."""
    r = nt.nodes.new('ShaderNodeValToRGB')
    e = r.color_ramp.elements
    stops = sorted(stops, key=lambda s: s[0])

    def c4(c):
        c = lin(c) if isinstance(c, str) else c
        return (float(c[0]), float(c[1]), float(c[2]), 1.0)
    e[0].position, e[0].color = stops[0][0], c4(stops[0][1])
    e[1].position, e[1].color = stops[-1][0], c4(stops[-1][1])
    for pos, c in stops[1:-1]:
        el = e.new(pos)
        el.color = c4(c)
    return r


def principled(name, color='#808080', rough=0.5, spec=0.5, sheen=0.0, coat=0.0, coat_rough=0.1, sss=0.0,
               sss_radius=(1.0, 0.45, 0.3), sss_scale=0.003, attr=None, metallic=0.0, emission=None, strength=0.0):
    """Principled BSDF. attr: name of a colour attribute to use as base colour instead of `color`."""
    m, nt, b, out = new_mat(name)
    if attr:
        at = nt.nodes.new('ShaderNodeAttribute')
        at.attribute_name = attr
        nt.links.new(at.outputs['Color'], b.inputs['Base Color'])
    else:
        b.inputs['Base Color'].default_value = lin4(color) if isinstance(color, str) else (*color, 1.0)
    b.inputs['Roughness'].default_value = rough
    b.inputs['Specular IOR Level'].default_value = spec
    b.inputs['Metallic'].default_value = metallic
    b.inputs['Sheen Weight'].default_value = sheen
    b.inputs['Sheen Roughness'].default_value = 0.45
    b.inputs['Coat Weight'].default_value = coat
    b.inputs['Coat Roughness'].default_value = coat_rough
    if sss > 0:
        b.inputs['Subsurface Weight'].default_value = sss
        b.inputs['Subsurface Radius'].default_value = sss_radius
        b.inputs['Subsurface Scale'].default_value = sss_scale
    if emission is not None:
        b.inputs['Emission Color'].default_value = lin4(emission) if isinstance(emission, str) else (*emission, 1.0)
        b.inputs['Emission Strength'].default_value = strength
    return m


def noise_mat(name, stops, scale=8.0, detail=4.0, rough=0.7, spec=0.3, bump=0.0, bump_scale=None, attr_mul=None,
              coat=0.0, distortion=0.0, coords='Object'):
    """Principled BSDF coloured by a noise through a ramp; optional bump from a second noise; optional multiply by a
    colour attribute (attr_mul)."""
    m, nt, b, out = new_mat(name)
    tc = nt.nodes.new('ShaderNodeTexCoord')
    nz = nt.nodes.new('ShaderNodeTexNoise')
    nz.inputs['Scale'].default_value = scale
    nz.inputs['Detail'].default_value = detail
    nz.inputs['Distortion'].default_value = distortion
    nt.links.new(tc.outputs[coords], nz.inputs['Vector'])
    r = ramp(nt, stops)
    nt.links.new(nz.outputs['Fac'], r.inputs['Fac'])
    src = r.outputs['Color']
    if attr_mul:
        at = nt.nodes.new('ShaderNodeAttribute')
        at.attribute_name = attr_mul
        mul = nt.nodes.new('ShaderNodeMixRGB')
        mul.blend_type = 'MULTIPLY'
        mul.inputs['Fac'].default_value = 1.0
        nt.links.new(src, mul.inputs['Color1'])
        nt.links.new(at.outputs['Color'], mul.inputs['Color2'])
        src = mul.outputs['Color']
    nt.links.new(src, b.inputs['Base Color'])
    b.inputs['Roughness'].default_value = rough
    b.inputs['Specular IOR Level'].default_value = spec
    b.inputs['Coat Weight'].default_value = coat
    if bump > 0:
        n2 = nt.nodes.new('ShaderNodeTexNoise')
        n2.inputs['Scale'].default_value = bump_scale or scale * 4
        n2.inputs['Detail'].default_value = 5.0
        nt.links.new(tc.outputs[coords], n2.inputs['Vector'])
        bp = nt.nodes.new('ShaderNodeBump')
        bp.inputs['Strength'].default_value = bump
        bp.inputs['Distance'].default_value = 0.01
        nt.links.new(n2.outputs['Fac'], bp.inputs['Height'])
        nt.links.new(bp.outputs['Normal'], b.inputs['Normal'])
    return m


def add_translucent(m, fac=0.3, tint=None):
    """Mix a translucent share into a material's surface (light through leaves, fur, quill tips)."""
    nt = m.node_tree
    out = nt.nodes['Material Output']
    cur = out.inputs['Surface'].links[0].from_socket
    b = nt.nodes['Principled BSDF']
    tr = nt.nodes.new('ShaderNodeBsdfTranslucent')
    if b.inputs['Base Color'].links:
        nt.links.new(b.inputs['Base Color'].links[0].from_socket, tr.inputs['Color'])
    else:
        tr.inputs['Color'].default_value = b.inputs['Base Color'].default_value
    if tint is not None:
        tr.inputs['Color'].default_value = (*tint, 1.0)
    mx = nt.nodes.new('ShaderNodeMixShader')
    mx.inputs['Fac'].default_value = fac
    nt.links.new(cur, mx.inputs[1])
    nt.links.new(tr.outputs[0], mx.inputs[2])
    nt.links.new(mx.outputs[0], out.inputs['Surface'])
    return m


def emission_mat(name, color, strength, obj_scaled=False):
    """Pure emission. obj_scaled: strength is multiplied by the object's colour alpha (object.color[3]), so each
    object can be dimmed or switched on with a keyframe."""
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    nt = m.node_tree
    nt.nodes.remove(nt.nodes['Principled BSDF'])
    em = nt.nodes.new('ShaderNodeEmission')
    em.inputs['Color'].default_value = lin4(color) if isinstance(color, str) else (*color, 1.0)
    em.inputs['Strength'].default_value = strength
    if obj_scaled:
        oi = nt.nodes.new('ShaderNodeObjectInfo')
        mul = nt.nodes.new('ShaderNodeMath')
        mul.operation = 'MULTIPLY'
        mul.inputs[1].default_value = strength
        nt.links.new(oi.outputs['Alpha'], mul.inputs[0])
        nt.links.new(mul.outputs[0], em.inputs['Strength'])
    nt.links.new(em.outputs[0], nt.nodes['Material Output'].inputs['Surface'])
    return m


# ------------------------------------------------------------------------------------------------ shapes (numpy)
def tube(path, radii, segs=12, cap=True):
    """Tube along a polyline (n,3) with per-point radius; returns verts, faces. Frames are carried along the path."""
    path = np.asarray(path, dtype=np.float64)
    n = len(path)
    radii = np.broadcast_to(np.asarray(radii, dtype=np.float64), (n,))
    verts, faces = [], []
    side = None
    for i in range(n):
        t = path[min(i + 1, n - 1)] - path[max(i - 1, 0)]
        t = t / max(np.linalg.norm(t), 1e-12)
        if side is None:
            up = np.array([0.0, 0.0, 1.0]) if abs(t[2]) < 0.9 else np.array([1.0, 0.0, 0.0])
            side = np.cross(t, up)
        else:
            side = side - t * np.dot(side, t)
        side = side / max(np.linalg.norm(side), 1e-12)
        up2 = np.cross(side, t)
        for j in range(segs):
            a = 2 * math.pi * j / segs
            verts.append(path[i] + (side * math.cos(a) + up2 * math.sin(a)) * radii[i])
    for i in range(n - 1):
        for j in range(segs):
            j2 = (j + 1) % segs
            faces.append((i * segs + j, i * segs + j2, (i + 1) * segs + j2, (i + 1) * segs + j))
    if cap:
        c0 = len(verts)
        verts.append(path[0])
        c1 = len(verts)
        verts.append(path[-1])
        for j in range(segs):
            j2 = (j + 1) % segs
            faces.append((c0, j2, j))
            faces.append((c1, (n - 1) * segs + j, (n - 1) * segs + j2))
    return np.array(verts), faces


def loft(rings, close_start=True, close_end=True):
    """Skin a list of rings (each (segs,3), same count and winding); returns verts, faces."""
    segs = len(rings[0])
    verts = np.concatenate([np.asarray(r, dtype=np.float64) for r in rings])
    faces = []
    for i in range(len(rings) - 1):
        for j in range(segs):
            j2 = (j + 1) % segs
            faces.append((i * segs + j, i * segs + j2, (i + 1) * segs + j2, (i + 1) * segs + j))
    extra = []
    if close_start:
        c = len(verts) + len(extra)
        extra.append(np.mean(rings[0], axis=0))
        for j in range(segs):
            faces.append((c, (j + 1) % segs, j))
    if close_end:
        c = len(verts) + len(extra)
        extra.append(np.mean(rings[-1], axis=0))
        base = (len(rings) - 1) * segs
        for j in range(segs):
            faces.append((c, base + j, base + (j + 1) % segs))
    if extra:
        verts = np.concatenate([verts, np.array(extra)])
    return verts, faces


def catmull(points, per=6):
    """Smooth curve through points (n,d); returns (m,d) samples including the end points."""
    p = np.asarray(points, dtype=np.float64)
    p = np.concatenate([p[:1] * 2 - p[1:2], p, p[-1:] * 2 - p[-2:-1]])
    out = []
    for i in range(1, len(p) - 2):
        for s in range(per):
            t = s / per
            t2, t3 = t * t, t * t * t
            out.append(0.5 * ((2 * p[i]) + (-p[i - 1] + p[i + 1]) * t
                              + (2 * p[i - 1] - 5 * p[i] + 4 * p[i + 1] - p[i + 2]) * t2
                              + (-p[i - 1] + 3 * p[i] - 3 * p[i + 1] + p[i + 2]) * t3))
    out.append(p[-2])
    return np.array(out)


# ------------------------------------------------------------------------------------------------ easing and keys
def clamp01(t):
    return max(0.0, min(1.0, t))


def smooth(t):
    t = clamp01(t)
    return t * t * (3.0 - 2.0 * t)


def ease_out(t):
    t = clamp01(t)
    return 1.0 - (1.0 - t) ** 3


def ease_in(t):
    t = clamp01(t)
    return t ** 3


def ramp01(f, a, b):
    """0 before frame a, 1 after frame b, smooth between."""
    if b == a:
        return 1.0 if f >= b else 0.0
    return smooth((f - a) / (b - a))


def kf(keys, f, mode='smooth'):
    """Value at frame f from keys [(frame, value), ...] (value: number or tuple). Holds before the first and after
    the last key. mode: 'smooth' (ease in and out), 'linear', 'out' (fast start, soft landing)."""
    if f <= keys[0][0]:
        return keys[0][1]
    if f >= keys[-1][0]:
        return keys[-1][1]
    for (fa, va), (fb, vb) in zip(keys[:-1], keys[1:]):
        if fa <= f <= fb:
            t = (f - fa) / float(fb - fa)
            t = smooth(t) if mode == 'smooth' else (ease_out(t) if mode == 'out' else t)
            if isinstance(va, (tuple, list)):
                return tuple(a + (b - a) * t for a, b in zip(va, vb))
            return va + (vb - va) * t
    return keys[-1][1]


def pulse(f, centre, half):
    """A smooth bump: 1 at frame `centre`, 0 at centre +- half."""
    t = abs(f - centre) / float(half)
    return 0.0 if t >= 1 else 0.5 * (1 + math.cos(math.pi * t))


def settle(f, f0, amp, period=9.0, decay=7.0):
    """A damped wobble that starts at frame f0 (0 before it): overshoot and follow-through."""
    if f < f0:
        return 0.0
    t = f - f0
    return amp * math.exp(-t / decay) * math.sin(2 * math.pi * t / period)


def lerp(a, b, t):
    if isinstance(a, (tuple, list)):
        return tuple(x + (y - x) * t for x, y in zip(a, b))
    return a + (b - a) * t


def key_obj(o, frame, loc=True, rot=True, scale=False):
    if loc:
        o.keyframe_insert('location', frame=frame)
    if rot:
        o.keyframe_insert('rotation_quaternion' if o.rotation_mode == 'QUATERNION' else 'rotation_euler', frame=frame)
    if scale:
        o.keyframe_insert('scale', frame=frame)


def key_val(owner, path, value, frame, index=-1):
    """Set and key any property (light energy, node socket default_value, camera lens ...)."""
    if index >= 0:
        getattr(owner, path)[index] = value
    else:
        setattr(owner, path, value)
    owner.keyframe_insert(path, frame=frame, index=index)


# ------------------------------------------------------------------------------------------------ camera, lights
def look_quat(loc, target, roll=0.0):
    q = (Vector(target) - Vector(loc)).to_track_quat('-Z', 'Y')
    if roll:
        q = q @ Quaternion((0, 0, 1), roll)
    return q


_LASTQ = {}


def camera(name='Cam', lens=35.0, fstop=4.0):
    cam = bpy.data.cameras.new(name)
    cam.lens = lens
    cam.sensor_width = 36
    cam.dof.use_dof = True
    cam.dof.aperture_fstop = fstop
    cam.dof.aperture_blades = 0
    cam.clip_start = 0.01
    cam.clip_end = 300
    co = bpy.data.objects.new(name, cam)
    co.rotation_mode = 'QUATERNION'
    link(co)
    bpy.context.scene.camera = co
    return co


def cam_key(co, frame, loc, target, focus=None, lens=None, fstop=None, roll=0.0):
    """Place the camera at loc looking at target and key it. focus: a point (the distance is measured along the
    lens axis) or a distance in metres."""
    co.location = loc
    q = look_quat(loc, target, roll)
    last = _LASTQ.get(co.name)
    if last is not None and last.dot(q) < 0:
        q.negate()
    _LASTQ[co.name] = q.copy()
    co.rotation_quaternion = q
    co.keyframe_insert('location', frame=frame)
    co.keyframe_insert('rotation_quaternion', frame=frame)
    cam = co.data
    if focus is not None:
        if not isinstance(focus, (int, float)):
            axis = (Vector(target) - Vector(loc)).normalized()
            focus = max(0.02, (Vector(focus) - Vector(loc)).dot(axis))
        cam.dof.focus_distance = focus
        cam.dof.keyframe_insert('focus_distance', frame=frame)
    if lens is not None:
        cam.lens = lens
        cam.keyframe_insert('lens', frame=frame)
    if fstop is not None:
        cam.dof.aperture_fstop = fstop
        cam.dof.keyframe_insert('aperture_fstop', frame=frame)


def sun_lamp(name, toward, energy, colour, angle=3.0):
    """A sun lamp. `toward` points from the scene to the lamp."""
    ld = bpy.data.lights.new(name, 'SUN')
    ld.energy = energy
    ld.angle = RAD(angle)
    ld.color = tuple(float(x) for x in (lin(colour) if isinstance(colour, str) else colour))
    o = bpy.data.objects.new(name, ld)
    link(o)
    o.rotation_euler = (-Vector(toward).normalized()).to_track_quat('-Z', 'Y').to_euler()
    return o


def area_lamp(name, loc, target, energy, colour, size=0.5, size_y=None, disk=False, spread=None):
    ld = bpy.data.lights.new(name, 'AREA')
    ld.shape = 'DISK' if disk else ('RECTANGLE' if size_y else 'SQUARE')
    ld.size = size
    if size_y:
        ld.size_y = size_y
    ld.energy = energy
    ld.color = tuple(float(x) for x in (lin(colour) if isinstance(colour, str) else colour))
    if spread is not None:
        ld.spread = spread
    o = bpy.data.objects.new(name, ld)
    link(o)
    o.location = loc
    o.rotation_euler = (Vector(target) - Vector(loc)).to_track_quat('-Z', 'Y').to_euler()
    o.visible_camera = False
    return o


def point_lamp(name, loc, energy, colour, radius=0.02):
    ld = bpy.data.lights.new(name, 'POINT')
    ld.energy = energy
    ld.shadow_soft_size = radius
    ld.color = tuple(float(x) for x in (lin(colour) if isinstance(colour, str) else colour))
    o = bpy.data.objects.new(name, ld)
    link(o)
    o.location = loc
    o.visible_camera = False
    return o


def eye_light(cam_obj, receivers, dist, radiance=60.0, rel_size=0.50, offset=(-0.42, 0.40), colour='#fff4e2'):
    """The catchlight: a soft round lamp beside the lens that only the eyes and noses receive, so the sparkle in an
    eye is a real reflection (nothing in an eye gives off light). It rides with the camera. dist: lens to face.
    Radiance is what the reflection sees; a disk of radiance L and area A needs 4*A*L watts in Blender."""
    d = rel_size * dist
    ld = bpy.data.lights.new('EyeLight', 'AREA')
    ld.shape = 'DISK'
    ld.size = d
    ld.energy = 4.0 * (math.pi * d * d / 4.0) * radiance
    ld.color = tuple(float(x) for x in lin(colour))
    o = bpy.data.objects.new('EyeLight', ld)
    link(o)
    o.parent = cam_obj
    o.location = (offset[0] * dist, offset[1] * dist, 0.0)
    o.rotation_euler = (Vector((-offset[0] * dist, -offset[1] * dist, -dist))).to_track_quat('-Z', 'Y').to_euler()
    coll = bpy.data.collections.new('EyeLit')
    for ob in receivers:
        coll.objects.link(ob)
    o.light_linking.receiver_collection = coll
    o.visible_camera = False
    return o


# ------------------------------------------------------------------------------------------------ render
def render_settings(samples=12, exposure=0.45, blur=False, shutter=0.5, bounces=4, clamp=4.0, look='AgX - Punchy',
                    quick_bvh=False):
    sc = bpy.context.scene
    c = sc.cycles
    sc.render.engine = 'CYCLES'
    c.device = 'CPU'
    c.samples = samples
    c.use_adaptive_sampling = False
    c.use_denoising = True
    c.denoiser = 'OPENIMAGEDENOISE'
    c.denoising_quality = 'BALANCED'
    c.denoising_prefilter = 'ACCURATE'
    c.denoising_input_passes = 'RGB_ALBEDO_NORMAL'
    c.max_bounces = bounces
    c.diffuse_bounces = 2
    c.glossy_bounces = 2
    c.transmission_bounces = 2
    c.transparent_max_bounces = 6
    c.volume_bounces = 0
    c.caustics_reflective = False
    c.caustics_refractive = False
    c.sample_clamp_indirect = clamp
    c.sample_clamp_direct = 0.0
    c.use_animated_seed = False
    if quick_bvh:            # test pictures: a faster-built, slower-traced acceleration structure
        try:
            c.debug_bvh_type = 'DYNAMIC_BVH'
        except Exception as ex:  # noqa: BLE001
            print('quick_bvh not available: %r' % (ex,), flush=True)
    c.seed = 7
    sc.cycles_curves.shape = 'RIBBONS'
    sc.cycles_curves.subdivisions = 2
    sc.render.use_persistent_data = True
    sc.render.use_motion_blur = blur
    sc.render.motion_blur_shutter = shutter
    sc.render.film_transparent = False
    sc.view_settings.view_transform = 'AgX'
    sc.view_settings.look = look
    sc.view_settings.exposure = exposure
    sc.render.dither_intensity = 1.0


def bloom(threshold=1.6, strength=0.25, size=0.35):
    """A soft glow on the brightest things (window, fireflies, sunlit rims). Compositor on the processor."""
    sc = bpy.context.scene
    try:
        ng = bpy.data.node_groups.new('Bloom', 'CompositorNodeTree')
        ng.interface.new_socket('Image', in_out='OUTPUT', socket_type='NodeSocketColor')
        rl = ng.nodes.new('CompositorNodeRLayers')
        gl = ng.nodes.new('CompositorNodeGlare')
        go = ng.nodes.new('NodeGroupOutput')
        gl.inputs['Type'].default_value = 'Bloom'
        gl.inputs['Threshold'].default_value = threshold
        gl.inputs['Strength'].default_value = strength
        gl.inputs['Size'].default_value = size
        ng.links.new(rl.outputs['Image'], gl.inputs['Image'])
        ng.links.new(gl.outputs['Image'], go.inputs[0])
        sc.compositing_node_group = ng
        sc.render.use_compositing = True
        sc.render.compositor_device = 'CPU'
        return True
    except Exception as ex:  # noqa: BLE001
        print('BLOOM not set up: %r' % (ex,), flush=True)
        try:
            sc.compositing_node_group = None
        except Exception:  # noqa: BLE001
            pass
        return False


def T(v):
    return Matrix.Translation(Vector(v))


def Rx(deg):
    return Matrix.Rotation(RAD(deg), 4, 'X')


def Ry(deg):
    return Matrix.Rotation(RAD(deg), 4, 'Y')


def Rz(deg):
    return Matrix.Rotation(RAD(deg), 4, 'Z')


def Sc(v):
    if isinstance(v, (int, float)):
        v = (v, v, v)
    return Matrix.Diagonal((v[0], v[1], v[2], 1.0))


def E(deg, order='XYZ'):
    return Euler([RAD(a) for a in deg], order).to_matrix().to_4x4()
