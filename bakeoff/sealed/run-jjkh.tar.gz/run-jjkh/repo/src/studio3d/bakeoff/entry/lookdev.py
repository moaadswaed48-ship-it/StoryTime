"""Test stills of the cast (not part of the film): run through the wrapper.

    bash REPO/studio/scripts/bakeoff/blender.sh look -- --python REPO/src/studio3d/bakeoff/entry/lookdev.py -- \
        --out WS/out/look --set face,family,sleep [--night] [--res 640x360] [--samples 12]
"""
import argparse
import math
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import bpy  # noqa: E402
from mathutils import Vector  # noqa: E402

import critters  # noqa: E402
import garden as G  # noqa: E402
import hedgehog as hh  # noqa: E402
import kit  # noqa: E402


def main():
    argv = sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else []
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', required=True)
    ap.add_argument('--set', default='face')
    ap.add_argument('--res', default='640x360')
    ap.add_argument('--samples', type=int, default=12)
    ap.add_argument('--fur', type=float, default=1.0)
    ap.add_argument('--night', action='store_true')
    a = ap.parse_args(argv)
    w, h = (int(v) for v in a.res.split('x'))
    os.makedirs(a.out, exist_ok=True)
    bpy.ops.wm.read_factory_settings(use_empty=True)
    t0 = time.time()
    G.ground()
    G.stone_wall(x0=-2.5, x1=2.5)
    G.backdrop()
    sky = G.Sky()
    G.grass([dict(rect=(-1.2, -1.2, 1.2, 1.2), n=24000, h=(0.018, 0.038))], short=[(0, 0, 0.17), (0.3, 0.05, 0.16)],
            focus=(0, -0.3), seed=3)
    if a.night:
        kit.sun_lamp('Moon', G.MOON_DIR, 1.0, '#a9c0ff', 7.0)
        sky.set_night(1.0)
        sky.stars.outputs[0].default_value = 1.0
        sky.amb.outputs[0].default_value = 0.115
        kit.area_lamp('Window', (2.0, 3.0, 1.0), (0, 0, 0.1), 170.0, '#ffab5c', size=0.9, size_y=1.2)
        kit.area_lamp('Bounce', (0.6, -0.9, 0.5), (0, 0, 0.06), 3.0, '#ffc890', size=0.7)
    else:
        kit.sun_lamp('Sun', G.SUN_DIR, 4.8, '#ffb070', 3.0)
        kit.sun_lamp('Rim', G.RIM_DIR, 2.6, '#ffc9a6', 6.0)
        sky.amb.outputs[0].default_value = 0.36
        kit.area_lamp('Bounce', (0.6, -1.0, 0.45), (0, 0, 0.06), 6.0, '#ffd2ac', size=0.9)
    little = hh.build_hedgehog('little', fur=a.fur)
    mama = hh.build_hedgehog('mama', fur=a.fur)
    owl = critters.build_owl()
    owl.place((-0.35, 1.585, G.WALL_H + 0.012), 0.0)
    owl.pose(lid=0.3, turn=-15)
    print('LOOK build %.1f s' % (time.time() - t0), flush=True)
    cam = kit.camera('Cam', 50.0, 5.6)
    recv = little.eye_objects() + mama.eye_objects() + owl.eye_objects()
    eye = kit.eye_light(cam, recv, 0.6, radiance=38.0 if a.night else 70.0)
    kit.render_settings(samples=a.samples)
    kit.bloom(1.5, 0.22, 0.35)
    sc = bpy.context.scene
    sc.render.resolution_x, sc.render.resolution_y = w, h
    sc.render.image_settings.file_format = 'PNG'
    sc.render.compositor_device = 'CPU'
    far = (5.0, 5.0, 0.0)

    def shoot(name, pos, tgt, lens, fstop, focus):
        cam.data.lens = lens
        cam.data.dof.aperture_fstop = fstop
        cam.location = pos
        cam.rotation_quaternion = kit.look_quat(pos, tgt)
        cam.data.dof.focus_distance = (Vector(focus) - Vector(pos)).length
        sc.render.filepath = os.path.join(a.out, name + '.png')
        t1 = time.time()
        bpy.ops.render.render(write_still=True)
        print('LOOK %s %.1f s' % (name, time.time() - t1), flush=True)

    for s in a.set.split(','):
        if s == 'face':        # Little close, curious eyes at the lens
            mama.place(far)
            little.place((0, 0, 0), 12.0)
            little.pose(**hh.POSES['sit_curious'])
            pos = (0.06, -0.42, 0.105)
            little.look_at(pos)
            shoot('face', pos, tuple(little.eyes_mid() - Vector((0, 0, 0.012))), 85.0, 8.0, tuple(little.eyes_mid()))
        elif s == 'giggle':
            mama.place(far)
            little.place((0, 0, 0), -20.0)
            little.pose(**hh.POSES['sit_giggle'])
            pos = (0.10, -0.55, 0.09)
            shoot('giggle', pos, (0, 0, 0.065), 60.0, 5.6, tuple(little.eyes_mid()))
        elif s == 'family':    # both standing, side by side, three-quarter and side on, small in the picture
            mama.place((-0.02, 0.05, 0), 70.0)
            mama.pose(**hh.POSES['stand'])
            little.place((0.24, -0.02, 0), -55.0)
            little.pose(**hh.POSES['stand'])
            little.look_at(mama.eyes_mid())
            mama.look_at(little.eyes_mid())
            pos = (0.18, -0.95, 0.12)
            shoot('family', pos, (0.10, 0, 0.07), 50.0, 5.6, (0.1, 0, 0.07))
        elif s == 'sleep':     # the sleeping curl seen from a high angle, and the ball
            mama.place((-0.05, 0.08, 0), 96.0)
            p = dict(hh.POSES['sleep'])
            p.update(head=(-9, -34, -10), slide=(0.004, -0.013, -0.027))
            mama.pose(**p)
            little.place((-0.02, -0.05, 0), 84.0)
            q = dict(hh.POSES['sleep'])
            q.update(head=(-6, -30, -12), slide=(0.003, -0.012, -0.027))
            little.pose(**q)
            pos = (0.06, -0.44, 0.36)
            shoot('sleep', pos, (0.02, 0.02, 0.035), 28.0, 4.0, (0.02, 0.0, 0.04))
        elif s == 'ball':
            mama.place(far)
            little.place((0, 0, 0), 60.0)
            little.pose(**hh.POSES['ball'])
            pos = (0.10, -0.50, 0.14)
            shoot('ball', pos, (0, 0, 0.05), 60.0, 5.6, (0, 0, 0.05))
        elif s == 'mama':      # Mama close, covering her eyes and peeking
            little.place(far)
            mama.place((0, 0, 0), 10.0)
            sys.path.insert(0, HERE)
            import film
            film.mama_count(mama, 168, (0.05, -0.85, 0.14))
            pos = (0.05, -0.85, 0.14)
            shoot('mama', pos, (0.0, 0.0, 0.148), 85.0, 5.6, tuple(mama.eyes_mid()))
        elif s == 'back':      # from behind and above
            mama.place(far)
            little.place((0, 0, 0), 150.0)
            little.pose(**hh.POSES['stand'])
            pos = (0.12, -0.45, 0.22)
            shoot('back', pos, (0, 0, 0.05), 60.0, 5.6, (0, 0, 0.06))
        elif s == 'owl':
            pos = (-0.25, 0.95, 0.40)
            shoot('owl', pos, (-0.35, 1.585, G.WALL_H + 0.065), 85.0, 5.6, (-0.35, 1.55, G.WALL_H + 0.08))
    print('LOOK total %.1f s' % (time.time() - t0), flush=True)


if __name__ == '__main__':
    main()
