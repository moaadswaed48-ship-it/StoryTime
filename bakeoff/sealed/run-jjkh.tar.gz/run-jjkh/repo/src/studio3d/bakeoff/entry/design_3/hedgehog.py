"""Design 3, Little Hedgehog: builds the character into the current Blender scene (Blender 5.2, Cycles).

    import hedgehog
    rig = hedgehog.build_hedgehog('little')            # or 'mama' (same build, her numbers; see README notes)
    rig.pose(**hedgehog.POSES['sit_giggle'])           # set a whole pose
    rig.look_at(camera.matrix_world.translation)       # eyes
    rig.key(frame)                                     # keyframe every control at that frame

The character is a puppet of rigid furry pieces (no skinning, no shape keys), so fur never has to follow a
deforming skin and a frame never depends on the one before it. Controls are plain objects in `rig.o`:

    root          the ground point under the body; move/turn/scale the whole character here (bounce = root.location.z)
    hip           body pitch (set through pose(); the body is put back on the ground automatically)
    head          head turn/tilt/nod in the root's axes, and head.location slides the head on the body
    jaw           rotation_euler.x opens the mouth (radians, about 0 .. 0.5)
    nose          scale or turn for a twitch
    ballL/ballR   the eyeballs (use look_at)
    upL/upR, loL/loR   eyelids (use lids())
    earL/earR     ear pivots
    pawFL/pawFR   front paws, children of the body; pawHL/pawHR hind paws, children of the root.
                  The short legs follow the paws by themselves.

"L" is the character's side at -X (screen left when he faces the camera), "R" is +X.

Notes for whoever builds the film with this:
  * Cost, measured on the design stills (1280x720, 24 samples, the grass patch in patch.py, fur=1.0): 52 to 67 s a
    picture. For the film use fewer samples and fur=0.5 or less away from close-ups; the face close-up costs most.
  * He is small (about 12 cm sitting up), so real lens numbers give a razor-thin focus: the stills use f/4 at 50 mm
    and f/8 at 85 mm to keep both eyes and the nose sharp.
  * The catchlights in the eyes are painted (a little emission), so they do not dim with the light: at night call
    rig.set_catchlight(1.0 or less).
  * Poses that exist and were looked at: POSES 'sit_giggle', 'sit_curious', 'sniff' (Little, three stills) and
    'stand' (Little and Mama, one small test picture). A curled-up ball pose does NOT exist yet.
  * 'mama' was only seen once, small. Treat her numbers in hh_geom.params() as a first pass.
"""
import math
import os
import sys

import bpy
import numpy as np
from mathutils import Euler, Matrix, Quaternion, Vector

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)
import hh_geom as g  # noqa: E402

RAD = math.radians

# ------------------------------------------------------------------------------------------------ small builders


def _link(o):
    bpy.context.scene.collection.objects.link(o)
    return o


def _empty(name, parent=None, loc=(0, 0, 0)):
    o = bpy.data.objects.new(name, None)
    o.empty_display_size = 0.01
    _link(o)
    o.parent = parent
    o.location = loc
    return o


def _mesh(name, verts, faces, mat=None, parent=None, col=None, loc=(0, 0, 0), subsurf=0):
    me = bpy.data.meshes.new(name)
    faces = faces.tolist() if hasattr(faces, 'tolist') else [tuple(f) for f in faces]
    me.from_pydata(np.asarray(verts, dtype=np.float64).tolist(), [], faces)
    me.update()
    me.shade_smooth()
    if col is not None:
        a = me.attributes.new('col', 'FLOAT_COLOR', 'POINT')
        a.data.foreach_set('color', np.asarray(col, dtype=np.float32).ravel())
    if mat is not None:
        me.materials.append(mat)
    o = bpy.data.objects.new(name, me)
    _link(o)
    o.parent = parent
    o.location = loc
    if subsurf:
        m = o.modifiers.new('subd', 'SUBSURF')
        m.levels = 1
        m.render_levels = subsurf
    return o


def _curves(name, data, mat, parent, loc=(0, 0, 0)):
    pos = np.asarray(data['pos'], dtype=np.float32)
    n, k, _ = pos.shape
    hc = bpy.data.hair_curves.new(name)
    hc.add_curves([k] * n)
    hc.position_data.foreach_set('vector', pos.ravel())
    a = hc.attributes.get('radius') or hc.attributes.new('radius', 'FLOAT', 'POINT')
    a.data.foreach_set('value', np.asarray(data['rad'], dtype=np.float32).ravel())
    c = hc.attributes.new('col', 'FLOAT_COLOR', 'CURVE')
    c.data.foreach_set('color', np.asarray(data['col'], dtype=np.float32).ravel())
    hc.materials.append(mat)
    o = bpy.data.objects.new(name, hc)
    _link(o)
    o.parent = parent
    o.location = loc
    return o


def _flat(c, n):
    return g.rgba(np.repeat(np.asarray(c)[None, :], n, 0))


# ------------------------------------------------------------------------------------------------ materials


def _new_mat(name):
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    nt = m.node_tree
    return m, nt, nt.nodes['Principled BSDF'], nt.nodes['Material Output']


def mat_skin(name, sss=0.0, sheen=0.4, rough=0.6, coat=0.0):
    """Bare skin, or the skin under fur: colour comes from the 'col' attribute of the mesh."""
    m, nt, b, out = _new_mat(name)
    at = nt.nodes.new('ShaderNodeAttribute')
    at.attribute_name = 'col'
    nt.links.new(at.outputs['Color'], b.inputs['Base Color'])
    b.inputs['Roughness'].default_value = rough
    b.inputs['Sheen Weight'].default_value = sheen
    b.inputs['Sheen Roughness'].default_value = 0.45
    b.inputs['Specular IOR Level'].default_value = 0.3
    b.inputs['Coat Weight'].default_value = coat
    b.inputs['Coat Roughness'].default_value = 0.15
    if sss > 0:
        b.inputs['Subsurface Weight'].default_value = sss
        b.inputs['Subsurface Radius'].default_value = (1.0, 0.45, 0.3)
        b.inputs['Subsurface Scale'].default_value = 0.003
    return m


def mat_fur(name, glow=0.32):
    """Soft fur on thin strands: a matte, slightly velvety surface with light coming through the edges.
    Cheap on purpose (no hair shader): see TECH-NOTES rows 14 and 33."""
    m, nt, b, out = _new_mat(name)
    at = nt.nodes.new('ShaderNodeAttribute')
    at.attribute_name = 'col'
    hi = nt.nodes.new('ShaderNodeHairInfo')
    mr = nt.nodes.new('ShaderNodeMapRange')
    mr.inputs['To Min'].default_value = 0.80
    mr.inputs['To Max'].default_value = 1.22
    nt.links.new(hi.outputs['Intercept'], mr.inputs['Value'])
    sc = nt.nodes.new('ShaderNodeVectorMath')
    sc.operation = 'SCALE'
    nt.links.new(at.outputs['Color'], sc.inputs[0])
    nt.links.new(mr.outputs['Result'], sc.inputs['Scale'])
    nt.links.new(sc.outputs['Vector'], b.inputs['Base Color'])
    b.inputs['Roughness'].default_value = 0.72
    b.inputs['Sheen Weight'].default_value = 0.35
    b.inputs['Sheen Roughness'].default_value = 0.4
    b.inputs['Specular IOR Level'].default_value = 0.15
    tr = nt.nodes.new('ShaderNodeBsdfTranslucent')
    nt.links.new(sc.outputs['Vector'], tr.inputs['Color'])
    mx = nt.nodes.new('ShaderNodeMixShader')
    mx.inputs['Fac'].default_value = glow
    nt.links.new(b.outputs[0], mx.inputs[1])
    nt.links.new(tr.outputs[0], mx.inputs[2])
    nt.links.new(mx.outputs[0], out.inputs['Surface'])
    return m


def mat_spines(name, colour):
    """Spines: dark at the root, the cast's brown in the middle, a pale soft tip that catches the rim light."""
    m, nt, b, out = _new_mat(name)
    c = g.lin(colour)
    hi = nt.nodes.new('ShaderNodeHairInfo')
    ramp = nt.nodes.new('ShaderNodeValToRGB')
    e = ramp.color_ramp.elements
    e[0].position, e[0].color = 0.0, (*(c * 0.30), 1)
    e[1].position, e[1].color = 1.0, (*g.lin('#f3e3c4'), 1)
    for pos, col in ((0.30, c * 0.62), (0.60, c), (0.80, g.mix(c, g.lin('#e8cfa4'), np.array(0.55)))):
        el = ramp.color_ramp.elements.new(pos)
        el.color = (*col, 1)
    nt.links.new(hi.outputs['Intercept'], ramp.inputs['Fac'])
    at = nt.nodes.new('ShaderNodeAttribute')
    at.attribute_name = 'col'
    mul = nt.nodes.new('ShaderNodeMixRGB')
    mul.blend_type = 'MULTIPLY'
    mul.inputs['Fac'].default_value = 1.0
    nt.links.new(ramp.outputs['Color'], mul.inputs['Color1'])
    nt.links.new(at.outputs['Color'], mul.inputs['Color2'])
    nt.links.new(mul.outputs['Color'], b.inputs['Base Color'])
    b.inputs['Roughness'].default_value = 0.42
    b.inputs['Specular IOR Level'].default_value = 0.35
    b.inputs['Sheen Weight'].default_value = 0.15
    tr = nt.nodes.new('ShaderNodeBsdfTranslucent')
    nt.links.new(mul.outputs['Color'], tr.inputs['Color'])
    mx = nt.nodes.new('ShaderNodeMixShader')
    mx.inputs['Fac'].default_value = 0.16
    nt.links.new(b.outputs[0], mx.inputs[1])
    nt.links.new(tr.outputs[0], mx.inputs[2])
    nt.links.new(mx.outputs[0], out.inputs['Surface'])
    return m


def mat_eye(name, socket, h1, h2, catch=3.0):
    """A big dark, wet eye. The iris is drawn around the eyeball's own -Y axis, so turning the eyeball moves
    the gaze. Two soft catchlights are drawn in the socket's space, so they stay put when the eye turns.
    They are a painted reflection, not a light: `catch` is their brightness (lower it at night)."""
    m, nt, b, out = _new_mat(name)
    Lk = nt.links.new

    def math_node(op, a=None, bval=None):
        n = nt.nodes.new('ShaderNodeMath')
        n.operation = op
        if a is not None:
            Lk(a, n.inputs[0])
        if bval is not None:
            if isinstance(bval, (int, float)):
                n.inputs[1].default_value = bval
            else:
                Lk(bval, n.inputs[1])
        return n

    def map_range(src, a, bb, c, d, smooth=False):
        n = nt.nodes.new('ShaderNodeMapRange')
        if smooth:
            n.interpolation_type = 'SMOOTHSTEP'
        n.clamp = True
        Lk(src, n.inputs['Value'])
        n.inputs['From Min'].default_value = a
        n.inputs['From Max'].default_value = bb
        n.inputs['To Min'].default_value = c
        n.inputs['To Max'].default_value = d
        return n

    def dot(vec_out, v):
        n = nt.nodes.new('ShaderNodeVectorMath')
        n.operation = 'DOT_PRODUCT'
        Lk(vec_out, n.inputs[0])
        n.inputs[1].default_value = tuple(v)
        return n

    tc = nt.nodes.new('ShaderNodeTexCoord')
    nrm = nt.nodes.new('ShaderNodeVectorMath')
    nrm.operation = 'NORMALIZE'
    Lk(tc.outputs['Object'], nrm.inputs[0])
    c = dot(nrm.outputs['Vector'], (0, -1, 0))
    t = map_range(c.outputs['Value'], 0.55, 1.0, 0.0, 1.0)
    ramp = nt.nodes.new('ShaderNodeValToRGB')
    e = ramp.color_ramp.elements
    e[0].position, e[0].color = 0.0, (*g.lin('#b9ab9a'), 1)
    e[1].position, e[1].color = 1.0, (*g.lin('#050303'), 1)
    for pos, col in ((0.27, '#ddd2c2'), (0.345, '#120a07'), (0.50, '#3f2414'), (0.68, '#5a3820'), (0.745, '#050303')):
        el = ramp.color_ramp.elements.new(pos)
        el.color = (*g.lin(col), 1)
    Lk(t.outputs['Result'], ramp.inputs['Fac'])
    # the lower half of the iris glows a little warmer, as if lit through the cornea from above
    mask = nt.nodes.new('ShaderNodeValToRGB')
    e = mask.color_ramp.elements
    e[0].position, e[0].color = 0.36, (0, 0, 0, 1)
    e[1].position, e[1].color = 0.74, (0, 0, 0, 1)
    for pos in (0.44, 0.66):
        el = mask.color_ramp.elements.new(pos)
        el.color = (1, 1, 1, 1)
    Lk(t.outputs['Result'], mask.inputs['Fac'])
    sep = nt.nodes.new('ShaderNodeSeparateXYZ')
    Lk(nrm.outputs['Vector'], sep.inputs[0])
    low = map_range(sep.outputs['Z'], 0.15, -0.5, 0.0, 0.45)
    f = math_node('MULTIPLY', mask.outputs['Color'], low.outputs['Result'])
    base = nt.nodes.new('ShaderNodeMixRGB')
    Lk(f.outputs[0], base.inputs['Fac'])
    Lk(ramp.outputs['Color'], base.inputs['Color1'])
    base.inputs['Color2'].default_value = (*g.lin('#8f5c2e'), 1)
    # catchlights
    tc2 = nt.nodes.new('ShaderNodeTexCoord')
    tc2.object = socket
    n2 = nt.nodes.new('ShaderNodeVectorMath')
    n2.operation = 'NORMALIZE'
    Lk(tc2.outputs['Object'], n2.inputs[0])
    s1 = map_range(dot(n2.outputs['Vector'], h1).outputs['Value'], 0.961, 0.990, 0.0, 1.0, True)
    s2 = map_range(dot(n2.outputs['Vector'], h2).outputs['Value'], 0.9905, 0.9975, 0.0, 0.7, True)
    mx = math_node('MAXIMUM', s1.outputs['Result'], s2.outputs['Result'])
    lit = nt.nodes.new('ShaderNodeMixRGB')
    Lk(mx.outputs[0], lit.inputs['Fac'])
    Lk(base.outputs['Color'], lit.inputs['Color1'])
    lit.inputs['Color2'].default_value = (1, 1, 1, 1)
    Lk(lit.outputs['Color'], b.inputs['Base Color'])
    em = math_node('MULTIPLY', mx.outputs[0], catch)
    em.label = 'catch'
    em.name = 'catch'
    b.inputs['Emission Color'].default_value = (1.0, 0.97, 0.92, 1)
    Lk(em.outputs[0], b.inputs['Emission Strength'])
    b.inputs['Roughness'].default_value = 0.14
    b.inputs['Specular IOR Level'].default_value = 0.28
    b.inputs['Coat Weight'].default_value = 0.28
    b.inputs['Coat Roughness'].default_value = 0.03
    return m


def mat_nose(name):
    m, nt, b, out = _new_mat(name)
    b.inputs['Base Color'].default_value = (*g.lin('#3a2521'), 1)
    b.inputs['Roughness'].default_value = 0.42
    b.inputs['Coat Weight'].default_value = 0.35
    b.inputs['Coat Roughness'].default_value = 0.16
    b.inputs['Subsurface Weight'].default_value = 0.2
    b.inputs['Subsurface Radius'].default_value = (1.0, 0.4, 0.3)
    b.inputs['Subsurface Scale'].default_value = 0.002
    return m


# ------------------------------------------------------------------------------------------------ poses

# Paws are given in the root's space (metres at size 1; z = 0 is the ground) as (x, y, z) or (x, y, z, rx, ry, rz) in
# degrees. Lids are the elevation of the lid margin in degrees: 0 is the middle of the eye; a wide-open eye is about
# up 50 / lo -50; closed is up -14 / lo -16.
POSES = {
    # on all fours, relaxed
    'stand': dict(pitch=6, clear=0.006, head=(4, 0, 0), slide=(0, -0.016, -0.016), jaw=0, lid_up=46, lid_lo=-50,
                  paws=dict(FL=(-0.024, -0.048, 0.0045), FR=(0.024, -0.048, 0.0045),
                            HL=(-0.031, 0.030, 0.0056, 0, 0, -14), HR=(0.031, 0.030, 0.0056, 0, 0, 14))),
    # sitting up, front paws by the cheeks, laughing: who he is
    'sit_giggle': dict(pitch=52, clear=-0.002, head=(6, 10, 9), slide=(0, -0.012, 0.010), jaw=24, lid_up=46,
                       lid_lo=-30, lid_tilt=9, ears=(10, 10),
                       paws=dict(FL=(-0.015, -0.023, 0.090, -80, 0, 200), FR=(0.028, -0.016, 0.087, -80, 0, 160),
                                 HL=(-0.031, -0.004, 0.0056, 0, 0, -28), HR=(0.031, -0.004, 0.0056, 0, 0, 28))),
    # sitting up, paws held together at the chest, wide curious eyes and a small open smile
    'sit_curious': dict(pitch=50, clear=-0.002, head=(-3, 8, -7), slide=(0, -0.012, 0.010), jaw=9, lid_up=52,
                        lid_lo=-46, lid_tilt=5, ears=(-8, -8),
                        paws=dict(FL=(-0.010, -0.025, 0.066, 35, 0, -10), FR=(0.009, -0.025, 0.068, 35, 0, 10),
                                  HL=(-0.031, -0.004, 0.0056, 0, 0, -28), HR=(0.031, -0.004, 0.0056, 0, 0, 28))),
    # on all fours, nose lifted, eyes closed: sniffing the evening air
    'sniff': dict(pitch=13, clear=0.006, head=(34, 0, 0), slide=(0, -0.021, -0.006), jaw=5, lid_up=-12, lid_lo=-15,
                  lid_tilt=4, ears=(-6, -6), nose=1.1,
                  paws=dict(FL=(-0.024, -0.052, 0.0045), FR=(0.024, -0.047, 0.0045),
                            HL=(-0.031, 0.030, 0.0056, 0, 0, -14), HR=(0.031, 0.034, 0.0056, 0, 0, 14))),
}


class Hedgehog:
    """Handles of one built character. See the top of this file."""

    def __init__(self, P):
        self.P = P
        self.o = {}

    # -------------------------------------------------------------------------------------------- posing
    def pose(self, pitch=6.0, clear=0.006, head=(0.0, 0.0, 0.0), slide=(0.0, -0.016, -0.016), jaw=0.0,
             lid_up=46.0, lid_lo=-50.0, lid_tilt=6.0, ears=(0.0, 0.0), nose=1.0, paws=None, gaze=None):
        """pitch: body nose-up in degrees (6 on all fours, about 50 sitting up). clear: gap under the body.
        head = (nod up, turn toward +X, tilt top toward +X) in degrees, in the root's axes. slide moves the head
        on the body. jaw in degrees. ears = (L, R) degrees outward: positive droops, negative perks up.
        Lids and paws as described above POSES."""
        o, P = self.o, self.P
        hp = P['hip']
        o['hip'].rotation_euler = (-RAD(pitch), 0, 0)
        o['hip'].location = (0, hp[1], 0.05)
        o['neck'].rotation_euler = (RAD(pitch), 0, 0)
        o['head'].location = slide
        o['head'].rotation_euler = (-RAD(head[0]), RAD(head[2]), RAD(head[1]))
        o['jaw'].rotation_euler = (RAD(jaw), 0, 0)
        o['nose'].scale = (nose, nose, nose)
        self.lids(lid_up, lid_lo, lid_tilt)
        o['earL'].rotation_euler = (0, -RAD(ears[0]), 0)
        o['earR'].rotation_euler = (0, RAD(ears[1]), 0)
        self.ground(clear)
        for k, v in (paws or {}).items():
            self.place_paw(k, v[:3], v[3:] if len(v) > 3 else (0, 0, 0))
        bpy.context.view_layer.update()
        self.look_at(gaze)

    def ground(self, clear=0.006):
        """Slide the hip up or down so the lowest point of the body is `clear` above the root's ground."""
        vl = bpy.context.view_layer
        vl.update()
        M = np.array(self.o['root'].matrix_world.inverted() @ self.o['body'].matrix_world)
        z = self._body_verts @ M[2, :3] + M[2, 3]
        self.o['hip'].location.z += clear - float(z.min())
        vl.update()

    def place_paw(self, key, loc, rot=(0, 0, 0)):
        """Put a paw at a point of the root's space, whatever it is parented to."""
        paw = self.o['paw' + key]
        s = 1.25 if key[0] == 'H' else 0.95
        M = Matrix.Translation(Vector(loc)) @ Euler([RAD(a) for a in rot], 'XYZ').to_matrix().to_4x4() @ Matrix.Scale(s, 4)
        bpy.context.view_layer.update()
        paw.matrix_world = self.o['root'].matrix_world @ M

    def lids(self, up=46.0, lo=-50.0, tilt=6.0):
        """up / lo: one number for both eyes or (L, R). tilt lowers the outer corners (soft, sweet); negative
        lowers the inner corners (cross, determined)."""
        up = up if isinstance(up, (tuple, list)) else (up, up)
        lo = lo if isinstance(lo, (tuple, list)) else (lo, lo)
        for i, (side, s) in enumerate((('L', -1), ('R', 1))):
            self.o['up' + side].rotation_euler = (-RAD(up[i]), s * RAD(tilt), 0)
            self.o['lo' + side].rotation_euler = (-RAD(lo[i]), 0, 0)

    def look_at(self, target=None, diverge=9.0, limit=30.0):
        """Aim both eyes at a world point (None: straight ahead of the head). A few degrees of outward drift keep
        eyes on the sides of a head from looking crossed. The gaze never leaves the head's forward direction by
        more than `limit` degrees: past that the dark iris slides away and the eye shows mostly pale white, which
        looks wrong on him (turn the head toward the target instead)."""
        bpy.context.view_layer.update()
        head = self.o['head']
        if target is None:
            target = head.matrix_world @ Vector((0, -0.8, 0))
        ahead = head.matrix_world.to_3x3() @ Vector((0, -1, 0))
        for side, s in (('L', -1), ('R', 1)):
            sock = self.o['sock' + side]
            d = (sock.matrix_world.inverted() @ Vector(target)).normalized()
            fwd = (sock.matrix_world.inverted().to_3x3() @ ahead).normalized()
            ang = fwd.angle(d, 0.0)
            if ang > RAD(limit):
                d = fwd.slerp(d, RAD(limit) / ang).normalized()
            q = Quaternion((0, 0, 1), RAD(s * diverge)) @ d.to_track_quat('-Y', 'Z')
            self.o['ball' + side].rotation_quaternion = q

    def set_catchlight(self, strength):
        for m in self._eye_mats:
            m.node_tree.nodes['catch'].inputs[1].default_value = strength

    def controls(self):
        return [self.o[k] for k in ('root', 'hip', 'neck', 'head', 'jaw', 'nose', 'ballL', 'ballR', 'upL', 'upR', 'loL',
                                    'loR', 'earL', 'earR', 'pawFL', 'pawFR', 'pawHL', 'pawHR')]

    def key(self, frame):
        """Keyframe every control at this frame (call after pose / look_at / your own edits)."""
        for ob in self.controls():
            ob.keyframe_insert('location', frame=frame)
            ob.keyframe_insert('scale', frame=frame)
            ob.keyframe_insert('rotation_quaternion' if ob.rotation_mode == 'QUATERNION' else 'rotation_euler',
                               frame=frame)

    def head_point(self, local=(0, 0, 0)):
        bpy.context.view_layer.update()
        return self.o['head'].matrix_world @ Vector(local)

    def eye_point(self, side='L'):
        bpy.context.view_layer.update()
        return self.o['sock' + side].matrix_world.translation.copy()


# ------------------------------------------------------------------------------------------------ the build


def build_hedgehog(variant='little', name=None, location=(0, 0, 0), fur=1.0, seed=3):
    """Build Little Hedgehog (or 'mama') into the current scene and return its Hedgehog handle.
    fur scales the number of strands (1.0 is the design; 0.5 is fine for far shots)."""
    P = g.params(variant)
    for k in ('n_face', 'n_head_spines', 'n_body_fur', 'n_body_under', 'n_body_spines'):
        P[k] = max(200, int(P[k] * fur))
    name = name or ('Mama' if variant == 'mama' else 'Little')
    rig = Hedgehog(P)
    o = rig.o
    N = lambda s: name + '.' + s  # noqa: E731

    under = mat_skin(N('under'), sss=0.0, sheen=0.5, rough=0.7)
    skin = mat_skin(N('skin'), sss=0.35, sheen=0.5, rough=0.55)
    wet = mat_skin(N('mouth'), sss=0.3, sheen=0.0, rough=0.35, coat=0.3)
    furm = mat_fur(N('fur'))
    spm = mat_spines(N('spines'), P['spine'])
    nosem = mat_nose(N('nose'))
    pawm = mat_skin(N('paw'), sss=0.0, sheen=0.25, rough=0.7)

    root = o['root'] = _empty(N('root'), None, location)
    root.scale = (P['size'],) * 3
    hip = o['hip'] = _empty(N('hip'), root, (0, P['hip'][1], 0.05))

    # body
    B = g.build_body(P, seed + 4)
    body = o['body'] = _mesh(N('body'), B['verts'], B['faces'], under, hip, B['col'], loc=tuple(-np.array(P['hip'])))
    rig._body_verts = B['verts']
    o['body_fur'] = _curves(N('body_fur'), B['fur'], furm, body)
    o['body_spines'] = _curves(N('body_spines'), B['spines'], spm, body)

    # head
    neck = o['neck'] = _empty(N('neck'), body, P['neck'])
    head = o['head'] = _empty(N('head'), neck, (0, -0.016, -0.016))
    head.rotation_mode = 'YXZ'
    H = g.build_head(P, seed)
    hm = o['head_mesh'] = _mesh(N('head_mesh'), H['verts'], H['faces'], under, head, H['col'])
    o['head_fur'] = _curves(N('head_fur'), H['fur'], furm, hm)
    o['head_spines'] = _curves(N('head_spines'), H['spines'], spm, hm)
    o['whiskers'] = _curves(N('whiskers'), H['whiskers'], furm, hm)

    # mouth: the lower jaw is the lower slice of the snout; it swings down on a hinge
    hinge = np.array(P['hinge'])
    jaw = o['jaw'] = _empty(N('jaw'), head, tuple(hinge))
    J = g.build_jaw(P, seed + 2)
    jm = o['jaw_mesh'] = _mesh(N('jaw_mesh'), J['verts'], J['faces'], under, jaw, J['col'], loc=tuple(-hinge))
    o['jaw_fur'] = _curves(N('jaw_fur'), J['fur'], furm, jm)
    ym = 0.5 * (P['jaw_back'] + P['jaw_front']) - 0.001
    tv, tf = g.ellipsoid_mesh(0.0050, 0.0080, 0.0019)
    tc = np.array([0.0, ym, float(g.cut_z(np.array(ym), P)) + 0.0004])
    o['tongue'] = _mesh(N('tongue'), tv, tf, wet, jaw, _flat(g.lin('#e58a8c'), len(tv)), loc=tuple(tc - hinge))
    bv, bf = g.uv_sphere(0.0078, 20, 10)
    o['mouth_back'] = _mesh(N('mouth_back'), bv, bf, wet, head, _flat(g.lin('#6e2a30'), len(bv)),
                            loc=(0.0, P['jaw_back'] - 0.003, float(g.cut_z(np.array(P['jaw_back']), P)) - 0.001))

    # nose
    nose = o['nose'] = _empty(N('nose'), head, P['nose_c'])
    nv, nf = g.ellipsoid_mesh(*P['nose_r'], segs=24, rings=14)
    o['nose_mesh'] = _mesh(N('nose_mesh'), nv, nf, nosem, nose, subsurf=1)

    # eyes: a socket (fixed), an eyeball (gaze) and two lids each
    h1 = g.unit(np.array([-0.12, -0.92, 0.38]))
    h2 = g.unit(np.array([0.15, -0.95, -0.25]))
    lidc, margin = g.lin(P['face']) * 0.80, g.lin('#3d2a20')
    lid_rng = np.random.default_rng(seed + 40)
    rig._eye_mats = []
    r = P['eye_r']
    for side, s in (('L', -1), ('R', 1)):
        sock = o['sock' + side] = _empty(N('sock' + side), head, tuple(H['eyes'][side]))
        toe = RAD(s * P['eye_toe'])
        sock.rotation_euler = (0, 0, toe)
        ci, si = math.cos(-toe), math.sin(-toe)
        to_sock = lambda v: (v[0] * ci - v[1] * si, v[0] * si + v[1] * ci, v[2])  # noqa: E731
        em = mat_eye(N('eye' + side), sock, to_sock(h1), to_sock(h2))
        rig._eye_mats.append(em)
        ev, ef = g.uv_sphere(r, 40, 20)
        ball = o['ball' + side] = _mesh(N('ball' + side), ev, ef, em, sock, subsurf=1)
        ball.rotation_mode = 'QUATERNION'
        for key, upper in (('up', True), ('lo', False)):
            lv, lf, lw = g.lid_wedge(r, upper, k=P['lid_k'])
            col = g.rgba(g.mix(np.repeat(lidc[None, :], len(lv), 0), margin, lw * 0.85))
            lid = o[key + side] = _mesh(N(key + side), lv, lf, under, sock, col)
            o[key + side + '_fur'] = _curves(N(key + side + '_fur'), g.lid_fur(r, upper, P['lid_k'], 1500, lid_rng, g.lin(P['face'])), furm, lid)

    # ears
    for side, s in (('L', -1), ('R', 1)):
        E = g.build_ear(P, s)
        c = g.mirror(P['ear_c'], s)
        piv = o['ear' + side] = _empty(N('ear' + side), head, tuple(c - np.array([0, 0, P['ear_r'][2] * 0.7])))
        em = _mesh(N('ear_mesh' + side), E['verts'], E['faces'], skin, piv, E['col'], loc=(0, 0, P['ear_r'][2] * 0.7),
                   subsurf=1)
        em.rotation_euler = (0, RAD(s * 24), RAD(s * 28))

    # paws and the short legs that follow them
    PW = g.build_paw(P)
    anchors = dict(FL=g.mirror(P['shoulder'], -1), FR=g.mirror(P['shoulder'], 1),
                   HL=g.mirror(P['thigh'], -1), HR=g.mirror(P['thigh'], 1))
    for i, (key, anc) in enumerate(anchors.items()):
        front = key[0] == 'F'
        paw = o['paw' + key] = _mesh(N('paw' + key), PW['verts'], PW['faces'], pawm, body if front else root,
                                     PW['col'], subsurf=1)
        LB = g.build_limb(P, 0.03, 0.0056 if front else 0.0068, P['face'] if front else '#d8bd97', seed + 20 + i)
        leg = o['leg' + key] = _mesh(N('leg' + key), LB['verts'], LB['faces'], under, body, LB['col'], loc=tuple(anc))
        o['leg_fur' + key] = _curves(N('leg_fur' + key), LB['fur'], furm, leg)
        c = leg.constraints.new('STRETCH_TO')
        c.target = paw
        c.rest_length = 0.03
        c.volume = 'NO_VOLUME'

    rig.pose(**POSES['stand'])
    return rig
