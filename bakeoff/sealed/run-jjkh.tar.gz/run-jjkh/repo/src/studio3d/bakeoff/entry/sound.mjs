// "Where Is Little Hedgehog?": 30 seconds of sound, made here from arithmetic only (no samples, no voice).
//
//   node REPO/src/studio3d/bakeoff/entry/sound.mjs --out WS/out/sound.wav        (absolute paths)
//
// Film frame N starts at (N - 1) / 24 seconds. What is in it:
//   an evening garden (crickets, a breath of air), a small lullaby in F on a soft plucked voice over a warm pad,
//   tiny pips for Little's bounces, three plucks while Mama counts and a two-note "peek" at frame 168,
//   pitter-patter and grass rustles for the scurry, sniffs, a slow low theme for the snail, a shimmer on the focus
//   pull, the music opening out as night comes, quiet twinkles as the stars appear, one soft owl hoot,
//   a wobble and a bird-like synthetic giggle from the boot, a soft "boop" when the two noses touch at frame 600,
//   and the lullaby coming to rest.
import { mkdirSync, writeFileSync } from 'node:fs'
import { dirname, resolve } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'

const HERE = dirname(fileURLToPath(import.meta.url))
const REPO = resolve(HERE, '../../../..')
const { wav, loudness } = await import(pathToFileURL(resolve(REPO, 'src/audio/mix.ts')).href)

const arg = Object.fromEntries(process.argv.slice(2).map((a, i, all) => (a.startsWith('--') ? [a.slice(2), all[i + 1]] : [])).filter((p) => p.length))
if (!arg.out) throw new Error('usage: node sound.mjs --out FILE')

const SR = 48000
const DUR = 30
const N = DUR * SR
const TAU = Math.PI * 2
const fr = (frame) => (frame - 1) / 24 // film frame -> seconds

// a small fixed-seed random generator: the same sound every run
function rng(seed) {
  let a = seed >>> 0
  return () => {
    a = (a + 0x6d2b79f5) >>> 0
    let t = a
    t = Math.imul(t ^ (t >>> 15), t | 1)
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61)
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

// ---------------------------------------------------------------------------------------------- buses
const bus = () => ({ L: new Float32Array(N), R: new Float32Array(N) })
const music = bus() // gets the room
const fx = bus() // gets a little of the room
const bed = bus() // dry

function put(b, t, x, gain = 1, pan = 0, panTo = undefined) {
  const s = Math.round(t * SR)
  for (let i = 0; i < x.length; i++) {
    const j = s + i
    if (j < 0) continue
    if (j >= N) break
    const p = panTo === undefined ? pan : pan + (panTo - pan) * (i / x.length)
    const a = ((Math.max(-1, Math.min(1, p)) + 1) * Math.PI) / 4
    b.L[j] += x[i] * Math.cos(a) * gain
    b.R[j] += x[i] * Math.sin(a) * gain
  }
}

const midi = (m) => 440 * 2 ** ((m - 69) / 12)

// one-pole low-pass and a simple band-pass (two one-poles)
function lowpass(x, hz) {
  const k = 1 - Math.exp((-TAU * hz) / SR)
  let y = 0
  const o = new Float32Array(x.length)
  for (let i = 0; i < x.length; i++) {
    y += k * (x[i] - y)
    o[i] = y
  }
  return o
}
function highpass(x, hz) {
  const lp = lowpass(x, hz)
  const o = new Float32Array(x.length)
  for (let i = 0; i < x.length; i++) o[i] = x[i] - lp[i]
  return o
}
const bandpass = (x, lo, hi) => highpass(lowpass(lowpass(x, hi), hi), lo)
function noise(n, r) {
  const o = new Float32Array(n)
  for (let i = 0; i < n; i++) o[i] = r() * 2 - 1
  return o
}

// ---------------------------------------------------------------------------------------------- voices
/** A soft plucked voice (between a kalimba and a celesta). */
function pluck(m, dur = 1.2, bright = 1) {
  const f = midi(m)
  const n = Math.round(dur * SR)
  const o = new Float32Array(n)
  for (let i = 0; i < n; i++) {
    const t = i / SR
    const att = Math.min(1, t / 0.004)
    const e = att * Math.exp(-t / (dur * 0.28))
    o[i] = e * (Math.sin(TAU * f * t) + 0.32 * bright * Math.sin(TAU * 2 * f * t) * Math.exp(-t / 0.12) + 0.16 * bright * Math.sin(TAU * 4.07 * f * t) * Math.exp(-t / 0.05))
  }
  return o
}
/** A short plucked string, for the playful bits. */
function pizz(m, dur = 0.32) {
  const f = midi(m)
  const n = Math.round(dur * SR)
  const o = new Float32Array(n)
  for (let i = 0; i < n; i++) {
    const t = i / SR
    const e = Math.min(1, t / 0.003) * Math.exp(-t / (dur * 0.22))
    o[i] = e * (Math.sin(TAU * f * t) + 0.5 * Math.sin(TAU * 2 * f * t) * Math.exp(-t / 0.04) + 0.25 * Math.sin(TAU * 3 * f * t) * Math.exp(-t / 0.025))
  }
  return o
}
/** A warm held chord. */
function pad(notes, dur, r) {
  const n = Math.round(dur * SR)
  const o = [new Float32Array(n), new Float32Array(n)]
  for (const m of notes) {
    for (let v = 0; v < 2; v++) {
      const f = midi(m) * (1 + (v ? 0.0022 : -0.0022))
      const ph = r() * TAU
      for (let i = 0; i < n; i++) {
        const t = i / SR
        const e = Math.min(1, t / 0.7) * Math.min(1, (dur - t) / 0.9)
        const s = Math.sin(TAU * f * t + ph) + 0.22 * Math.sin(TAU * 2 * f * t + ph * 1.3) + 0.07 * Math.sin(TAU * 3 * f * t)
        o[v][i] += (e * s) / notes.length
      }
    }
  }
  return o
}
/** A low, round, slow voice for the snail (a little like a clarinet). */
function reed(m, dur) {
  const f = midi(m)
  const n = Math.round(dur * SR)
  const o = new Float32Array(n)
  for (let i = 0; i < n; i++) {
    const t = i / SR
    const e = Math.min(1, t / 0.06) * Math.min(1, (dur - t) / 0.12)
    const vib = 1 + 0.004 * Math.sin(TAU * 5 * t) * Math.min(1, t / 0.3)
    const p = TAU * f * vib * t
    o[i] = e * (Math.sin(p) + 0.3 * Math.sin(3 * p) + 0.1 * Math.sin(5 * p))
  }
  return lowpass(o, 1800)
}
/** A tiny bell, for twinkles and the "peek". */
function ting(m, dur = 0.9) {
  const f = midi(m)
  const n = Math.round(dur * SR)
  const o = new Float32Array(n)
  for (let i = 0; i < n; i++) {
    const t = i / SR
    const e = Math.min(1, t / 0.002) * Math.exp(-t / (dur * 0.22))
    o[i] = e * (Math.sin(TAU * f * t) + 0.35 * Math.sin(TAU * 2.76 * f * t) * Math.exp(-t / 0.08) + 0.12 * Math.sin(TAU * 5.4 * f * t) * Math.exp(-t / 0.03))
  }
  return o
}
/** A gliding sine blip. */
function blip(f0, f1, dur, harm = 0.15) {
  const n = Math.round(dur * SR)
  const o = new Float32Array(n)
  let ph = 0
  for (let i = 0; i < n; i++) {
    const u = i / n
    const f = f0 + (f1 - f0) * u
    ph += (TAU * f) / SR
    const e = Math.sin(Math.PI * u) ** 0.8
    o[i] = e * (Math.sin(ph) + harm * Math.sin(2 * ph))
  }
  return o
}
/** A sniff: a quick breath of filtered noise. */
function sniff(r, hz = 2600, dur = 0.085) {
  const n = Math.round(dur * SR)
  const x = bandpass(noise(n, r), hz * 0.6, hz * 1.5)
  for (let i = 0; i < n; i++) {
    const u = i / n
    x[i] *= Math.min(1, u / 0.18) * (1 - u) ** 1.6 * 3
  }
  return x
}
/** A rustle in the grass. */
function rustle(r, dur, lo = 1800, hi = 7000) {
  const n = Math.round(dur * SR)
  const x = bandpass(noise(n, r), lo, hi)
  let g = 0
  let target = 0
  for (let i = 0; i < n; i++) {
    if (i % 900 === 0) target = r() ** 2
    g += (target - g) * 0.004
    const u = i / n
    x[i] *= g * Math.sin(Math.PI * u) ** 0.6 * 4
  }
  return x
}
/** One tiny footstep in grass. */
function step(r) {
  const n = Math.round(0.05 * SR)
  const x = bandpass(noise(n, r), 900, 4200)
  for (let i = 0; i < n; i++) {
    const t = i / SR
    x[i] = x[i] * Math.exp(-t / 0.009) * 2.2 + 0.5 * Math.sin(TAU * 170 * t) * Math.exp(-t / 0.014)
  }
  return x
}
/** A soft thump (the boot rocking). */
function thump(hz = 95, dur = 0.14) {
  const n = Math.round(dur * SR)
  const o = new Float32Array(n)
  for (let i = 0; i < n; i++) {
    const t = i / SR
    o[i] = Math.sin(TAU * hz * t * (1 - 0.3 * t / dur)) * Math.min(1, t / 0.004) * Math.exp(-t / 0.035)
  }
  return o
}
/** The giggle from the boot: a run of bird-like chirps that tumble down and bounce up at the end. Not a voice. */
function giggle(r, base = 1250, count = 6) {
  const gap = 0.088
  const n = Math.round((count * gap + 0.12) * SR)
  const o = new Float32Array(n)
  for (let k = 0; k < count; k++) {
    const u = k / (count - 1)
    const f = base * (1 - 0.30 * u + 0.22 * u * u * u) * (1 + (r() - 0.5) * 0.04)
    const b = blip(f * 1.22, f * 0.94, 0.062, 0.22)
    const s = Math.round(k * gap * (1 - 0.12 * u) * SR)
    const g = 0.75 + 0.25 * Math.sin(Math.PI * u)
    for (let i = 0; i < b.length && s + i < n; i++) o[s + i] += b[i] * g
  }
  return o
}
/** One soft owl hoot: "hoo, hoooo". */
function hoot() {
  const parts = [
    [0.0, 0.2, 392],
    [0.3, 0.62, 370],
  ]
  const n = Math.round(1.05 * SR)
  const o = new Float32Array(n)
  for (const [t0, d, f0] of parts) {
    let ph = 0
    const s = Math.round(t0 * SR)
    const m = Math.round(d * SR)
    for (let i = 0; i < m; i++) {
      const u = i / m
      const f = f0 * (1 + 0.035 * Math.sin(Math.PI * Math.min(1, u * 3) * 0.5) - 0.05 * u * u)
      ph += (TAU * f) / SR
      const e = Math.min(1, u / 0.22) * Math.min(1, (1 - u) / 0.35) ** 1.3
      o[s + i] += e * (Math.sin(ph) + 0.12 * Math.sin(2 * ph) + 0.03 * Math.sin(3 * ph))
    }
  }
  return lowpass(o, 1400)
}
/** Crickets: several insects, each a train of short high pulses. */
function crickets(b, t0, t1, voices, seed, gain) {
  const r = rng(seed)
  for (let v = 0; v < voices; v++) {
    const f = 4100 + r() * 900
    const period = 0.42 + r() * 0.34
    const pulses = 3 + Math.floor(r() * 2)
    const pan = r() * 1.6 - 0.8
    const g = gain * (0.45 + r() * 0.55)
    let t = t0 + r() * period
    while (t < t1) {
      const n = Math.round(pulses * 0.019 * SR)
      const x = new Float32Array(n)
      for (let i = 0; i < n; i++) {
        const tt = i / SR
        const k = tt / 0.019
        const e = Math.sin(Math.PI * (k - Math.floor(k))) ** 2
        x[i] = e * Math.sin(TAU * f * tt)
      }
      const fade = Math.min(1, (t - t0) / 1.5 + 0.2) * Math.min(1, (t1 - t) / 1.5 + 0.1)
      put(b, t, x, g * fade * (0.8 + r() * 0.4), pan)
      t += period * (0.9 + r() * 0.25)
    }
  }
}

// ---------------------------------------------------------------------------------------------- the garden
const R = rng(20261126)
crickets(bed, 0.0, 17.8, 5, 11, 0.022) // evening
crickets(bed, 16.5, 30.0, 8, 12, 0.026) // night: a few more join in
{
  // a breath of air through the whole film
  const air = lowpass(noise(N, rng(5)), 380)
  for (let i = 0; i < N; i++) {
    const t = i / SR
    const sw = 0.6 + 0.4 * Math.sin(TAU * t / 7.3) * Math.sin(TAU * t / 3.1)
    bed.L[i] += air[i] * 0.05 * sw
    bed.R[i] += air[(i + 7001) % N] * 0.05 * sw
  }
}

// ---------------------------------------------------------------------------------------------- the music
// 60 beats a minute; every cut of the film falls on a half beat.
const chords = [
  [0.0, 2.2, [53, 57, 60, 65]], // F
  [2.0, 2.7, [52, 55, 60, 64]], // C over E
  [4.5, 2.2, [50, 57, 62, 65]], // D minor
  [6.5, 2.2, [46, 53, 58, 62]], // B flat
  [8.5, 2.2, [53, 57, 60, 65]], // F
  [10.5, 2.2, [46, 53, 58, 62]], // B flat
  [12.5, 1.2, [48, 55, 60, 64]], // C
  [13.5, 2.2, [50, 53, 57, 62]], // D minor
  [15.5, 2.2, [46, 50, 53, 58]], // B flat
  [17.5, 2.4, [41, 53, 57, 60, 65]], // F, low: night comes
  [19.7, 2.5, [38, 53, 57, 60, 64]], // D minor seventh
  [22.0, 2.2, [43, 50, 55, 58]], // G minor
  [24.0, 1.2, [48, 52, 58, 60]], // C seventh
  [25.0, 1.4, [41, 53, 57, 60]], // F: found you
  [26.0, 2.2, [46, 53, 58, 62]], // B flat
  [28.0, 2.0, [41, 48, 53, 57, 60]], // F: goodnight
]
for (const [t, d, notes] of chords) {
  const p = pad(notes, d + 0.6, R)
  const g = t >= 17.5 ? 0.085 : 0.07
  put(music, t, p[0], g, -0.5)
  put(music, t, p[1], g, 0.5)
}
const tune = [
  // S1: the lullaby's first line
  [0.5, 69], [1.0, 72], [1.5, 77], [2.0, 76], [2.5, 74], [3.0, 72], [3.5, 69], [4.0, 72],
  // S2: an answer after the peek
  [7.5, 69], [8.0, 67],
  // S5: night opens out
  [17.5, 77], [18.0, 72], [18.5, 69], [19.0, 65], [19.7, 74], [20.7, 72], [21.5, 69],
  // S6 into the touch
  [23.5, 72], [24.0, 76], [24.5, 79],
  // S7: the lullaby comes home
  [26.0, 77], [26.5, 74], [27.0, 72], [27.5, 69], [28.0, 70], [28.5, 67], [29.0, 65],
]
for (const [t, m] of tune) put(music, t, pluck(m, t >= 29 ? 2.2 : 1.3, t >= 17.5 ? 0.7 : 1), 0.20, (m - 70) / 40)
// the last chord, spread gently
for (const [dt, m] of [[0.0, 53], [0.07, 57], [0.14, 60], [0.21, 65]]) put(music, 29.0 + dt, pluck(m, 2.4, 0.6), 0.09, (m - 59) / 14)

// S1: Little's three bounces (frames 66, 80, 94: he leaves the ground a few frames later)
for (const f of [69, 83, 97]) put(fx, fr(f), blip(720, 1180, 0.07), 0.07, 0.25)
for (const f of [75, 89, 103]) put(fx, fr(f), step(R), 0.10, 0.25)

// S2: Mama counts (nods at 126, 137, 148), then peeks by 168
for (const [f, m] of [[126, 62], [137, 65], [148, 69]]) put(music, fr(f), pizz(m, 0.4), 0.22, -0.1)
for (const f of [112, 131, 143]) put(fx, fr(f), sniff(R, 1900, 0.07), 0.05, -0.1)
put(music, fr(161), ting(79, 0.7), 0.10, 0.1)
put(music, fr(166), ting(84, 1.0), 0.12, 0.2)
// behind her, Little hops twice and scurries off to the right
for (const f of [123, 136]) put(fx, fr(f), blip(760, 1240, 0.06), 0.04, 0.5)
put(fx, fr(147), rustle(R, 1.3), 0.05, 0.35, 0.95)
for (let f = 148; f < 176; f += 3) put(fx, fr(f) + R() * 0.01, step(R), 0.05 * (1 - (f - 148) / 40), 0.4 + (f - 148) / 50)

// S3: the scurry. Two paw beats every six frames until he stops at about frame 272.
for (let k = 0; ; k++) {
  const f = 205 + k * 3
  if (f > 271) break
  const slow = f > 262 ? 1 - (f - 262) / 14 : 1
  put(fx, fr(f) + (R() - 0.5) * 0.012, step(R), 0.13 * (0.75 + 0.25 * R()) * slow, -0.35 + (f - 205) / 110)
}
put(fx, fr(205), rustle(R, 2.9), 0.075, -0.4, 0.2)
put(fx, fr(262), rustle(R, 0.6, 1200, 5000), 0.09, 0.1) // the little skid
for (let i = 0; i < 20; i++) {
  // a quick playful line under the run
  const seq = [65, 69, 72, 69, 65, 69, 72, 77, 70, 74, 77, 74, 70, 74, 77, 82, 72, 76, 79, 76]
  const t = 8.5 + i * 0.125
  if (t < 11.0) put(music, t, pizz(seq[i], 0.2), 0.10 + 0.02 * (i % 4 === 0), ((i % 8) - 3.5) / 8)
}
put(music, fr(272), pizz(48, 0.5), 0.2, 0) // he stops
for (const f of [283, 287]) put(fx, fr(f), sniff(R, 2700), 0.11, 0.1)
for (const f of [297, 301]) put(fx, fr(f), sniff(R, 3000), 0.12, 0.15)
put(music, 12.5, pluck(72, 0.9), 0.14, 0.2)
put(music, 13.0, pluck(76, 0.9), 0.14, 0.3)

// S4: the snail's slow tune; a shimmer as the focus moves (frames 372 to 396); Little slips into the boot
for (const [t, m, d] of [[13.6, 50, 0.9], [14.6, 53, 0.45], [15.1, 52, 0.45], [15.6, 50, 0.8]]) put(music, t, reed(m, d), 0.12, -0.35)
for (let i = 0; i < 9; i++) put(music, fr(372) + i * 0.11, ting([77, 81, 84, 89, 84, 81, 84, 89, 93][i], 0.6), 0.035 + 0.004 * i, 0.3 + i * 0.05)
put(fx, fr(345), rustle(R, 1.3), 0.035, -0.6, 0.3) // he passes behind the snail
for (let f = 348; f < 378; f += 3) put(fx, fr(f) + R() * 0.01, step(R), 0.035, -0.5 + (f - 348) / 40)
put(fx, fr(392), rustle(R, 1.1, 1200, 5000), 0.07, 0.4)
for (const f of [399, 406, 413]) put(fx, fr(f), thump(100), 0.10, 0.4)
for (const [t, m] of [[16.6, 57], [16.85, 60], [17.1, 62]]) put(music, t, pizz(m, 0.25), 0.12, 0.3)

// S5: stars come out (quiet twinkles), the owl ruffles and gives one soft hoot around its blink (frame 492)
{
  const r = rng(77)
  const scale = [84, 86, 89, 91, 93, 96, 98]
  for (let i = 0; i < 16; i++) {
    const t = 18.6 + i * 0.21 + r() * 0.12
    put(music, t, ting(scale[Math.floor(r() * scale.length)], 0.8), 0.016 + 0.014 * r(), r() * 1.6 - 0.8)
  }
  for (let i = 0; i < 10; i++) {
    const t = 22.3 + i * 0.75 + r() * 0.3
    put(music, t, ting(scale[Math.floor(r() * scale.length)], 0.9), 0.012 + 0.008 * r(), r() * 1.6 - 0.8)
  }
}
put(fx, fr(458), rustle(R, 0.45, 700, 3000), 0.05, -0.15) // feathers
put(fx, fr(478), hoot(), 0.16, -0.15)

// S6: the boot wobbles with a giggle; Mama sniffs her way in; the noses touch at frame 600
for (const f of [533, 536, 539, 542]) put(fx, fr(f), thump(105), 0.10, 0.3)
put(fx, fr(534), giggle(R, 1320, 6), 0.075, 0.3)
for (const f of [551, 554, 557]) put(fx, fr(f), thump(105), 0.08, 0.3)
put(fx, fr(552), giggle(R, 1400, 5), 0.065, 0.3)
for (const f of [550, 560, 574, 586]) put(fx, fr(f), sniff(R, 1700, 0.09), 0.085, -0.3)
put(fx, fr(577), giggle(R, 1440, 6), 0.07, 0.25) // Little peeps out and laughs as Mama comes close (frames 571 to 595)
for (const [t, m] of [[22.0, 55], [22.5, 58], [23.0, 62]]) put(music, t, pizz(m, 0.3), 0.13, -0.2)
put(fx, fr(600), blip(540, 400, 0.13, 0.1), 0.16, 0)
put(music, fr(600) + 0.02, ting(89, 1.4), 0.10, 0.1)
put(music, fr(600) + 0.04, pluck(77, 1.6), 0.16, 0)
put(fx, fr(604), giggle(R, 1360, 7), 0.075, 0.2)
put(fx, fr(607), thump(105), 0.06, 0.3)

// S7: a last sleepy sigh of air, and stillness
put(fx, fr(640), sniff(R, 900, 0.5), 0.02, 0)

// ---------------------------------------------------------------------------------------------- the room
/** A small, soft room: four comb filters and two all-pass filters on each side. */
function room(x, combs, seed) {
  const o = new Float32Array(N)
  for (const [ms, fb] of combs) {
    const d = Math.round((ms / 1000) * SR)
    const buf = new Float32Array(d)
    let k = 0
    let lp = 0
    for (let i = 0; i < N; i++) {
      const y = buf[k]
      lp += 0.35 * (y - lp)
      buf[k] = x[i] + lp * fb
      k = (k + 1) % d
      o[i] += y * 0.25
    }
  }
  let y = o
  for (const ms of [5.1 + seed, 1.7 + seed * 0.3]) {
    const d = Math.round((ms / 1000) * SR)
    const buf = new Float32Array(d)
    const out = new Float32Array(N)
    let k = 0
    for (let i = 0; i < N; i++) {
      const b = buf[k]
      const v = y[i] + b * 0.5
      buf[k] = v
      out[i] = b - v * 0.5
      k = (k + 1) % d
    }
    y = out
  }
  return y
}
const send = { L: new Float32Array(N), R: new Float32Array(N) }
for (let i = 0; i < N; i++) {
  send.L[i] = music.L[i] + fx.L[i] * 0.45
  send.R[i] = music.R[i] + fx.R[i] * 0.45
}
const wetL = room(send.L, [[29.7, 0.80], [37.1, 0.78], [41.1, 0.76], [43.7, 0.74]], 0)
const wetR = room(send.R, [[30.5, 0.80], [36.3, 0.78], [42.3, 0.76], [44.9, 0.74]], 0.4)

const L = new Float32Array(N)
const Rt = new Float32Array(N)
for (let i = 0; i < N; i++) {
  const t = i / SR
  // the whole track eases in with the picture and comes to rest at the very end
  const env = Math.min(1, t / 0.4) * Math.min(1, (DUR - t) / 0.7) ** 1.5
  L[i] = (music.L[i] + fx.L[i] + bed.L[i] + wetL[i] * 0.42) * env
  Rt[i] = (music.R[i] + fx.R[i] + bed.R[i] + wetR[i] * 0.42) * env
}
// bring it near -16 LUFS without letting a peak pass -2.5 dB (the organisers set the final level)
let peak = 0
for (let i = 0; i < N; i++) peak = Math.max(peak, Math.abs(L[i]), Math.abs(Rt[i]))
const lufs = loudness(L, Rt)
let gain = 10 ** ((-16.5 - lufs) / 20)
if (peak * gain > 0.75) gain = 0.75 / peak
for (let i = 0; i < N; i++) {
  L[i] *= gain
  Rt[i] *= gain
}
mkdirSync(dirname(resolve(arg.out)), { recursive: true })
writeFileSync(resolve(arg.out), wav(L, Rt))
console.log(`sound: ${resolve(arg.out)} · ${N} sample frames · ${loudness(L, Rt).toFixed(1)} LUFS · peak ${(20 * Math.log10(peak * gain)).toFixed(1)} dB`)
