"""Design proposal 1: draws the stills of Little Hedgehog in the dusk garden patch.

Run through the wrapper (REPO and WS as in the brief), for example:

    bash REPO/studio/scripts/bakeoff/blender.sh d1-stills --sub design_1 --sub-cap 720 -- \
        --python REPO/src/studio3d/bakeoff/entry/design_1/stills.py -- --out WS/out/design_1 --res 1280x720 --samples 32

--only a_medium,b_face,c_sniff   which pictures (default: these three). Extra check views: x_front, x_side, x_back,
                                 x_curl, x_family (give --mama with it: builds Mama behind him).
One Blender process builds the character and the patch once, then re-poses him for each picture.
"""
import argparse
import math
import os
import sys
import time

import bpy

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

import hedgehog as hh  # noqa: E402
import patch  # noqa: E402

# name: pose, how far he is turned (degrees, + = toward his left), camera position, look-at point, lens, f-stop
STILLS = {
    'a_medium': dict(pose=hh.STAND, turn=0.0, cam=(0.29, -0.41, 0.072), look=(0.004, -0.022, 0.054), lens=55, fstop=6.3),
    'b_face': dict(pose=hh.STAND, turn=0.0, cam=(0.134, -0.555, 0.066), look=(0.012, -0.058, 0.0605), lens=85, fstop=16),
    'c_sniff': dict(pose=hh.SNIFF, turn=70.0, cam=(0.33, -0.46, 0.088), look=(0.0, 0.0, 0.070), lens=55, fstop=6.3),
    'x_front': dict(pose=hh.REST, turn=0.0, cam=(0.0, -0.62, 0.060), look=(0.0, 0.0, 0.055), lens=70, fstop=11),
    'x_side': dict(pose=hh.REST, turn=0.0, cam=(0.62, -0.02, 0.060), look=(0.0, -0.01, 0.052), lens=70, fstop=11),
    'x_back': dict(pose=hh.REST, turn=0.0, cam=(-0.34, 0.50, 0.13), look=(0.0, 0.0, 0.05), lens=60, fstop=11),
    'x_curl': dict(pose=hh.CURL, turn=0.0, cam=(0.33, -0.46, 0.10), look=(0.0, 0.0, 0.045), lens=60, fstop=8),
    'x_family': dict(pose=hh.STAND, turn=0.0, cam=(0.30, -0.66, 0.11), look=(-0.075, 0.0, 0.075), lens=50, fstop=9),
}


def main():
    argv = sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else []
    ap = argparse.ArgumentParser(prog='stills.py')
    ap.add_argument('--out', required=True)
    ap.add_argument('--res', default='1280x720')
    ap.add_argument('--samples', type=int, default=24)
    ap.add_argument('--only', default='a_medium,b_face,c_sniff')
    ap.add_argument('--fur', type=float, default=1.0)
    ap.add_argument('--exposure', type=float, default=0.55)
    ap.add_argument('--denoise', default='HIGH')
    ap.add_argument('--mama', action='store_true')
    a = ap.parse_args(argv)
    w, h_px = (int(v) for v in a.res.lower().split('x'))
    os.makedirs(a.out, exist_ok=True)

    bpy.ops.wm.read_factory_settings(use_empty=True)
    t0 = time.time()
    patch.build_patch()
    patch.build_light()
    t1 = time.time()
    h = hh.build_hedgehog('Little', fur=a.fur)
    if a.mama:
        mama = hh.build_hedgehog('Mama', design=hh.MAMA, scale=1.5, seed=11, fur=a.fur)
        mama.root.location = (-0.20, 0.07, 0.0)
        mama.root.rotation_euler = (0.0, 0.0, math.radians(22.0))
        hh.pose(mama, head_yaw=12.0, head_pitch=4.0, smile=0.6)
    t2 = time.time()
    cam, tgt, _card = patch.build_camera()
    patch.render_settings(a.samples, (w, h_px), a.exposure, a.denoise)
    print(f'BUILD patch {t1 - t0:.1f}s hedgehog {t2 - t1:.1f}s', flush=True)
    for key, obj in sorted(h.parts.items()):
        d = obj.data
        size = len(d.vertices) if hasattr(d, 'vertices') else len(getattr(d, 'curves', []))
        print(f'PART {key} {size}', flush=True)

    sc = bpy.context.scene
    for key in [k.strip() for k in a.only.split(',') if k.strip()]:
        s = STILLS[key]
        hh.pose(h, **s['pose'])
        h.root.rotation_euler = (0.0, 0.0, math.radians(s['turn']))
        patch.aim_camera(cam, tgt, s['cam'], s['look'], s['lens'], s['fstop'], h.focus)
        bpy.context.view_layer.update()
        ts = time.time()
        sc.render.filepath = os.path.join(a.out, key + '.png')
        bpy.ops.render.render(write_still=True)
        print(f'STILL {key} {time.time() - ts:.1f}s', flush=True)
    print('DONE', flush=True)


if __name__ == '__main__':
    main()
