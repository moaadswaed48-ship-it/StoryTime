"""The garden behind the house: ground, grass, bush, low stone wall, house with its warm window, far hedges, the old
boot, the green watering can, the sky (dusk to night, with stars that come out one by one), lamps and fireflies.

One layout for the whole film (metres, Z up). The main cameras stand at -Y and look toward +Y, where the house is.
"""
import math
import os
import sys

import bpy
import numpy as np
from mathutils import Matrix, Vector

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)
import hh_geom as g  # noqa: E402
import kit  # noqa: E402
from critters import vnoise  # noqa: E402

RAD = math.radians

# ------------------------------------------------------------------------------------------------ the layout
HOUSE_Y, HOUSE_X0, HOUSE_X1, EAVES = 3.4, 1.3, 9.0, 2.6
WIN = dict(x0=1.9, x1=2.8, z0=0.42, z1=1.62)
WALL_Y0, WALL_Y1, WALL_H, WALL_X0, WALL_X1 = 1.45, 1.75, 0.42, -5.0, 6.0
OWL_POS = (0.35, 1.475, WALL_H + 0.003)
BUSH = (-1.75, 1.10)
MAMA0, LITTLE0 = (-0.62, 0.20), (-0.36, 0.08)
BOOT_O = (1.25, 0.85)                 # centre of the boot's opening on the ground plan
BOOT_A = (-0.2588, -0.9659)           # the way the opening faces
BOOT_S = 1.25
BOOT_ZC = 0.080                       # height of the shaft's axis
BOOT_FLOOR = 0.018                    # height of the floor inside the shaft
BOOT_ROLL = -16.0                     # the boot is rolled a little, so its toe points up
STONE = (0.448, 0.250)
CAN = (0.52, 0.415)
SUN_DIR = (-0.90, -0.32, 0.24)        # from the scene toward the low evening sun (left, a little in front)
RIM_DIR = (0.55, 0.78, 0.30)          # a peach rim from behind on the other side
MOON_DIR = (-0.50, -0.60, 0.62)       # night: soft cool light from the front left, high


def boot_point(along, side=0.0, z=None):
    """A world point `along` metres out of the boot's opening (negative: inside) and `side` metres to its right."""
    a = Vector((BOOT_A[0], BOOT_A[1], 0.0))
    r = Vector((-BOOT_A[1], BOOT_A[0], 0.0))
    p = Vector((BOOT_O[0], BOOT_O[1], 0.0)) + a * along + r * side
    p.z = BOOT_ZC if z is None else z
    return p


# ------------------------------------------------------------------------------------------------ ground and grass
def ground():
    m = kit.noise_mat('Ground', [(0.25, '#1f2c12'), (0.5, '#33471c'), (0.75, '#4a5c26')], scale=7.0, detail=6.0,
                      rough=0.95, spec=0.1, bump=0.3, bump_scale=60.0)
    s = 60.0
    return kit.mesh('Ground', [(-s, -s, 0), (s, -s, 0), (s, s, 0), (-s, s, 0)], [(0, 1, 2, 3)], m, smooth=False)


def _in_shapes(x, y, shapes):
    """True where (x, y) falls in any shape: (cx, cy, r) discs or (x0, y0, x1, y1, r) capsules."""
    hit = np.zeros(len(x), dtype=bool)
    for s in shapes:
        if len(s) == 3:
            hit |= (x - s[0]) ** 2 + (y - s[1]) ** 2 < s[2] ** 2
        else:
            ax, ay, bx, by, r = s[:5]
            dx, dy = bx - ax, by - ay
            t = np.clip(((x - ax) * dx + (y - ay) * dy) / max(dx * dx + dy * dy, 1e-9), 0, 1)
            hit |= (x - ax - t * dx) ** 2 + (y - ay - t * dy) ** 2 < r ** 2
    return hit


def daisies(x, y, rng, name='Daisies'):
    """Small white daisies with yellow hearts on thin stems, as one mesh."""
    n = len(x)
    if n == 0:
        return None
    hs = rng.uniform(0.028, 0.055, n)
    rr = rng.uniform(0.0065, 0.0095, n)
    lx, ly = rng.uniform(-0.008, 0.008, n), rng.uniform(-0.008, 0.008, n)
    V, F, C = [], [], []
    white, yellow, green = g.lin('#fbf7ec'), g.lin('#f2c230'), g.lin('#5c9632')
    ang = np.linspace(0, 2 * math.pi, 8, endpoint=False)
    for i in range(n):
        top = np.array([x[i] + lx[i], y[i] + ly[i], hs[i]])
        w = 0.0009
        base = len(V) * 0 + sum(len(a) for a in V)
        stem = np.array([[x[i] - w, y[i], 0.0], [x[i] + w, y[i], 0.0], [top[0] + w, top[1], top[2]], [top[0] - w, top[1], top[2]]])
        tilt = np.array([lx[i], ly[i], 0.0]) * 0.25
        rim = top + np.stack([np.cos(ang) * rr[i], np.sin(ang) * rr[i], np.full(8, -0.0012)], 1) \
            + np.outer(np.cos(ang) * tilt[0] + np.sin(ang) * tilt[1], np.array([0.0, 0.0, -1.0]))
        V.append(np.concatenate([stem, top[None, :] + np.array([[0.0, 0.0, 0.0012]]), rim]))
        F.append(np.array([[0, 1, 2], [0, 2, 3]] + [[4, 5 + k, 5 + (k + 1) % 8] for k in range(8)]) + base)
        C.append(np.concatenate([np.repeat(green[None, :], 4, 0), yellow[None, :], np.repeat(white[None, :], 8, 0)]))
    m = kit.principled(name + '.mat', attr='col', rough=0.6, spec=0.25)
    kit.add_translucent(m, 0.30)
    return kit.mesh(name, np.concatenate(V), np.concatenate(F), m, None, np.concatenate(C), smooth=False)


def grass(patches, short=(), bare=(), wedges=None, focus=(0.0, 0.0), seed=21, name='Grass', flowers=0,
          no_flowers=()):
    """Grass blades as one mesh.
    patches: [dict(rect=(x0, y0, x1, y1), n=blades, h=(lo, hi))]: blades spread evenly in a rectangle.
    short:  shapes (see _in_shapes) where the lawn is cut short, so a character standing there shows.
    bare:   shapes where nothing grows (under the boot, the can, the wall).
    wedges: [(cam_x, cam_y, look_x, look_y, half_angle_deg, far)]: blades outside every wedge are dropped
            (what no camera of the shot can see is not built).
    focus:  blades get wider and taller with distance from this point, so far lawn stays closed with few blades."""
    rng = np.random.default_rng(seed)
    xs, ys, hs = [], [], []
    for p in patches:
        x0, y0, x1, y1 = p['rect']
        n = int(p['n'])
        x = rng.uniform(x0, x1, n)
        y = rng.uniform(y0, y1, n)
        h = rng.uniform(p['h'][0], p['h'][1], n)
        xs.append(x), ys.append(y), hs.append(h)
    x, y, h = np.concatenate(xs), np.concatenate(ys), np.concatenate(hs)
    keep = ~_in_shapes(x, y, bare) if bare else np.ones(len(x), dtype=bool)
    keep &= ~((y > WALL_Y0 - 0.02) & (y < WALL_Y1 + 0.02) & (x > WALL_X0) & (x < WALL_X1))
    keep &= ~((y > HOUSE_Y - 0.05) & (x > HOUSE_X0))
    if wedges:
        seen = np.zeros(len(x), dtype=bool)
        for cx, cy, lx, ly, ha, far in wedges:
            dx, dy = x - cx, y - cy
            dist = np.hypot(dx, dy)
            ll = math.hypot(lx, ly)
            cosang = (dx * lx + dy * ly) / np.maximum(dist * ll, 1e-9)
            seen |= ((cosang > math.cos(RAD(ha))) | (dist < 0.25)) & (dist < far)
        keep &= seen
    x, y, h = x[keep], y[keep], h[keep]
    n = len(x)
    cut = np.zeros(n, dtype=bool)
    if short:
        cut = _in_shapes(x, y, short)
        h = np.where(cut, rng.uniform(0.007, 0.015, n), h)
    if flowers:
        frng = np.random.default_rng(seed + 500)
        ok = ~cut
        if no_flowers:
            ok &= ~_in_shapes(x, y, no_flowers)
        idx = np.where(ok)[0]
        if len(idx):
            pick = frng.choice(idx, size=min(int(flowers), len(idx)), replace=False)
            daisies(x[pick], y[pick], frng, name + '.daisies')
    dist = np.hypot(x - focus[0], y - focus[1])
    far = g.smoothstep(0.7, 3.0, dist)
    h = h * (1 + 0.5 * far)
    w = rng.uniform(0.0030, 0.0048, n) * (1 + 2.2 * far)
    face = rng.uniform(0, 2 * math.pi, n)
    lean_dir = rng.uniform(0, 2 * math.pi, n)
    lean = rng.uniform(0.05, 0.55, n)
    ts = np.array([0.0, 0.38, 0.72, 1.0])
    wf = np.array([1.0, 0.85, 0.55, 0.06])
    verts = np.zeros((n, 4, 2, 3))
    for i, (t, wk) in enumerate(zip(ts, wf)):
        cx = x + np.cos(lean_dir) * lean * h * t * t
        cy = y + np.sin(lean_dir) * lean * h * t * t
        cz = h * t * (1 - 0.25 * lean * t)
        dx, dy = np.cos(face) * w * wk * 0.5, np.sin(face) * w * wk * 0.5
        verts[:, i, 0] = np.stack([cx - dx, cy - dy, cz], 1)
        verts[:, i, 1] = np.stack([cx + dx, cy + dy, cz], 1)
    base = np.arange(n)[:, None] * 8
    quads = np.concatenate([base + np.array([2 * i, 2 * i + 1, 2 * i + 3, 2 * i + 2])[None, :] for i in range(3)])
    tone = rng.random(n)
    c0, c1, c2 = g.lin('#3f6a1f'), g.lin('#7fa236'), g.lin('#b9b657')
    tip = np.where(tone[:, None] < 0.75, c1 + (c2 - c1) * (tone[:, None] / 0.75) * 0.5, c2)
    col = np.zeros((n, 4, 2, 4))
    for i, t in enumerate(ts):
        cc = g.lin('#26401a') * (1 - t) ** 2 + (c0 * (1 - t) + tip * t) * (1 - (1 - t) ** 2)
        col[:, i, :, :3] = cc[:, None, :]
    col[..., 3] = 1
    m = kit.principled(name + '.mat', attr='col', rough=0.5, spec=0.3)
    kit.add_translucent(m, 0.36)
    print('GRASS %s blades %d' % (name, n), flush=True)
    return kit.mesh(name, verts.reshape(-1, 3), quads, m, None, col.reshape(-1, 4))


# ------------------------------------------------------------------------------------------------ bush
def bush(centre=BUSH, seed=4, leaves=5200, blobs=None, name='Bush'):
    """A leafy bush: dark cores with a coat of small leaves that let the low sun through."""
    rng = np.random.default_rng(seed)
    blobs = blobs or [((0.0, 0.0, 0.50), (0.62, 0.52, 0.46)), ((0.42, -0.22, 0.36), (0.36, 0.30, 0.30)),
                      ((-0.40, -0.10, 0.40), (0.38, 0.34, 0.34)), ((0.15, 0.10, 0.80), (0.40, 0.36, 0.28)),
                      ((0.30, -0.42, 0.30), (0.26, 0.20, 0.16))]
    corem = kit.noise_mat(name + '.core', [(0.3, '#1d3316'), (0.7, '#36552a')], scale=9.0, rough=0.9, spec=0.1)
    leafm = kit.principled(name + '.leaf', attr='col', rough=0.45, spec=0.35)
    kit.add_translucent(leafm, 0.38)
    V, F, C = [], [], []
    area = np.array([r[0] * r[1] + r[1] * r[2] + r[0] * r[2] for _, r in blobs])
    counts = (leaves * area / area.sum()).astype(int)
    c_lo, c_hi, c_y = g.lin('#3f7426'), g.lin('#84b23a'), g.lin('#bccb5a')
    for (c, r), n in zip(blobs, counts):
        cc = np.array([centre[0] + c[0], centre[1] + c[1], c[2]])
        ev, ef = g.ellipsoid_mesh(r[0] * 0.86, r[1] * 0.86, r[2] * 0.86, 20, 12)
        kit.mesh(name + '.core', ev, ef, corem, None, loc=tuple(cc))
        d = g.unit(rng.normal(0, 1, (n, 3)))
        d[:, 2] = np.abs(d[:, 2]) * 0.9 - 0.25 * rng.random(n)
        d = g.unit(d)
        p = cc + d * np.array(r) * rng.uniform(0.86, 1.06, (n, 1))
        ok = p[:, 2] > 0.04
        p, d = p[ok], d[ok]
        k = len(p)
        ax = g.unit(d + rng.normal(0, 0.55, (k, 3)) + np.array([0, 0, -0.35]))        # leaf points out and down
        sd = g.unit(np.cross(ax, rng.normal(0, 1, (k, 3))))
        L = rng.uniform(0.035, 0.060, k)[:, None]
        W = L * rng.uniform(0.22, 0.32, (k, 1))
        nrm = np.cross(ax, sd)
        v0 = p
        v1 = p + ax * L * 0.45 + sd * W + nrm * L * 0.06
        v2 = p + ax * L
        v3 = p + ax * L * 0.45 - sd * W + nrm * L * 0.06
        base = sum(len(a) for a in V)
        V.append(np.stack([v0, v1, v2, v3], 1).reshape(-1, 3))
        F.append((base + np.arange(k)[:, None] * 4 + np.arange(4)[None, :]))
        t = rng.random(k)
        lc = g.mix(g.mix(np.repeat(c_lo[None, :], k, 0), c_hi, t), c_y, 0.5 * (t > 0.85))
        lc = lc * (0.55 + 0.45 * g.smoothstep(-0.3, 0.6, d[:, 2]))[:, None]
        C.append(np.repeat(lc, 4, 0))
    V, F, C = np.concatenate(V), np.concatenate(F), np.concatenate(C)
    return kit.mesh(name + '.leaves', V, F, leafm, None, C, smooth=False)


# ------------------------------------------------------------------------------------------------ the stone wall
def stone_wall(seed=8, x0=WALL_X0, x1=WALL_X1):
    rng = np.random.default_rng(seed)
    d, f = g.icosphere(2)
    box = np.sign(d) * np.abs(d) ** 0.42                         # a rounded block
    V, F, C = [], [], []
    tones = [g.lin(c) for c in ('#8c8473', '#a39a86', '#7a7468', '#b3a58a', '#958a78', '#6f6a60')]
    courses = [(0.0, 0.15), (0.14, 0.14), (0.27, 0.105)]
    for ci, (zb, hh_) in enumerate(courses):
        x = x0 + rng.uniform(-0.1, 0.0)
        while x < x1:
            ln = rng.uniform(0.15, 0.30)
            sz = np.array([ln * 0.5 + 0.006, 0.09, hh_ * 0.5 + 0.006])
            c = np.array([x + ln * 0.5, WALL_Y0 + 0.075 + rng.uniform(-0.012, 0.012), zb + hh_ * 0.5])
            n1 = (vnoise(d + rng.uniform(0, 50), 1.6, ci) - 0.5) * 0.16
            v = box * sz * (1 + n1)[:, None] + c
            base = sum(len(a) for a in V)
            V.append(v), F.append(f + base)
            C.append(np.repeat((tones[rng.integers(len(tones))] * rng.uniform(0.85, 1.1))[None, :], len(v), 0))
            x += ln + rng.uniform(0.004, 0.012)
    # cap stones: flat and wide, across the whole thickness (the owl sits on one)
    x = x0
    while x < x1:
        ln = rng.uniform(0.22, 0.38)
        thick = rng.uniform(0.045, 0.06)
        sz = np.array([ln * 0.5 + 0.004, (WALL_Y1 - WALL_Y0) * 0.5 + 0.02, thick * 0.5])
        c = np.array([x + ln * 0.5, (WALL_Y0 + WALL_Y1) * 0.5, WALL_H - thick * 0.5 + rng.uniform(-0.004, 0.004)])
        if abs(c[0] - OWL_POS[0]) < ln * 0.5:
            c[2] = WALL_H - thick * 0.5
        n1 = (vnoise(d + rng.uniform(0, 50), 1.4, 7) - 0.5) * 0.10
        v = box * sz * (1 + n1)[:, None] + c
        base = sum(len(a) for a in V)
        V.append(v), F.append(f + base)
        C.append(np.repeat((tones[rng.integers(len(tones))] * rng.uniform(0.9, 1.12))[None, :], len(v), 0))
        x += ln + rng.uniform(0.004, 0.010)
    m = kit.noise_mat('WallStone', [(0.3, (0.72, 0.72, 0.72)), (0.7, (1.0, 1.0, 1.0))], scale=38.0, detail=7.0,
                      rough=0.88, spec=0.2, bump=0.5, bump_scale=130.0, attr_mul='col')
    # moss and lichen where the stones face up
    nt = m.node_tree
    b = nt.nodes['Principled BSDF']
    geo = nt.nodes.new('ShaderNodeNewGeometry')
    sep = nt.nodes.new('ShaderNodeSeparateXYZ')
    nt.links.new(geo.outputs['Normal'], sep.inputs[0])
    nz = nt.nodes.new('ShaderNodeTexNoise')
    nz.inputs['Scale'].default_value = 22.0
    add = nt.nodes.new('ShaderNodeMath')
    add.operation = 'MULTIPLY_ADD'
    add.inputs[1].default_value = 0.9
    nt.links.new(nz.outputs['Fac'], add.inputs[0])
    nt.links.new(sep.outputs['Z'], add.inputs[2])
    mr = nt.nodes.new('ShaderNodeMapRange')
    mr.inputs['From Min'].default_value = 1.18
    mr.inputs['From Max'].default_value = 1.45
    nt.links.new(add.outputs[0], mr.inputs['Value'])
    mixc = nt.nodes.new('ShaderNodeMixRGB')
    src = b.inputs['Base Color'].links[0].from_socket
    nt.links.new(mr.outputs['Result'], mixc.inputs['Fac'])
    nt.links.new(src, mixc.inputs['Color1'])
    mixc.inputs['Color2'].default_value = kit.lin4('#6b7f3a')
    nt.links.new(mixc.outputs['Color'], b.inputs['Base Color'])
    kit.mesh('Wall', np.concatenate(V), np.concatenate(F), m, None, np.concatenate(C))
    corem = kit.principled('WallCore', color='#3a362f', rough=0.95, spec=0.1)
    bv = [(x0, WALL_Y0 + 0.05, 0), (x1, WALL_Y0 + 0.05, 0), (x1, WALL_Y1, 0), (x0, WALL_Y1, 0),
          (x0, WALL_Y0 + 0.05, WALL_H - 0.03), (x1, WALL_Y0 + 0.05, WALL_H - 0.03), (x1, WALL_Y1, WALL_H - 0.03),
          (x0, WALL_Y1, WALL_H - 0.03)]
    bf = [(0, 1, 5, 4), (1, 2, 6, 5), (2, 3, 7, 6), (3, 0, 4, 7), (4, 5, 6, 7)]
    kit.mesh('WallCore', bv, bf, corem, None, smooth=False)


# ------------------------------------------------------------------------------------------------ the house
def _box(x0, y0, z0, x1, y1, z1):
    v = [(x0, y0, z0), (x1, y0, z0), (x1, y1, z0), (x0, y1, z0), (x0, y0, z1), (x1, y0, z1), (x1, y1, z1), (x0, y1, z1)]
    f = [(0, 1, 5, 4), (1, 2, 6, 5), (2, 3, 7, 6), (3, 0, 4, 7), (4, 5, 6, 7), (3, 2, 1, 0)]
    return v, f


def _boxes(name, boxes, mat):
    V, F = [], []
    for b in boxes:
        v, f = _box(*b)
        base = len(V)
        V += v
        F += [tuple(i + base for i in q) for q in f]
    return kit.mesh(name, V, F, mat, None, smooth=False)


def _tiles(m, row=0.21, col=0.17):
    """Rows of roof tiles drawn into a material: each row throws a thin shadow on the one below, tiles are set
    half a tile apart from row to row, and every tile has its own shade."""
    nt = m.node_tree
    b = nt.nodes['Principled BSDF']
    Lk = nt.links.new

    def mth(op, a, bb=None, c=None):
        n = nt.nodes.new('ShaderNodeMath')
        n.operation = op
        for i, x in enumerate((a, bb, c)):
            if x is None:
                continue
            if isinstance(x, (int, float)):
                n.inputs[i].default_value = x
            else:
                Lk(x, n.inputs[i])
        return n.outputs[0]

    def rng(v, a, bb, c, d):
        n = nt.nodes.new('ShaderNodeMapRange')
        n.clamp = True
        n.interpolation_type = 'SMOOTHSTEP'
        Lk(v, n.inputs['Value'])
        for key, x in (('From Min', a), ('From Max', bb), ('To Min', c), ('To Max', d)):
            n.inputs[key].default_value = x
        return n.outputs['Result']
    tc = nt.nodes.new('ShaderNodeTexCoord')
    sep = nt.nodes.new('ShaderNodeSeparateXYZ')
    Lk(tc.outputs['Object'], sep.inputs[0])
    ry = mth('MULTIPLY', sep.outputs['Y'], 1.0 / row)
    fy, iy = mth('FRACT', ry), mth('FLOOR', ry)
    rx = mth('ADD', mth('MULTIPLY', sep.outputs['X'], 1.0 / col), mth('MULTIPLY', iy, 0.5))
    fx, ix = mth('FRACT', rx), mth('FLOOR', rx)
    cell = nt.nodes.new('ShaderNodeCombineXYZ')
    Lk(ix, cell.inputs[0])
    Lk(iy, cell.inputs[1])
    wn = nt.nodes.new('ShaderNodeTexWhiteNoise')
    wn.noise_dimensions = '3D'
    Lk(cell.outputs[0], wn.inputs['Vector'])
    shade = mth('MULTIPLY', mth('MULTIPLY', rng(fy, 0.80, 0.97, 1.0, 0.42), rng(fx, 0.0, 0.08, 0.55, 1.0)),
                mth('MULTIPLY_ADD', wn.outputs['Value'], 0.34, 0.80))
    src = b.inputs['Base Color'].links[0].from_socket
    sc = nt.nodes.new('ShaderNodeVectorMath')
    sc.operation = 'SCALE'
    Lk(src, sc.inputs[0])
    Lk(shade, sc.inputs['Scale'])
    Lk(sc.outputs['Vector'], b.inputs['Base Color'])
    bp = nt.nodes.new('ShaderNodeBump')
    bp.inputs['Strength'].default_value = 0.7
    bp.inputs['Distance'].default_value = 0.03
    Lk(fy, bp.inputs['Height'])
    if b.inputs['Normal'].links:
        Lk(b.inputs['Normal'].links[0].from_socket, bp.inputs['Normal'])
    Lk(bp.outputs['Normal'], b.inputs['Normal'])


def house(glow=2.0):
    """The back of the house: a plastered wall, a tall window with warm light behind a thin curtain, shutters,
    a sill and the edge of the roof. Returns the window's lamp and the glass material's strength socket."""
    plaster = kit.noise_mat('Plaster', [(0.3, '#b9a98e'), (0.55, '#d6c7a8'), (0.8, '#e6dabd')], scale=2.2, detail=8.0,
                            rough=0.9, spec=0.15, bump=0.25, bump_scale=45.0)
    y = HOUSE_Y
    w = WIN
    # the wall as four slabs around the window opening
    _boxes('HouseWall', [(HOUSE_X0, y, 0, w['x0'], y + 0.3, EAVES), (w['x1'], y, 0, HOUSE_X1, y + 0.3, EAVES),
                         (w['x0'], y, 0, w['x1'], y + 0.3, w['z0']), (w['x0'], y, w['z1'], w['x1'], y + 0.3, EAVES)],
           plaster)
    base = kit.noise_mat('HouseBase', [(0.3, '#6f6658'), (0.7, '#8f8472')], scale=9.0, rough=0.9, spec=0.15, bump=0.3)
    _boxes('HouseBase', [(HOUSE_X0 - 0.02, y - 0.03, 0, HOUSE_X1, y, 0.24)], base)
    wood = kit.noise_mat('WinWood', [(0.3, '#e9e2d0'), (0.7, '#f6f1e2')], scale=30.0, rough=0.5, spec=0.4)
    fr = 0.06
    bars = [(w['x0'] - fr, y - 0.04, w['z0'] - fr, w['x0'], y + 0.05, w['z1'] + fr),
            (w['x1'], y - 0.04, w['z0'] - fr, w['x1'] + fr, y + 0.05, w['z1'] + fr),
            (w['x0'], y - 0.04, w['z1'], w['x1'], y + 0.05, w['z1'] + fr),
            (w['x0'] - 0.10, y - 0.10, w['z0'] - fr - 0.03, w['x1'] + 0.10, y + 0.05, w['z0'])]
    xm = 0.5 * (w['x0'] + w['x1'])
    bars.append((xm - 0.018, y - 0.01, w['z0'], xm + 0.018, y + 0.03, w['z1']))
    for k in (1, 2):
        zz = w['z0'] + (w['z1'] - w['z0']) * k / 3.0
        bars.append((w['x0'], y - 0.01, zz - 0.014, w['x1'], y + 0.03, zz + 0.014))
    _boxes('WinFrame', bars, wood)
    shut = kit.noise_mat('Shutter', [(0.3, '#3f6f68'), (0.7, '#5a8f84')], scale=25.0, rough=0.55, spec=0.35, bump=0.2)
    sh = []
    for sx0, sx1 in ((w['x0'] - fr - 0.46, w['x0'] - fr - 0.01), (w['x1'] + fr + 0.01, w['x1'] + fr + 0.46)):
        sh.append((sx0, y - 0.035, w['z0'] - 0.02, sx1, y, w['z1'] + 0.02))
        for k in range(9):
            zz = w['z0'] + 0.06 + (w['z1'] - w['z0'] - 0.12) * k / 8.0
            sh.append((sx0 + 0.04, y - 0.05, zz - 0.02, sx1 - 0.04, y - 0.03, zz + 0.02))
    _boxes('Shutters', sh, shut)
    # the lit curtain behind the glass
    gm = bpy.data.materials.new('WinGlow')
    gm.use_nodes = True
    nt = gm.node_tree
    nt.nodes.remove(nt.nodes['Principled BSDF'])
    em = nt.nodes.new('ShaderNodeEmission')
    tc = nt.nodes.new('ShaderNodeTexCoord')
    wv = nt.nodes.new('ShaderNodeTexWave')
    wv.inputs['Scale'].default_value = 11.0
    wv.inputs['Distortion'].default_value = 1.2
    wv.inputs['Detail'].default_value = 1.0
    nt.links.new(tc.outputs['Object'], wv.inputs['Vector'])
    gr = nt.nodes.new('ShaderNodeSeparateXYZ')
    nt.links.new(tc.outputs['Object'], gr.inputs[0])
    hz = nt.nodes.new('ShaderNodeMapRange')
    hz.inputs['From Min'].default_value = w['z0']
    hz.inputs['From Max'].default_value = w['z1']
    hz.inputs['To Min'].default_value = 1.15
    hz.inputs['To Max'].default_value = 0.62
    nt.links.new(gr.outputs['Z'], hz.inputs['Value'])
    cr = kit.ramp(nt, [(0.0, '#ff7a1a'), (0.5, '#ff9838'), (1.0, '#ffb45a')])
    nt.links.new(wv.outputs['Fac'], cr.inputs['Fac'])
    st = nt.nodes.new('ShaderNodeMath')
    st.operation = 'MULTIPLY'
    st.inputs[1].default_value = glow
    st.name = 'glow'
    nt.links.new(hz.outputs['Result'], st.inputs[0])
    nt.links.new(cr.outputs['Color'], em.inputs['Color'])
    nt.links.new(st.outputs[0], em.inputs['Strength'])
    nt.links.new(em.outputs[0], nt.nodes['Material Output'].inputs['Surface'])
    gm.cycles.emission_sampling = 'NONE'
    kit.mesh('WinGlow', [(w['x0'], y + 0.06, w['z0']), (w['x1'], y + 0.06, w['z0']), (w['x1'], y + 0.06, w['z1']),
                         (w['x0'], y + 0.06, w['z1'])], [(0, 1, 2, 3)], gm, smooth=False)
    # the roof's edge
    roofm = kit.noise_mat('Roof', [(0.3, '#6b3f2c'), (0.7, '#8f563a')], scale=14.0, rough=0.8, spec=0.2, bump=0.4)
    rv = [(HOUSE_X0 - 0.25, y - 0.35, EAVES - 0.04), (HOUSE_X1, y - 0.35, EAVES - 0.04),
          (HOUSE_X1, y + 2.6, EAVES + 1.5), (HOUSE_X0 - 0.25, y + 2.6, EAVES + 1.5),
          (HOUSE_X0 - 0.25, y - 0.35, EAVES + 0.06), (HOUSE_X1, y - 0.35, EAVES + 0.06),
          (HOUSE_X1, y + 2.6, EAVES + 1.6), (HOUSE_X0 - 0.25, y + 2.6, EAVES + 1.6)]
    _tiles(roofm)
    kit.mesh('Roof', rv, [(0, 1, 5, 4), (4, 5, 6, 7), (3, 0, 4, 7), (0, 3, 2, 1)], roofm, smooth=False)
    # the side of the house (so its corner reads as a solid building against the sky)
    _boxes('HouseSide', [(HOUSE_X0, y + 0.3, 0, HOUSE_X0 + 0.3, y + 4.0, EAVES)], plaster)
    # a window box of flowers under the sill, and a creeper up the wall and along under the eaves
    rng = np.random.default_rng(12)
    boxm = kit.noise_mat('WinBox', [(0.3, '#5a3a22'), (0.7, '#7d5533')], scale=20.0, rough=0.7, spec=0.2)
    _boxes('WinBox', [(w['x0'] - 0.06, y - 0.27, w['z0'] - 0.25, w['x1'] + 0.06, y - 0.09, w['z0'] - 0.10)], boxm)
    d1, f1 = g.icosphere(1)
    V, F, C = [], [], []
    petals = [g.lin(c) for c in ('#ff7fa0', '#ffd6e4', '#ffe27a', '#ff9a6a', '#fff6ee', '#e88ad0')]
    greens = [g.lin(c) for c in ('#3f7426', '#5c9632', '#84b23a')]
    for i in range(190):
        flower = i < 60
        c = np.array([rng.uniform(w['x0'] - 0.04, w['x1'] + 0.04), rng.uniform(y - 0.27, y - 0.10),
                      w['z0'] - 0.10 + (rng.uniform(0.03, 0.10) if flower else rng.uniform(-0.06, 0.07))])
        r = rng.uniform(0.018, 0.028) if flower else rng.uniform(0.022, 0.04)
        v = d1 * np.array([r, r, r * (0.6 if flower else 0.8)]) + c
        base = sum(len(a) for a in V)
        V.append(v), F.append(f1 + base)
        col = petals[rng.integers(len(petals))] if flower else greens[rng.integers(len(greens))] * rng.uniform(0.7, 1.1)
        C.append(np.repeat(col[None, :], len(v), 0))
    fm = kit.principled('Flowers', attr='col', rough=0.55, spec=0.3)
    kit.add_translucent(fm, 0.25)
    kit.mesh('Flowers', np.concatenate(V), np.concatenate(F), fm, None, np.concatenate(C))
    bush(centre=(HOUSE_X0, y - 0.03), seed=6, leaves=2300, name='Creeper',
         blobs=[((0.20, 0.0, 1.10), (0.17, 0.06, 1.12)), ((0.95, 0.0, 2.28), (0.85, 0.06, 0.20)),
                ((0.32, 0.0, 2.05), (0.26, 0.06, 0.34))])
    # the light the window throws into the garden
    lamp = kit.area_lamp('WindowLight', (xm, y - 0.12, 0.5 * (w['z0'] + w['z1'])), (xm - 0.6, y - 3.0, 0.1), 60.0,
                         '#ffab5c', size=w['x1'] - w['x0'], size_y=w['z1'] - w['z0'])
    return lamp, st.inputs[1]


def backdrop(seed=3, low=1.0):
    """Far hedges and trees: big soft shapes behind everything, softened by the evening air (see Sky).
    low scales the height of the hedge row behind the garden (the last shot keeps it low so the stars show)."""
    rng = np.random.default_rng(seed)
    m = kit.noise_mat('FarGreen', [(0.3, '#16261a'), (0.6, '#2a4424'), (0.85, '#44602c')], scale=3.5, detail=6.0,
                      rough=0.9, spec=0.1)
    V, F = [], []
    d, f = g.icosphere(3)
    items = []  # (x, y, height, radius)
    for x in np.arange(-11.0, 2.0, 1.1):
        items.append((x + rng.uniform(-0.3, 0.3), rng.uniform(6.2, 7.2), rng.uniform(0.42, 0.66) * low, rng.uniform(0.8, 1.2)))
    for x in np.arange(-15.0, -4.5, 2.6):
        items.append((x + rng.uniform(-1, 1), rng.uniform(11.0, 14.0), rng.uniform(1.6, 2.8), rng.uniform(1.6, 2.4)))
    for x in (-3.6, -2.6):
        items.append((x, rng.uniform(2.6, 3.2), rng.uniform(0.45, 0.6), rng.uniform(0.6, 0.8)))
    for (x, y, h, r) in items:
        n1 = vnoise(d + rng.uniform(0, 30), 2.0, 2) - 0.5
        v = d * np.array([r, r * 0.8, h]) * (1 + 0.35 * n1)[:, None] + np.array([x, y, h * 0.75])
        base = sum(len(a) for a in V)
        V.append(v), F.append(f + base)
    return kit.mesh('FarGreen', np.concatenate(V), np.concatenate(F), m)


# ------------------------------------------------------------------------------------------------ the old boot
def old_boot(s=BOOT_S):
    """An old leather boot lying on its side. Returns its 'wobble' empty: turn it about its local X (the shaft's
    axis) to rock the boot. Built upright (toe to -Y, shaft up), then laid down so the opening faces BOOT_A."""
    st = [  # centre (y, z), tangent (y, z), half-width a (across), half-height b, colour weight (0 leather .. 1 dark)
        ((-0.232, 0.030), (1.0, 0.03), 0.016, 0.010), ((-0.220, 0.032), (1.0, 0.05), 0.040, 0.022),
        ((-0.185, 0.036), (1.0, 0.08), 0.050, 0.028), ((-0.125, 0.042), (1.0, 0.12), 0.050, 0.034),
        ((-0.068, 0.052), (0.92, 0.38), 0.048, 0.044), ((-0.022, 0.076), (0.66, 0.75), 0.049, 0.056),
        ((0.000, 0.110), (0.25, 0.97), 0.050, 0.058), ((0.004, 0.140), (0.0, 1.0), 0.052, 0.060),
        ((0.004, 0.172), (0.0, 1.0), 0.055, 0.063), ((0.004, 0.198), (0.0, 1.0), 0.060, 0.067),
        ((0.004, 0.208), (0.0, 1.0), 0.0575, 0.0645),
        ((0.004, 0.202), (0.0, 1.0), 0.052, 0.059), ((0.004, 0.160), (0.0, 1.0), 0.049, 0.056),
        ((0.004, 0.100), (0.0, 1.0), 0.046, 0.052), ((0.004, 0.062), (0.0, 1.0), 0.040, 0.046)]
    segs = 28
    ph = np.linspace(0, 2 * math.pi, segs, endpoint=False)
    rings, cols = [], []
    leather, worn, inside = g.lin('#7a4a2b'), g.lin('#a9774a'), g.lin('#3a2416')
    for i, ((cy, cz), (ty, tz), a, b) in enumerate(st):
        t = np.array([0.0, ty, tz]) / math.hypot(ty, tz)
        u = np.array([0.0, -t[2], t[1]])
        ring = np.array([0.0, cy, cz]) + np.outer(np.cos(ph), np.array([a, 0, 0])) + np.outer(np.sin(ph), u * b)
        rings.append(ring * s)
        if i >= 11:
            c = np.repeat(inside[None, :], segs, 0)
        else:
            wear = 0.35 * (i in (9, 10)) + 0.25 * np.clip(np.sin(ph), 0, 1) * (2 < i < 6)
            c = g.mix(np.repeat(leather[None, :], segs, 0), worn, np.clip(wear, 0, 1) * np.ones(segs))
            if i <= 2:          # a darker toe cap
                c = np.repeat((leather * 0.55)[None, :], segs, 0)
        cols.append(c)
    # smooth the shape along the boot: four rings between every two stations (outside and inside separately, so the
    # rim stays crisp)
    def fine(rs, per=4):
        a = kit.catmull(np.array(rs).reshape(len(rs), -1), per)
        return [r.reshape(segs, 3) for r in a]
    ro, ri = fine(rings[:11]), fine(rings[10:])[1:]
    co = [cols[min(10, int(round(i / 4.0)))] for i in range(len(ro))]
    ci = [cols[11]] * len(ri)
    rings, cols = ro + ri, co + ci
    v, f = kit.loft(rings, close_start=True, close_end=True)
    col = np.concatenate(cols + [cols[0][:1], cols[-1][:1]])
    lm = kit.noise_mat('BootLeather', [(0.25, (0.62, 0.62, 0.62)), (0.6, (0.9, 0.9, 0.9)), (0.85, (1.12, 1.1, 1.05))],
                       scale=28.0, detail=7.0, rough=0.62, spec=0.35, bump=0.45, bump_scale=90.0, attr_mul='col',
                       distortion=0.6)
    root = kit.empty('Boot')
    wob = kit.empty('Boot.wobble', root, (0, 0, BOOT_ZC))
    roll = kit.empty('Boot.roll', wob)
    roll.rotation_euler = (RAD(BOOT_ROLL), 0, 0)
    lie = kit.empty('Boot.lie', roll)
    lie.rotation_euler = (0, RAD(-90), 0)
    kit.mesh('Boot.upper', v, f, lm, lie, col, subsurf=1)
    # sole and heel
    solem = kit.noise_mat('BootSole', [(0.3, '#2a2019'), (0.7, '#5a4634')], scale=40.0, rough=0.8, spec=0.2, bump=0.4)
    out = []
    for yy, hw in ((-0.246, 0.014), (-0.234, 0.040), (-0.190, 0.057), (-0.125, 0.058), (-0.055, 0.050), (0.010, 0.054),
                   (0.052, 0.048), (0.072, 0.022)):
        out.append((yy, hw))
    top, bot = [], []
    for (yy, hw) in out:
        top.append((-hw * s, yy * s, 0.024 * s))
        bot.append((-hw * s, yy * s, -0.006 * s))
    for (yy, hw) in reversed(out):
        top.append((hw * s, yy * s, 0.024 * s))
        bot.append((hw * s, yy * s, -0.006 * s))
    n = len(top)
    sv = top + bot
    sf = [tuple(range(n))[::-1], tuple(range(n, 2 * n))]
    for i in range(n):
        j = (i + 1) % n
        sf.append((i, j, n + j, n + i))
    kit.mesh('Boot.sole', sv, sf, solem, lie, smooth=False)
    hv, hf = _box(-0.050 * s, -0.012 * s, -0.026 * s, 0.050 * s, 0.070 * s, -0.004 * s)
    kit.mesh('Boot.heel', hv, hf, solem, lie, smooth=False)
    # laces: short bars across the front of the shaft and the instep, with eyelets
    lacem = kit.principled('BootLace', color='#d9c38a', rough=0.7, spec=0.2)
    eyem = kit.principled('BootEyelet', color='#b08a4a', rough=0.35, spec=0.5, metallic=0.8)
    for cz in (0.126, 0.150, 0.174):
        k = (cz - 0.11) / 0.088
        sa, sb = 0.050 + 0.010 * k, 0.058 + 0.009 * k
        a = 0.024 + 0.004 * k
        cy = 0.004 - sb * math.sqrt(1 - (a / sa) ** 2) - 0.0015
        pL = np.array([-a, cy, cz]) * s
        pR = np.array([a, cy, cz]) * s
        mid = np.array([0.0, 0.004 - sb - 0.003, cz]) * s
        tv, tf = kit.tube(kit.catmull([pL, mid, pR], 4), 0.0028 * s, 8)
        kit.mesh('Boot.lace', tv, tf, lacem, lie, subsurf=1)
        for p in (pL, pR):
            ev, ef = g.uv_sphere(0.0052 * s, 10, 6)
            kit.mesh('Boot.eyelet', ev * np.array([1, 0.5, 1]), ef, eyem, lie, loc=tuple(p))
    # three more laces over the instep
    for cy, cc, bb_, aa in ((-0.074, 0.051, 0.043, 0.048), (-0.100, 0.046, 0.038, 0.049), (-0.126, 0.042, 0.034, 0.050)):
        a = 0.027
        zz = cc + bb_ * math.sqrt(1 - (a / aa) ** 2) + 0.0015
        pL = np.array([-a, cy, zz]) * s
        pR = np.array([a, cy, zz]) * s
        mid = np.array([0.0, cy, cc + bb_ + 0.003]) * s
        tv, tf = kit.tube(kit.catmull([pL, mid, pR], 4), 0.0028 * s, 8)
        kit.mesh('Boot.lace', tv, tf, lacem, lie, subsurf=1)
        for p in (pL, pR):
            ev, ef = g.uv_sphere(0.0052 * s, 10, 6)
            kit.mesh('Boot.eyelet', ev * np.array([1, 1, 0.5]), ef, eyem, lie, loc=tuple(p))
    # a pull loop at the back of the collar
    lp = [np.array([0.0, 0.066, 0.182]) * s, np.array([0.0, 0.082, 0.208]) * s, np.array([0.0, 0.070, 0.236]) * s,
          np.array([0.0, 0.056, 0.214]) * s]
    tv, tf = kit.tube(kit.catmull(lp + [lp[0]], 4), 0.0035 * s, 8, cap=False)
    kit.mesh('Boot.loop', tv, tf, lm, lie, np.repeat(worn[None, :], len(tv), 0), subsurf=1)
    # put the opening's centre at BOOT_O with the opening facing BOOT_A. In the lying frame the opening is at
    # local -X (0.26 * s from the heel) and the toe points to local -Y.
    yaw = math.atan2(-BOOT_A[1], -BOOT_A[0])
    root.rotation_euler = (0, 0, yaw)
    off = Matrix.Rotation(yaw, 4, 'Z') @ Vector((-0.205 * s, 0.0, 0.0))
    root.location = (BOOT_O[0] - off.x, BOOT_O[1] - off.y, 0.0)
    return wob


# ------------------------------------------------------------------------------------------------ the watering can
def watering_can(loc=CAN, yaw=132.0):
    """A green enamel watering can; its spout points to local -Y."""
    root = kit.empty('Can')
    root.location = (loc[0], loc[1], 0.0)
    root.rotation_euler = (0, 0, RAD(yaw))
    m = kit.noise_mat('CanGreen', [(0.3, '#2f7a45'), (0.6, '#3f9655'), (0.85, '#58ab66')], scale=6.0, detail=5.0,
                      rough=0.28, spec=0.5, coat=0.4, bump=0.05, bump_scale=40.0)
    dark = kit.principled('CanRim', color='#1f4f30', rough=0.35, spec=0.5)
    prof = [(0.0, 0.0), (0.0, 0.070), (0.004, 0.084), (0.012, 0.086), (0.10, 0.089), (0.185, 0.091), (0.192, 0.094),
            (0.198, 0.092), (0.196, 0.086), (0.188, 0.084), (0.060, 0.080), (0.012, 0.078), (0.010, 0.0)]
    segs = 40
    ph = np.linspace(0, 2 * math.pi, segs, endpoint=False)
    rings = [np.stack([np.cos(ph) * r + 0.0, np.sin(ph) * r, np.full(segs, z)], 1) for z, r in prof[1:-1]]
    v, f = kit.loft(rings, close_start=True, close_end=True)
    kit.mesh('Can.body', v, f, m, root, subsurf=1)
    # spout with a rose
    sp = kit.catmull([(0, -0.070, 0.045), (0, -0.115, 0.075), (0, -0.175, 0.150), (0, -0.235, 0.215)], 5)
    tv, tf = kit.tube(sp, np.linspace(0.021, 0.012, len(sp)), 12)
    kit.mesh('Can.spout', tv, tf, m, root, subsurf=1)
    ax = g.unit(np.array(sp[-1]) - np.array(sp[-2]))
    rose = [np.array(sp[-1]) - ax * 0.004, np.array(sp[-1]) + ax * 0.022, np.array(sp[-1]) + ax * 0.030]
    tv, tf = kit.tube(np.array(rose), [0.013, 0.030, 0.029], 16)
    kit.mesh('Can.rose', tv, tf, dark, root, subsurf=1)
    # back handle and top handle
    hb = kit.catmull([(0, 0.082, 0.175), (0, 0.135, 0.165), (0, 0.150, 0.105), (0, 0.120, 0.050), (0, 0.082, 0.040)], 5)
    tv, tf = kit.tube(hb, 0.0075, 10)
    kit.mesh('Can.handle', tv, tf, m, root, subsurf=1)
    ht = kit.catmull([(0, -0.080, 0.192), (0, -0.050, 0.262), (0, 0.010, 0.285), (0, 0.065, 0.262), (0, 0.086, 0.192)], 5)
    tv, tf = kit.tube(ht, 0.0065, 10)
    kit.mesh('Can.top', tv, tf, m, root, subsurf=1)
    return root


# ------------------------------------------------------------------------------------------------ sky and world
def _air(m, near, far, k):
    """Evening air for a far material: beyond `near` metres from the lens it fades (up to k at `far`) into the
    colour of the sky at the horizon, so far ground and far trees sink into haze and no hard line is left where the
    ground meets the sky. Returns the value node that says how far night has come (0 dusk .. 1 night)."""
    nt = m.node_tree
    out = nt.nodes['Material Output']
    surf = out.inputs['Surface'].links[0].from_socket
    cd = nt.nodes.new('ShaderNodeCameraData')
    mr = nt.nodes.new('ShaderNodeMapRange')
    mr.clamp = True
    mr.interpolation_type = 'SMOOTHSTEP'
    for key, x in (('From Min', near), ('From Max', far), ('To Min', 0.0), ('To Max', k)):
        mr.inputs[key].default_value = x
    nt.links.new(cd.outputs['View Distance'], mr.inputs['Value'])
    v = nt.nodes.new('ShaderNodeValue')
    v.name = 'air_night'
    col = nt.nodes.new('ShaderNodeMixRGB')
    col.inputs['Color1'].default_value = kit.lin4('#f0b68f')
    col.inputs['Color2'].default_value = kit.lin4('#3a4e8a')
    nt.links.new(v.outputs[0], col.inputs['Fac'])
    em = nt.nodes.new('ShaderNodeEmission')
    em.inputs['Strength'].default_value = 0.85
    nt.links.new(col.outputs['Color'], em.inputs['Color'])
    mx = nt.nodes.new('ShaderNodeMixShader')
    nt.links.new(mr.outputs['Result'], mx.inputs['Fac'])
    nt.links.new(surf, mx.inputs[1])
    nt.links.new(em.outputs[0], mx.inputs[2])
    nt.links.new(mx.outputs[0], out.inputs['Surface'])
    m.cycles.emission_sampling = 'NONE'
    return v


class Sky:
    """The world: what the lens sees (a painted dusk-to-night sky with stars) and what lights the scene (a soft
    even sky colour). set(frame, ...) keys the change from evening to night. Build it after the set: it also puts
    evening air on the far ground and the far hedges, and that air turns to night with the sky."""

    def __init__(self):
        w = bpy.data.worlds.new('Sky')
        w.use_nodes = True
        nt = w.node_tree
        self.nt = nt
        Lk = nt.links.new

        def val(name, v):
            n = nt.nodes.new('ShaderNodeValue')
            n.name = name
            n.outputs[0].default_value = v
            return n

        def m(op, a, b=None, c=None):
            n = nt.nodes.new('ShaderNodeMath')
            n.operation = op
            for i, x in enumerate((a, b, c)):
                if x is None:
                    continue
                if isinstance(x, (int, float)):
                    n.inputs[i].default_value = x
                else:
                    Lk(x, n.inputs[i])
            return n.outputs[0]

        def mr(v, a, b, c=0.0, d=1.0, smooth=True):
            n = nt.nodes.new('ShaderNodeMapRange')
            n.clamp = True
            if smooth:
                n.interpolation_type = 'SMOOTHSTEP'
            for key, x in (('Value', v), ('From Min', a), ('From Max', b), ('To Min', c), ('To Max', d)):
                if isinstance(x, (int, float)):
                    n.inputs[key].default_value = x
                else:
                    Lk(x, n.inputs[key])
            return n.outputs['Result']

        def mixc(fac, a, b, blend='MIX'):
            n = nt.nodes.new('ShaderNodeMixRGB')
            n.blend_type = blend
            for key, x in (('Fac', fac), ('Color1', a), ('Color2', b)):
                if isinstance(x, (int, float)):
                    n.inputs[key].default_value = x
                elif isinstance(x, tuple):
                    n.inputs[key].default_value = x
                else:
                    Lk(x, n.inputs[key])
            return n.outputs['Color']

        self.night = val('night', 0.0)       # 0 dusk .. 1 night (the colour of the sky)
        self.stars = val('stars', 0.0)       # 0 none .. 1 all out
        self.time = val('time', 0.0)         # seconds, for the twinkle
        self.amb = val('amb', 0.3)           # strength of the sky as a light
        geo = nt.nodes.new('ShaderNodeNewGeometry')
        sep = nt.nodes.new('ShaderNodeSeparateXYZ')
        Lk(geo.outputs['Incoming'], sep.inputs[0])
        up = m('MULTIPLY', sep.outputs['Z'], -1.0)
        dusk = kit.ramp(nt, [(0.0, '#ffcf96'), (0.06, '#f9b28c'), (0.16, '#cf9cb4'), (0.30, '#8790c2'), (0.55, '#4f6cab'),
                             (1.0, '#3a5596')])
        Lk(up, dusk.inputs['Fac'])
        ngt = kit.ramp(nt, [(0.0, '#3d528f'), (0.10, '#2a3d7a'), (0.35, '#18275a'), (1.0, '#0d1740')])
        Lk(up, ngt.inputs['Fac'])
        sky = mixc(self.night.outputs[0], dusk.outputs['Color'], ngt.outputs['Color'])
        # thin evening clouds, lit from below; they sink into the dark as night comes
        scl = nt.nodes.new('ShaderNodeVectorMath')
        scl.operation = 'MULTIPLY'
        Lk(geo.outputs['Incoming'], scl.inputs[0])
        scl.inputs[1].default_value = (1.0, 1.0, 7.0)
        cn = nt.nodes.new('ShaderNodeTexNoise')
        cn.inputs['Scale'].default_value = 2.6
        cn.inputs['Detail'].default_value = 6.0
        cn.inputs['Roughness'].default_value = 0.55
        Lk(scl.outputs['Vector'], cn.inputs['Vector'])
        cl = mr(cn.outputs['Fac'], 0.52, 0.74)
        band = m('MULTIPLY', mr(up, 0.02, 0.10), mr(up, 0.55, 0.30))
        cfac = m('MULTIPLY', m('MULTIPLY', cl, band), m('MULTIPLY_ADD', self.night.outputs[0], -0.50, 0.62))
        ccol = mixc(self.night.outputs[0], kit.lin4('#ffb6a0'), kit.lin4('#3a4a86'))
        sky = mixc(cfac, sky, ccol)
        # stars: one per cell of a Voronoi pattern on the view direction; each has its own moment to appear
        vor = nt.nodes.new('ShaderNodeTexVoronoi')
        vor.voronoi_dimensions = '3D'
        vor.feature = 'F1'
        vor.inputs['Scale'].default_value = 62.0
        Lk(geo.outputs['Incoming'], vor.inputs['Vector'])
        sc = nt.nodes.new('ShaderNodeSeparateColor')
        Lk(vor.outputs['Color'], sc.inputs[0])
        r_, g_, b_ = sc.outputs[0], sc.outputs[1], sc.outputs[2]
        size = m('MULTIPLY_ADD', b_, 0.075, 0.055)
        core = mr(vor.outputs['Distance'], 0.0, size, 1.0, 0.0)
        chosen = m('GREATER_THAN', r_, 0.15)
        when = m('MULTIPLY_ADD', g_, 0.80, 0.08)
        appear = mr(m('SUBTRACT', self.stars.outputs[0], when), -0.04, 0.04, 0.0, 1.0)
        tw = m('MULTIPLY_ADD', m('SINE', m('ADD', m('MULTIPLY', self.time.outputs[0], m('MULTIPLY_ADD', b_, 5.0, 2.5)),
                                         m('MULTIPLY', g_, 40.0))), 0.22, 0.78)
        bright = m('MULTIPLY', m('MULTIPLY', core, chosen), m('MULTIPLY', appear, tw))
        bright = m('MULTIPLY', bright, m('MULTIPLY_ADD', m('MULTIPLY', b_, b_), 7.0, 2.4))
        bright = m('MULTIPLY', bright, mr(up, 0.03, 0.22))
        scol = mixc(m('FRACT', m('MULTIPLY', r_, 7.0)), kit.lin4('#cfdcff'), kit.lin4('#fff0d6'))
        bg_cam = nt.nodes.new('ShaderNodeBackground')
        Lk(sky, bg_cam.inputs['Color'])
        bg_cam.inputs['Strength'].default_value = 0.9
        bg_star = nt.nodes.new('ShaderNodeBackground')
        Lk(scol, bg_star.inputs['Color'])
        Lk(bright, bg_star.inputs['Strength'])
        addc = nt.nodes.new('ShaderNodeAddShader')
        Lk(bg_cam.outputs[0], addc.inputs[0])
        Lk(bg_star.outputs[0], addc.inputs[1])
        # the sky as a light: an even colour (no noise from it), cool at dusk, deep blue at night
        bg = nt.nodes['Background']
        Lk(mixc(self.night.outputs[0], kit.lin4('#93a8dc'), kit.lin4('#3d58ad')), bg.inputs['Color'])
        Lk(self.amb.outputs[0], bg.inputs['Strength'])
        lp = nt.nodes.new('ShaderNodeLightPath')
        mix = nt.nodes.new('ShaderNodeMixShader')
        Lk(lp.outputs['Is Camera Ray'], mix.inputs['Fac'])
        Lk(bg.outputs[0], mix.inputs[1])
        Lk(addc.outputs[0], mix.inputs[2])
        Lk(mix.outputs[0], nt.nodes['World Output'].inputs['Surface'])
        bpy.context.scene.world = w
        self.air = []
        for name, near, far, k in (('Ground', 10.0, 52.0, 0.95), ('FarGreen', 2.0, 28.0, 0.50)):
            mm = bpy.data.materials.get(name)
            if mm is not None:
                self.air.append(_air(mm, near, far, k))

    def set_night(self, v):
        """Dusk (0) or night (1) for a whole shot, without keys."""
        self.night.outputs[0].default_value = v
        for n in self.air:
            n.outputs[0].default_value = v

    def set(self, frame, night=None, stars=None, amb=None):
        for node, v in ((self.night, night), (self.stars, stars), (self.amb, amb)):
            if v is not None:
                node.outputs[0].default_value = v
                node.outputs[0].keyframe_insert('default_value', frame=frame)
        if night is not None:
            for n in self.air:
                n.outputs[0].default_value = night
                n.outputs[0].keyframe_insert('default_value', frame=frame)
        self.time.outputs[0].default_value = (frame - 1) / 24.0
        self.time.outputs[0].keyframe_insert('default_value', frame=frame)


# ------------------------------------------------------------------------------------------------ fireflies
class Fireflies:
    """Small warm lights that drift over the grass. Each is a tiny glowing ball with a weak lamp inside."""

    def __init__(self, flies, seed=17):
        """flies: [dict(c=(x, y, z) centre, r=(rx, ry, rz) drift, on=frame it lights up, lamp=watts (0: no lamp))]"""
        rng = np.random.default_rng(seed)
        self.mat = kit.emission_mat('Firefly', '#f6ff8a', 55.0, obj_scaled=True)
        self.mat.cycles.emission_sampling = 'NONE'
        self.items = []
        ev, ef = g.uv_sphere(0.0036, 10, 6)
        for i, fl in enumerate(flies):
            ob = kit.mesh('Firefly%d' % i, ev, ef, self.mat, None)
            ob.visible_shadow = False
            lamp = None
            if fl.get('lamp', 0.0) > 0:
                lamp = kit.point_lamp('FireflyLamp%d' % i, (0, 0, 0), 0.0, '#eaff7a', radius=0.012)
                lamp.parent = ob
            self.items.append(dict(ob=ob, lamp=lamp, spec=fl, ph=rng.uniform(0, 6.28, 4), sp=rng.uniform(0.6, 1.3, 3),
                                   blink=rng.uniform(0.25, 0.5), bph=rng.uniform(0, 6.28)))

    def key(self, frame, hold=None):
        """hold: None, or a frame from which the blinking settles to a steady glow (drift goes on)."""
        t = (frame - 1) / 24.0
        for it in self.items:
            fl = it['spec']
            c, r = fl['c'], fl['r']
            x = c[0] + r[0] * math.sin(it['sp'][0] * t * 0.9 + it['ph'][0])
            y = c[1] + r[1] * math.sin(it['sp'][1] * t * 0.7 + it['ph'][1])
            z = c[2] + r[2] * math.sin(it['sp'][2] * t * 1.3 + it['ph'][2])
            ob = it['ob']
            ob.location = (x, y, z)
            ob.keyframe_insert('location', frame=frame)
            on = kit.ramp01(frame, fl.get('on', -999), fl.get('on', -999) + 14)
            glow = 0.55 + 0.45 * math.sin(2 * math.pi * it['blink'] * t + it['bph'])
            glow = max(0.0, glow) ** 1.5
            b = on * (0.25 + 0.75 * glow)
            ob.color = (1.0, 1.0, 1.0, b)
            ob.keyframe_insert('color', frame=frame)
            # a firefly that has not lit yet is not there at all (a dark ball would drift through the picture)
            k = 0.001 + 0.999 * min(1.0, on * 4.0)
            ob.scale = (k, k, k)
            ob.keyframe_insert('scale', frame=frame)
            if it['lamp'] is not None:
                it['lamp'].data.energy = fl['lamp'] * b
                it['lamp'].data.keyframe_insert('energy', frame=frame)
