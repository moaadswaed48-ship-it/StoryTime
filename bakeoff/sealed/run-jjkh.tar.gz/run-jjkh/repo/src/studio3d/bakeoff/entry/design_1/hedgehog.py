"""Little Hedgehog, design proposal 1: "shape first".

The idea in one line: ONE soft dome, low and wide, with a big pale face set into it like a face in a hood.
What carries the charm is the outline, so that he reads at a glance even as a small shape on a phone:

  - a round bean of a body, head as wide as the body and no neck (a baby's proportions);
  - a heart-shaped pale face framed by a halo of swept-back spines (the "hood");
  - a short, slightly upturned snout that ends in an oversized button nose;
  - two small round ears and a little cowlick of longer spines on the forehead (his signature, and a part
    that can bounce a frame late);
  - tiny dark paws and two flat little feet peeping from under a fluffy cream skirt;
  - large dark eyes set low and wide, with soft lids so they can blink, smile and close into happy arcs.

Everything is built by this file when it runs: no models, images or downloads.

HOW TO USE (inside Blender, any scene):

    import hedgehog as hh
    h = hh.build_hedgehog('Little')                 # builds him at the world origin, standing, facing -Y
    hh.pose(h, **hh.STAND)                          # or hh.SNIFF, hh.CURL, or your own values
    hh.pose(h, frame=230, head_yaw=20, blink=1)     # frame=N also inserts keyframes on every control
    h.root.location = (x, y, 0); h.root.rotation_euler[2] = turn    # move and turn him with the root
    mama = hh.build_hedgehog('Mama', design=hh.MAMA, scale=1.5)     # same build, other numbers (one small test only)

Units are metres, Z is up, he faces -Y, +X is HIS left. At scale 1 he is about 15 cm long and 10 cm tall.
All parts are rigid pieces on a small tree of pivots (root > hips > neck > face parts), so animation is plain
keyframes on empties: nothing deforms, nothing is simulated, and every frame builds the same way.
The spines are a mesh (cheap, and they do not depend on the scene's curve settings); the fur is real strands
(Blender `Curves`), about 97,000 of them, shaded with a Principled BSDF (the cheaper of the two measured options).
The eyes are dark with a deliberately weak wet coat: their sparkle needs a small bright card beside the lens that
is seen only in reflections (patch.build_camera makes one). Without such a card the eyes go dull.
"""
import math
import os
import sys

import bpy
import numpy as np
from mathutils import Matrix

_HERE = os.path.dirname(os.path.abspath(__file__))
_BLENDER_LIB = os.path.abspath(os.path.join(_HERE, '..', '..', '..', 'blender'))
if _BLENDER_LIB not in sys.path:
    sys.path.insert(0, _BLENDER_LIB)

import lib  # noqa: E402
from lib import (capsule_profile, ellipsoid, empty, lathe, lin, mesh_obj, principled, sd_ellipsoid, sd_sphere,  # noqa: E402
                 smax, smin, tube_path)

# ------------------------------------------------------------------------------------------------ the design numbers

LITTLE = {
    # body: an egg, a wider haunch low at the back, a chest under the head
    'body_c': (0.0, 0.010, 0.049), 'body_r': (0.046, 0.040, 0.045),
    'haunch_c': (0.0, 0.016, 0.036), 'haunch_r': (0.047, 0.035, 0.031),
    'chest_c': (0.0, -0.012, 0.040), 'chest_r': (0.036, 0.028, 0.033),
    # head: a round ball nearly as wide as the body, chubby cheeks, and a short pointed snout stuck on its front.
    # Eyes and snout sit LOW on the face under a tall forehead: a baby's face.
    'head_c': (0.0, -0.033, 0.058), 'head_r': (0.040, 0.036, 0.035),
    'cheek_c': (0.022, -0.043, 0.0445), 'cheek_r': (0.019, 0.018, 0.016),
    'snout_c': (0.0, -0.066, 0.0440), 'snout_r': (0.0105, 0.021, 0.0100),
    'tip_c': (0.0, -0.082, 0.0465), 'tip_r': (0.0072, 0.0075, 0.0068),
    'nose_r': (0.0064, 0.0056, 0.0058),
    # eye_c is where the eye goes; the build then sets it so that exactly eye_pop of the ball stands out of the face
    'eye_c': (0.0183, -0.0600, 0.0545), 'eye_r': 0.0096, 'eye_pop': 0.0026,
    'ear_r': 0.0080,
    # the pale face: how far round the head it reaches (radians from "straight ahead") and how deep the peak dips
    'mask_side': 1.16, 'mask_peak': 0.24,
    # coat
    'spine_len': 0.017, 'spine_rad': 0.0015, 'spine_gap': 0.0028, 'spines_body': 3000, 'spines_head': 1150,
    'cowlick': 9,
    'fur_head': 52000, 'fur_body': 42000,
    # colours (sRGB hex). Face, chest, spines, paws and eyes are the ones given in content/stories/a13/cast.json
    'c_face': '#e8d2b0', 'c_muzzle': '#f6ead2', 'c_chest': '#f2e6cf', 'c_blush': '#e9977f', 'c_fringe': '#a8825d',
    'c_rim': '#c7a37c', 'c_under': '#33241a', 'c_paw': '#5a3a2a', 'c_nose': '#1f1411', 'c_eye': '#1c1210',
    'c_iris': '#33200f', 'c_lid': '#bfa07a', 'c_lash': '#3a2418', 'c_ear': '#a37c58', 'c_ear_in': '#dd947f',
    'c_mouth': '#5b3528',
    'spine_ramp': [(0.0, '#22160e'), (0.35, '#523828'), (0.70, '#74543a'), (0.87, '#a8845c'), (1.0, '#f2e0bc')],
}

# Mama: the same animal grown up. Longer nose that "leads the way", smaller eyes, darker spines, no cowlick.
# Build her with scale=1.5. These numbers are a starting point: she was test-rendered once, small, beside Little
# (stills.py --mama --only x_family). Her front legs are as short as his: she cannot cover her eyes with them yet.
MAMA = dict(LITTLE)
MAMA.update({
    'snout_c': (0.0, -0.070, 0.0445), 'snout_r': (0.0105, 0.027, 0.0100),
    'tip_c': (0.0, -0.092, 0.0465), 'tip_r': (0.0068, 0.0075, 0.0064),
    'nose_r': (0.0054, 0.0048, 0.0048),
    'eye_c': (0.0180, -0.0600, 0.0565), 'eye_r': 0.0072, 'eye_pop': 0.0022,
    'ear_r': 0.0070, 'cowlick': 0, 'mask_peak': 0.28,
    'c_face': '#e2c8a4', 'c_paw': '#4a3020', 'c_fringe': '#967252',
    'spine_ramp': [(0.0, '#241810'), (0.35, '#4e3626'), (0.70, '#6a4a32'), (0.88, '#8e6c4a'), (1.0, '#dcc8a2')],
})

HIPS = np.array([0.0, 0.019, 0.028])      # pivot for sitting up, rocking, squash and stretch
NECK = np.array([0.0, -0.018, 0.048])     # pivot for every head move

# ------------------------------------------------------------------------------------------------ poses

REST = dict(body_pitch=0.0, body_roll=0.0, body_yaw=0.0, lift=0.0, squash=1.0,
            head_pitch=0.0, head_yaw=0.0, head_roll=0.0, head_tuck=0.0, nose=0.0,
            blink=0.0, happy=0.0, smile=0.3, look_yaw=0.0, look_pitch=0.0,
            paw_l=0.0, paw_r=0.0, ear_l=0.0, ear_r=0.0, cowlick=0.0, feet_pitch=0.0, feet_fwd=0.0)
# angles are degrees; "pitch" is nose-up positive, "yaw" turns toward his left (+X), "roll" tips the head.
STAND = dict(REST, head_yaw=24.0, head_roll=7.0, head_pitch=8.0, paw_l=30.0, smile=0.6, ear_l=-6.0)
SNIFF = dict(REST, body_pitch=52.0, lift=0.002, head_pitch=-14.0, head_yaw=14.0, head_roll=-5.0, nose=14.0,
             blink=1.0, happy=1.0, paw_l=14.0, paw_r=30.0, feet_pitch=32.0, feet_fwd=0.016, cowlick=10.0)
# CURL is a sleepy tuck (face down, eyes closed), not yet a tight ball: seen only in a small test picture.
CURL = dict(REST, body_pitch=-6.0, squash=0.94, head_pitch=-34.0, head_tuck=0.012, blink=1.0, happy=0.0,
            paw_l=-35.0, paw_r=-35.0, ear_l=20.0, ear_r=20.0)

# ------------------------------------------------------------------------------------------------ small helpers


def _norm(v):
    return v / np.maximum(np.linalg.norm(v, axis=-1, keepdims=True), 1e-12)


def _ss(e0, e1, x):
    """Smoothstep; also works with e0 > e1 (then it falls from 1 to 0)."""
    t = np.clip((np.asarray(x, dtype=np.float64) - e0) / (e1 - e0), 0.0, 1.0)
    return t * t * (3.0 - 2.0 * t)


def _mix(a, b, w):
    w = np.asarray(w, dtype=np.float64)[..., None]
    return a * (1.0 - w) + b * w


def _rgb(hexc):
    return np.array(lin(hexc)[:3])


def _ramp(t, stops):
    pos = [s[0] for s in stops]
    cols = np.array([_rgb(s[1]) for s in stops])
    return np.stack([np.interp(t, pos, cols[:, k]) for k in range(3)], axis=-1)


def _grad(sdf, p, e=2.5e-4):
    g = np.empty_like(p)
    for i in range(3):
        d = np.zeros(3)
        d[i] = e
        g[:, i] = sdf(p + d) - sdf(p - d)
    return _norm(g)


def _sample_tris(verts, faces, n, rng):
    """n points spread evenly (by area) over a triangle mesh."""
    f = np.asarray(faces)
    a, b, c = verts[f[:, 0]], verts[f[:, 1]], verts[f[:, 2]]
    area = 0.5 * np.linalg.norm(np.cross(b - a, c - a), axis=1)
    idx = rng.choice(len(f), size=n, p=area / area.sum())
    u, v = rng.random(n), rng.random(n)
    flip = u + v > 1.0
    u[flip], v[flip] = 1.0 - u[flip], 1.0 - v[flip]
    return a[idx] + (b[idx] - a[idx]) * u[:, None] + (c[idx] - a[idx]) * v[:, None]


def _on_surface(sdf, p):
    """Points and outward normals pulled exactly onto the surface."""
    for _ in range(2):
        p = p - sdf(p)[:, None] * _grad(sdf, p)
    return p, _grad(sdf, p)


def _thin(p, gap):
    """At most one point per cell of size `gap`: evenly spaced roots instead of random clumps."""
    k = np.floor(p / gap).astype(np.int64)
    key = (k[:, 0] * 73856093) ^ (k[:, 1] * 19349663) ^ (k[:, 2] * 83492791)
    _, first = np.unique(key, return_index=True)
    return np.sort(first)


def _axes_euler(x, y, z):
    """Euler angles of the frame whose local axes are the given world directions."""
    return Matrix(((x[0], y[0], z[0]), (x[1], y[1], z[1]), (x[2], y[2], z[2]))).to_euler()


def _attr_mat(name, rough=0.6, sheen=0.0, spec=0.3, coat=0.0, coat_rough=0.2, sss=0.0):
    """Principled BSDF whose colour comes from the geometry's own 'col' attribute (painted by this file)."""
    m = principled(name, '#808080', rough=rough, sheen=sheen, sheen_rough=0.45, spec=spec, coat=coat,
                   coat_rough=coat_rough, sss=sss, sss_scale=0.004)
    nt = m.node_tree
    at = nt.nodes.new('ShaderNodeAttribute')
    at.attribute_name = 'col'
    nt.links.new(at.outputs['Color'], nt.nodes['Principled BSDF'].inputs['Base Color'])
    return m


def _rgba(rgb):
    rgb = np.asarray(rgb, dtype=np.float32)
    return np.concatenate([rgb, np.ones(rgb.shape[:-1] + (1,), dtype=np.float32)], axis=-1)


def _paint(obj, rgb):
    lib.set_point_attr(obj, 'col', _rgba(rgb), 'FLOAT_COLOR')


# ------------------------------------------------------------------------------------------------ forms


def body_sdf(P):
    def f(p):
        d = sd_ellipsoid(p, P['body_c'], P['body_r'])
        d = smin(d, sd_ellipsoid(p, P['haunch_c'], P['haunch_r']), 0.020)
        d = smin(d, sd_ellipsoid(p, P['chest_c'], P['chest_r']), 0.015)
        return d
    return f


def head_sdf(P, sockets=True):
    ex, ey, ez = P['eye_c']
    cx, cy, cz = P['cheek_c']

    def f(p):
        d = sd_ellipsoid(p, P['head_c'], P['head_r'])
        for s in (1, -1):
            d = smin(d, sd_ellipsoid(p, (s * cx, cy, cz), P['cheek_r']), 0.012)
        d = smin(d, sd_ellipsoid(p, P['snout_c'], P['snout_r']), 0.012)
        d = smin(d, sd_ellipsoid(p, P['tip_c'], P['tip_r']), 0.008)
        if sockets:
            for s in (1, -1):
                d = smax(d, -sd_sphere(p, (s * ex, ey, ez), P['eye_r'] * 1.03), 0.0025)
        return d
    return f


def _nose_c(P):
    return np.array(P['tip_c']) + np.array([0.0, -P['tip_r'][1] * 0.90, 0.0012])


def _flank_line(y):
    """Height where the spines stop and the cream skirt begins, along the body (higher at the chest)."""
    return 0.026 + 0.018 * _ss(0.0, -0.035, y) - 0.008 * _ss(0.015, 0.050, y)


def _body_colour(P, p):
    """White bib under the chin and white belly; the flanks are a warm tan so the pale face stays a clear shape."""
    bib = _ss(0.012, -0.012, p[:, 1]) * _ss(0.040, 0.022, np.abs(p[:, 0]))
    belly = _ss(0.032, 0.016, p[:, 2]) * _ss(0.048, 0.030, np.abs(p[:, 0]))
    tan = _mix(_rgb(P['c_fringe']), _rgb(P['c_face']), 0.30)
    return _mix(np.tile(tan, (len(p), 1)), _rgb(P['c_chest']), np.maximum(bib, belly))


def _head_zone(P, p):
    """Where a point of the head lies: m = 1 inside the pale heart-shaped face, 0 in the spines."""
    u = _norm(p - np.array(P['head_c']))
    f = _norm(np.array([0.0, -1.0, -0.25]))
    up = _norm(np.array([0.0, -0.25, 1.0]))
    th = np.arccos(np.clip(u @ f, -1.0, 1.0))
    ph = np.arctan2(u[:, 0], u @ up)                       # 0 at the top of the face, +-pi under the chin
    edge = P['mask_side'] - P['mask_peak'] * np.exp(-(ph / 0.34) ** 2) + 2.5 * _ss(1.75, 2.35, np.abs(ph))
    m = _ss(edge + 0.09, edge - 0.09, th)
    ex, ey, ez = P['eye_c']
    side = np.where(p[:, 0] >= 0, 1.0, -1.0)
    eye = np.stack([side * ex, np.full(len(p), ey), np.full(len(p), ez)], axis=1)
    d_eye = np.linalg.norm(p - eye, axis=1) / P['eye_r']
    d_nose = np.linalg.norm(p - _nose_c(P), axis=1)
    return dict(m=m, th=th, ph=ph, d_eye=d_eye, d_nose=d_nose, eye=eye)


def _head_fields(P, p, z):
    """Fur colour, length and lift over the face (also used to paint the skin under the fur)."""
    near = _ss(0.006, 0.024, z['d_nose'])                  # 0 at the nose, 1 on the cheeks
    cheek = _ss(1.05, 1.9, np.abs(z['ph'])) * _ss(0.55, 1.0, z['th'])
    fringe = _ss(0.80, 0.15, z['m'])                       # 1 where the face meets the spines
    throat = _ss(0.040, 0.030, p[:, 2])
    col = np.tile(_rgb(P['c_face']), (len(p), 1))
    col = _mix(col, _rgb(P['c_muzzle']), 0.65 * _ss(0.022, 0.008, z['d_nose']))
    col = _mix(col, _rgb(P['c_chest']), 0.8 * throat)
    bx, by, bz = 0.0255, P['cheek_c'][1] - P['cheek_r'][1] * 0.87, P['cheek_c'][2] - 0.0015
    side = np.where(p[:, 0] >= 0, 1.0, -1.0)
    bl = np.stack([side * bx, np.full(len(p), by), np.full(len(p), bz)], axis=1)
    col = _mix(col, _rgb(P['c_blush']), 0.78 * np.exp(-(np.linalg.norm(p - bl, axis=1) / 0.0088) ** 2))
    col = _mix(col, _rgb(P['c_rim']), 0.15 * _ss(1.75, 1.15, z['d_eye']))
    col = _mix(col, _rgb(P['c_fringe']), 0.85 * fringe)
    length = 0.0036 * (0.30 + 0.70 * near) + 0.0035 * cheek + 0.0032 * fringe + 0.0028 * throat
    lift = 0.42 + 0.45 * cheek + 0.55 * fringe + 0.20 * throat
    return col, length, lift


def _strands(p, n, comb, length, lift, rng, bend=0.55, grav=0.12, jitter=0.20):
    """Four-point strands: rise from the skin, lean along the comb direction, droop a little."""
    s = len(p)
    d0 = _norm(n * np.asarray(lift)[:, None] + comb + rng.normal(0.0, jitter, (s, 3)))
    seg = (length / 3.0)[:, None]
    lay = bend * (comb - 0.35 * n) + np.array([0.0, 0.0, -grav])
    p0 = p - n * 0.0004
    p1 = p0 + d0 * seg
    d1 = _norm(d0 + lay)
    p2 = p1 + d1 * seg
    d2 = _norm(d1 + lay)
    p3 = p2 + d2 * seg
    return np.stack([p0, p1, p2, p3], axis=1)


def _fur_object(name, pts, rgb, r_root, r_tip, mat, parent, rng, root_dark=0.62):
    """pts (S, K, 3), rgb (S, 3) -> one Curves object; the colour is stored on the points, darker at the root."""
    s, k = pts.shape[0], pts.shape[1]
    hc = bpy.data.hair_curves.new(name)
    hc.add_curves([k] * s)
    hc.position_data.foreach_set('vector', pts.astype(np.float32).ravel())
    t = np.linspace(0.0, 1.0, k)
    rad = np.tile((r_root + (r_tip - r_root) * t).astype(np.float32), s)
    a = hc.attributes.get('radius') or hc.attributes.new('radius', 'FLOAT', 'POINT')
    a.data.foreach_set('value', rad)
    var = rng.uniform(0.90, 1.08, (s, 1, 1))
    shade = (root_dark + (1.0 - root_dark) * t)[None, :, None]
    col = np.clip(rgb[:, None, :] * var * shade, 0.0, 1.0)
    c = hc.attributes.new('col', 'FLOAT_COLOR', 'POINT')
    c.data.foreach_set('color', _rgba(col).ravel())
    hc.materials.append(mat)
    o = bpy.data.objects.new(name, hc)
    lib.link(o)
    o.parent = parent
    return o


def _spine_object(name, roots, dirs, length, radius, var, stops, mat, parent):
    """Soft cones (five sides, blunt tip) as one mesh. Colour runs dark root > brown > cream tip."""
    s, k = len(roots), 5
    ref = np.where(np.abs(dirs[:, 2:3]) < 0.9, np.array([[0.0, 0.0, 1.0]]), np.array([[1.0, 0.0, 0.0]]))
    a = _norm(np.cross(dirs, ref))
    b = np.cross(dirs, a)
    ts = np.array([0.0, 0.50, 0.88])
    rs = np.array([1.0, 0.78, 0.46])
    ang = 2.0 * np.pi * np.arange(k) / k
    centre = roots[:, None, None, :] + dirs[:, None, None, :] * (ts[None, :, None, None] * length[:, None, None, None])
    off = a[:, None, None, :] * np.cos(ang)[None, None, :, None] + b[:, None, None, :] * np.sin(ang)[None, None, :, None]
    ring = centre + off * (rs[None, :, None, None] * radius[:, None, None, None])
    tip = roots + dirs * length[:, None]
    nv = 3 * k + 1
    verts = np.concatenate([ring.reshape(s, 3 * k, 3), tip[:, None, :]], axis=1).reshape(-1, 3)
    base = (np.arange(s) * nv)[:, None, None]
    quads = np.array([[j * k + i, j * k + (i + 1) % k, (j + 1) * k + (i + 1) % k, (j + 1) * k + i]
                      for j in range(2) for i in range(k)])
    tris = np.array([[2 * k + i, 2 * k + (i + 1) % k, 3 * k] for i in range(k)])
    faces = (base + quads[None]).reshape(-1, 4).tolist() + (base + tris[None]).reshape(-1, 3).tolist()
    o = mesh_obj(name, verts, faces, mat, parent, True, 0)
    tv = np.concatenate([np.repeat(ts, k), [1.0]])
    col = np.clip(_ramp(tv, stops)[None, :, :] * var[:, None, None], 0.0, 1.0).reshape(-1, 3)
    _paint(o, col)
    return o


def _eye_material(name, P):
    """Deep dark eye: big calm pupil, a faint warm iris ring, and a thin wet coat. Local +Z is the gaze.
    The coat is kept weak on purpose: a full mirror coat shows the whole horizon in the eye and reads as a glass
    marble. The sparkle comes from a bright catchlight card beside the lens (see patch.build_camera)."""
    m = principled(name, P['c_eye'], rough=0.5, coat=0.35, coat_rough=0.02, spec=0.0)
    nt = m.node_tree
    b = nt.nodes['Principled BSDF']
    b.inputs['Coat IOR'].default_value = 1.5
    lk = nt.links
    tc = nt.nodes.new('ShaderNodeTexCoord')
    nrm = nt.nodes.new('ShaderNodeVectorMath')
    nrm.operation = 'NORMALIZE'
    lk.new(tc.outputs['Object'], nrm.inputs[0])
    sep = nt.nodes.new('ShaderNodeSeparateXYZ')
    lk.new(nrm.outputs[0], sep.inputs[0])
    ac = nt.nodes.new('ShaderNodeMath')
    ac.operation = 'ARCCOSINE'
    lk.new(sep.outputs['Z'], ac.inputs[0])
    sc = nt.nodes.new('ShaderNodeMath')
    sc.operation = 'DIVIDE'
    sc.inputs[1].default_value = 1.6
    lk.new(ac.outputs[0], sc.inputs[0])
    k = 1.0 / 1.6
    pupil, iris = 0.60, 1.28
    dark = lin('#0a0605')
    stops = [(0.0, dark), (pupil * k, dark), (pupil * k + 0.02, lin(P['c_iris'])),
             (iris * k - 0.05, lin('#1a0f09')), (iris * k, lin('#0d0806')), (iris * k + 0.03, lin('#c9bcae')),
             (1.0, lin('#b5a79a'))]
    r = nt.nodes.new('ShaderNodeValToRGB')
    cr = r.color_ramp
    cr.elements[0].position, cr.elements[0].color = stops[0]
    cr.elements[1].position, cr.elements[1].color = stops[-1]
    for pos, c in stops[1:-1]:
        e = cr.elements.new(pos)
        e.color = c
    lk.new(sc.outputs[0], r.inputs['Fac'])
    lk.new(r.outputs['Color'], b.inputs['Base Color'])
    return m


def _lid_mesh(name, radius, a0, a1, mat, parent, na=18, nb=22):
    """A band of a sphere that turns about the eye's local X axis; its edge at angle 0 is the lash line."""
    verts, faces = [], []
    for i in range(na + 1):
        al = a0 + (a1 - a0) * i / na
        for j in range(nb + 1):
            be = -1.45 + 2.9 * j / nb
            verts.append((radius * math.sin(be), radius * math.cos(be) * math.sin(al),
                          radius * math.cos(be) * math.cos(al)))
    for i in range(na):
        for j in range(nb):
            q = i * (nb + 1) + j
            faces.append((q, q + 1, q + nb + 2, q + nb + 1))
    return mesh_obj(name, verts, faces, mat, parent, True, 0)


def _ray_hit(sdf, origin, target, reach=0.03):
    """First point where the ray from `origin` (inside) through `target` leaves the shape."""
    o = np.asarray(origin, dtype=np.float64)
    d = _norm(np.asarray(target, dtype=np.float64) - o)
    lo, hi = 0.0, reach
    for _ in range(30):
        mid = 0.5 * (lo + hi)
        if sdf((o + d * mid)[None, :])[0] < 0:
            lo = mid
        else:
            hi = mid
    return o + d * hi, d


class Hedgehog:
    """Handles to one built hedgehog. root: move and turn him. j: the pivots (empties). state: the current pose."""

    def __init__(self, name, design):
        self.name = name
        self.P = design
        self.root = None
        self.j = {}
        self.parts = {}
        self.rest = {}
        self.state = dict(REST)
        self.focus = None


# ------------------------------------------------------------------------------------------------ the build


def build_hedgehog(name='Little', design=None, scale=1.0, seed=7, fur=1.0, parent=None):
    """Builds one hedgehog into the current scene, standing at the origin, facing -Y. Returns a Hedgehog.

    design: LITTLE (default) or MAMA, or your own copy with changed numbers.
    scale:  1.0 = Little (about 15 cm long). Use 1.5 for Mama.
    fur:    multiplies the number of fur strands (1.0 = about 97,000; 0.5 is fine for wide shots).
    """
    P = dict(LITTLE)
    P.update(design or {})
    rng = np.random.default_rng(seed)
    h = Hedgehog(name, P)
    n_ = name + '.'

    # ---- materials
    m_skin = _attr_mat(n_ + 'skin', rough=0.75, sheen=0.4, spec=0.2)
    m_fur = _attr_mat(n_ + 'fur', rough=0.62, sheen=0.55, spec=0.22)
    m_spine = _attr_mat(n_ + 'spine', rough=0.40, spec=0.45, coat=0.25, coat_rough=0.25)
    m_eye = _eye_material(n_ + 'eye', P)
    m_lid = principled(n_ + 'lid', P['c_lid'], rough=0.8, sheen=0.25, spec=0.15)
    m_lash = principled(n_ + 'lash', P['c_lash'], rough=0.5, spec=0.2)
    m_nose = principled(n_ + 'nose', P['c_nose'], rough=0.22, coat=1.0, coat_rough=0.08, spec=0.6)
    m_paw = principled(n_ + 'paw', P['c_paw'], rough=0.6, sheen=0.35, spec=0.3)
    m_ear = principled(n_ + 'ear', P['c_ear'], rough=0.6, sheen=0.6, sss=0.35, sss_radius=(1.0, 0.35, 0.2),
                       sss_scale=0.004, spec=0.25)
    m_ear_in = principled(n_ + 'ear_in', P['c_ear_in'], rough=0.55, sheen=0.3, sss=0.5, sss_radius=(1.0, 0.3, 0.2),
                          sss_scale=0.004, spec=0.25)
    m_mouth = principled(n_ + 'mouth', P['c_mouth'], rough=0.6, spec=0.2)

    # ---- pivots
    root = empty(n_ + 'root', (0, 0, 0), parent, 0.06)
    hips = empty(n_ + 'hips', tuple(HIPS), root, 0.03)
    neck = empty(n_ + 'neck', tuple(NECK - HIPS), hips, 0.03)
    h.root = root
    h.j.update(hips=hips, neck=neck)

    b_sdf = body_sdf(P)
    h_sdf0 = head_sdf(P, False)
    # set the eyes into the face: find the skin in front of eye_c and sink the ball until only eye_pop stands out
    e0 = np.array(P['eye_c'])
    skin, _ = _ray_hit(h_sdf0, e0, e0 + _grad(h_sdf0, e0[None, :])[0], 0.03)
    eye_n = _grad(h_sdf0, skin[None, :])[0]
    P['eye_c'] = tuple(skin - eye_n * (P['eye_r'] - P['eye_pop']))
    h_sdf = head_sdf(P, True)
    under = _rgb(P['c_under'])

    # ---- body skin
    dirs5, faces5 = lib.icosphere_dirs(6)
    b_ctr = np.array(P['body_c']) + np.array([0.0, 0.0, -0.002])
    b_pts = lib.march(b_sdf, b_ctr, dirs5, 0.085, 170)
    body = mesh_obj(n_ + 'body', b_pts - HIPS, faces5, m_skin, hips, True, 1)
    w = _ss(-0.003, 0.003, b_pts[:, 2] - _flank_line(b_pts[:, 1]))
    _paint(body, _mix(_body_colour(P, b_pts), under, w))
    h.parts['body'] = body

    # ---- body spines: swept back in one flow, like combed hair
    p, n = _on_surface(b_sdf, _sample_tris(b_pts, faces5, 90000, rng))
    over = p[:, 2] - _flank_line(p[:, 1])
    ok = (over > 0.001) & (h_sdf0(p) > 0.0005)
    p, n, over = p[ok], n[ok], over[ok]
    keep = _thin(p, P['spine_gap'])
    keep = keep[rng.permutation(len(keep))[:P['spines_body']]]
    p, n, over = p[keep], n[keep], over[keep]
    d = _norm(0.62 * n + 0.75 * np.array([0.0, 1.0, 0.10]) + rng.normal(0.0, 0.09, p.shape))
    ln = P['spine_len'] * (0.72 + 0.28 * _ss(0.0, 0.020, over)) * rng.uniform(0.9, 1.15, len(p))
    rd = P['spine_rad'] * rng.uniform(0.9, 1.1, len(p))
    var = rng.uniform(0.84, 1.16, len(p))
    h.parts['body_spines'] = _spine_object(n_ + 'body_spines', p - n * 0.0015 - HIPS, d, ln, rd, var,
                                           P['spine_ramp'], m_spine, hips)

    # ---- body fur: white chest and belly, a longer cream skirt where it meets the spines
    cnt = int(P['fur_body'] * fur)
    p, n = _on_surface(b_sdf, _sample_tris(b_pts, faces5, int(cnt * 3.2), rng))
    over = p[:, 2] - _flank_line(p[:, 1])
    ok = (over < 0.005) & (h_sdf0(p) > -0.006)
    p, n, over = p[ok][:cnt], n[ok][:cnt], over[ok][:cnt]
    skirt = _ss(-0.012, 0.004, over)
    bib = _ss(0.012, -0.012, p[:, 1]) * _ss(0.040, 0.022, np.abs(p[:, 0]))
    col = _mix(_body_colour(P, p), _rgb(P['c_fringe']), 0.50 * skirt ** 2 * (1.0 - bib))
    chest = _ss(-0.005, -0.030, p[:, 1]) * _ss(0.012, 0.022, p[:, 2])
    ln = (0.0090 + 0.0045 * skirt + 0.0030 * chest) * rng.uniform(0.75, 1.25, len(p))
    flow = np.array([0.0, 0.35, -1.0])
    comb = _norm(flow[None, :] - n * (n @ flow)[:, None])
    pts = _strands(p, n, comb, ln, 0.85 + 0.3 * skirt, rng, bend=0.45, grav=0.22, jitter=0.24)
    h.parts['body_fur'] = _fur_object(n_ + 'body_fur', pts - HIPS, col, 0.00017, 0.00005, m_fur, hips, rng)

    # ---- tail: a tiny nub, for the back view
    h.parts['tail'] = ellipsoid(n_ + 'tail', 0.0045, 0.0080, 0.0045, m_paw, hips,
                                tuple(np.array([0.0, P['body_c'][1] + P['body_r'][1] - 0.001, 0.019]) - HIPS), 16, 1)

    # ---- head skin (the eye sockets are carved, so the eyes sit IN the face, not on it)
    dirs6, faces6 = lib.icosphere_dirs(7)
    h_pts = lib.march(h_sdf, np.array(P['head_c']), dirs6, 0.075, 220)
    head = mesh_obj(n_ + 'head', h_pts - NECK, faces6, m_skin, neck, True, 0)
    z = _head_zone(P, h_pts)
    col, _, _ = _head_fields(P, h_pts, z)
    _paint(head, _mix(under[None, :].repeat(len(h_pts), 0), col, _ss(0.10, 0.35, z['m'])))
    h.parts['head'] = head

    # ---- head spines: the hood. Shorter at the hairline so the face stays clean, longer behind.
    p, n = _on_surface(h_sdf0, _sample_tris(h_pts, faces6, 50000, rng))
    z = _head_zone(P, p)
    ok = (z['m'] < 0.30) & (b_sdf(p) > -0.004)
    p, n, m = p[ok], n[ok], z['m'][ok]
    keep = _thin(p, P['spine_gap'])
    keep = keep[rng.permutation(len(keep))[:P['spines_head']]]
    p, n, m = p[keep], n[keep], m[keep]
    d = _norm(0.85 * n + 0.55 * np.array([0.0, 0.8, 0.45]) + rng.normal(0.0, 0.09, p.shape))
    ln = P['spine_len'] * (0.60 + 0.34 * (1.0 - m / 0.30)) * rng.uniform(0.9, 1.12, len(p))
    rd = P['spine_rad'] * rng.uniform(0.85, 1.05, len(p))
    var = rng.uniform(0.86, 1.18, len(p))
    h.parts['head_spines'] = _spine_object(n_ + 'head_spines', p - n * 0.0015 - NECK, d, ln, rd, var,
                                           P['spine_ramp'], m_spine, neck)

    # ---- the cowlick: a few longer spines standing up at the peak of the hairline (on its own pivot: it can bounce)
    f_ax = _norm(np.array([0.0, -1.0, -0.25]))
    up_ax = _norm(np.array([0.0, -0.25, 1.0]))
    th = P['mask_side'] - P['mask_peak'] + 0.10
    peak, _ = _ray_hit(h_sdf0, P['head_c'], np.array(P['head_c']) + math.cos(th) * f_ax + math.sin(th) * up_ax, 0.07)
    cow = empty(n_ + 'cowlick', tuple(peak - NECK), neck, 0.01)
    h.j['cowlick'] = cow
    if P['cowlick'] > 0:
        k = P['cowlick']
        off = np.stack([rng.uniform(-0.0045, 0.0045, k), rng.uniform(0.0, 0.006, k), np.zeros(k)], axis=1)
        d = _norm(np.array([0.0, -0.40, 1.0]) + np.stack([off[:, 0] * 55.0, rng.uniform(-0.15, 0.25, k),
                                                           np.zeros(k)], axis=1))
        ln = P['spine_len'] * rng.uniform(1.45, 1.95, k)
        rd = P['spine_rad'] * rng.uniform(1.15, 1.35, k)
        h.parts['cowlick'] = _spine_object(n_ + 'cowlick_spines', off - np.array([0.0, 0.0, 0.002]), d, ln, rd,
                                           rng.uniform(1.1, 1.3, k), P['spine_ramp'], m_spine, cow)

    # ---- face fur: short and sleek, flowing away from the nose; fluffier on the cheeks and at the hairline
    cnt = int(P['fur_head'] * fur)
    p, n = _on_surface(h_sdf0, _sample_tris(h_pts, faces6, int(cnt * 2.6), rng))
    z = _head_zone(P, p)
    nose_c = _nose_c(P)
    in_nose = np.linalg.norm((p - nose_c) / np.array(P['nose_r']), axis=1) < 0.92
    ok = (z['m'] > 0.10) & (z['d_eye'] > 1.14) & ~in_nose & (b_sdf(p) > -0.006)
    p, n = p[ok][:cnt], n[ok][:cnt]
    z = _head_zone(P, p)
    col, ln, lift = _head_fields(P, p, z)
    ln = ln * rng.uniform(0.75, 1.25, len(p))
    v = p - nose_c
    comb = v - n * np.sum(v * n, axis=1, keepdims=True)
    e = p - z['eye']
    e = e - n * np.sum(e * n, axis=1, keepdims=True)
    comb = _norm(_norm(comb) + _norm(e) * (1.6 * _ss(2.1, 1.14, z['d_eye']))[:, None])
    pts = _strands(p, n, comb, ln, lift, rng, bend=0.55, grav=0.10, jitter=0.18)
    h.parts['head_fur'] = _fur_object(n_ + 'head_fur', pts - NECK, col, 0.00015, 0.00004, m_fur, neck, rng)

    # ---- eyes: a ball in its socket, an upper and a lower lid, a fine lash line
    r_eye = P['eye_r']
    for s, tag in ((1, 'L'), (-1, 'R')):
        c = np.array([s * P['eye_c'][0], P['eye_c'][1], P['eye_c'][2]])
        gaze = _norm(0.6 * np.array([s * eye_n[0], eye_n[1], eye_n[2]]) + 0.4 * np.array([s * 0.10, -1.0, 0.05]))
        ax = _norm(np.cross(np.array([0.0, 0.0, 1.0]), gaze))
        ay = np.cross(gaze, ax)
        piv = empty(n_ + 'eye.' + tag, tuple(c - NECK), neck, 0.006, rot=_axes_euler(ax, ay, gaze))
        ball = ellipsoid(n_ + 'eyeball.' + tag, r_eye, r_eye, r_eye, m_eye, piv, (0, 0, 0), 40, 1)
        lu = empty(n_ + 'lidU.' + tag, (0, 0, 0), piv, 0.004)
        ld = empty(n_ + 'lidD.' + tag, (0, 0, 0), piv, 0.004)
        _lid_mesh(n_ + 'lidU.mesh.' + tag, r_eye * 1.05, 0.0, 2.3, m_lid, lu)
        _lid_mesh(n_ + 'lidD.mesh.' + tag, r_eye * 1.045, -2.3, 0.0, m_lid, ld)
        rr = r_eye * 1.065
        lash = [(rr * math.sin(-1.3 + 2.6 * i / 24), 0.0, rr * math.cos(-1.3 + 2.6 * i / 24)) for i in range(25)]
        tube_path(n_ + 'lash.' + tag, lash, 0.00042, m_lash, lu, 6, True, 0)
        h.j.update({'eye' + tag: ball, 'lidU' + tag: lu, 'lidD' + tag: ld})

    # ---- nose: an oversized glossy button on its own pivot (it twitches)
    nose_piv = empty(n_ + 'nose', tuple(np.array(P['tip_c']) - NECK), neck, 0.006)
    nr = P['nose_r']
    h.parts['nose'] = ellipsoid(n_ + 'nose.mesh', nr[0], nr[1], nr[2], m_nose, nose_piv,
                                tuple(nose_c - np.array(P['tip_c'])), 32, 2)
    h.j['nose'] = nose_piv

    # ---- mouth: one small smile line under the nose that curls up along the snout (never opens: no teeth)
    def lip(s, t):
        y0 = P['tip_c'][1] - P['tip_r'][1] * 0.70
        y1 = P['tip_c'][1] + 0.0045
        y = y0 + (y1 - y0) * t
        u = min(1.0, max(0.0, (P['snout_c'][1] - y) / (P['snout_c'][1] - P['tip_c'][1])))
        zc = P['snout_c'][2] + (P['tip_c'][2] - P['snout_c'][2]) * u          # the snout's own axis
        ph = 1.30 * t ** 0.75                                                # 0 = under the snout, up its side
        hit, d = _ray_hit(h_sdf0, (0.0, y, zc), (s * math.sin(ph), y, zc - math.cos(ph)))
        return hit + d * 0.00035
    ts = np.linspace(0.0, 1.0, 8)
    lip_pts = [lip(-1, t) for t in ts[::-1]] + [lip(1, t) for t in ts[1:]]
    lip_r = [0.00028 + 0.00030 * (1.0 - abs(i - 7) / 7.0) for i in range(15)]
    h.parts['mouth'] = tube_path(n_ + 'mouth', [q - NECK for q in lip_pts], lip_r, m_mouth, neck, 6, True, 1)

    # ---- ears: two small round shells at the hairline; the light glows through them
    er = P['ear_r']
    for s, tag in ((1, 'L'), (-1, 'R')):
        u = _norm(np.array([s * 0.74, -0.42, 0.52]))
        base, _ = _ray_hit(h_sdf0, P['head_c'], np.array(P['head_c']) + u, 0.07)
        az = _norm(u + np.array([s * 0.10, 0.05, 0.30]))
        fwd = np.array([s * 0.35, -0.94, 0.0])
        ay = -_norm(fwd - az * (fwd @ az))
        ax = np.cross(ay, az)
        piv = empty(n_ + 'ear.rest.' + tag, tuple(base - az * 0.002 - NECK), neck, 0.006, rot=_axes_euler(ax, ay, az))
        flick = empty(n_ + 'ear.' + tag, (0, 0, 0), piv, 0.004)
        ellipsoid(n_ + 'ear.mesh.' + tag, er, er * 0.30, er * 1.10, m_ear, flick, (0, 0, er * 0.80), 24, 1)
        ellipsoid(n_ + 'ear.in.' + tag, er * 0.62, er * 0.14, er * 0.74, m_ear_in, flick,
                  (0, -er * 0.28, er * 0.82), 24, 1)
        # soft fuzz on the rim and the back, so the ear belongs to the furry head
        dv = _norm(rng.normal(size=(int(2600 * fur), 3)))
        rad3 = np.array([er, er * 0.30, er * 1.10])
        nn = _norm(dv / rad3)
        pp = dv * rad3 + np.array([0.0, 0.0, er * 0.80])
        keep = (nn[:, 1] > -0.45) & (pp[:, 2] > er * 0.25)
        pp, nn = pp[keep], nn[keep]
        up3 = np.array([0.0, 0.0, 1.0])
        comb = _norm(up3[None, :] - nn * (nn @ up3)[:, None] + 1e-6)
        fz = _strands(pp, nn, comb, 0.0024 * rng.uniform(0.7, 1.3, len(pp)), np.full(len(pp), 0.9), rng,
                      bend=0.3, grav=0.0, jitter=0.25)
        _fur_object(n_ + 'ear.fuzz.' + tag, fz, np.tile(np.clip(_rgb(P['c_ear']) * 1.3, 0, 1), (len(pp), 1)),
                    0.00014, 0.00004, m_fur, flick, rng)
        h.j['ear' + tag] = flick

    # ---- front legs: stubby, on shoulder pivots, ending in tiny dark mitts with three toes
    for s, tag in ((1, 'L'), (-1, 'R')):
        sh = np.array([s * 0.023, -0.022, 0.024])
        piv = empty(n_ + 'paw.' + tag, tuple(sh - HIPS), hips, 0.006)
        lathe(n_ + 'leg.' + tag, capsule_profile(0.0165, 0.0074, 0.0062), m_paw, piv, 16, 1.0, 1.0, 1, (0, 0, 0), True)
        ellipsoid(n_ + 'paw.mesh.' + tag, 0.0072, 0.0092, 0.0045, m_paw, piv, (0, -0.0035, -0.0195), 20, 1)
        for i, dx in enumerate((-0.0044, 0.0, 0.0044)):
            ellipsoid(n_ + f'toe.{tag}{i}', 0.0025, 0.0030, 0.0024, m_paw, piv,
                      (dx, -0.0118 + 0.0012 * abs(i - 1), -0.0208), 10, 1)
        h.j['paw' + tag] = piv

    # ---- hind feet: flat little feet that stay on the ground when he sits up
    for s, tag in ((1, 'L'), (-1, 'R')):
        heel = (s * 0.030, 0.009, 0.0040)
        piv = empty(n_ + 'foot.' + tag, heel, root, 0.006, rot=(0.0, 0.0, s * 0.35))
        ellipsoid(n_ + 'foot.mesh.' + tag, 0.0075, 0.0130, 0.0042, m_paw, piv, (0, -0.010, 0.0005), 20, 1)
        for i, dx in enumerate((-0.0046, 0.0, 0.0046)):
            ellipsoid(n_ + f'ftoe.{tag}{i}', 0.0026, 0.0032, 0.0025, m_paw, piv,
                      (dx, -0.0222 + 0.0013 * abs(i - 1), 0.0002), 10, 1)
        h.j['foot' + tag] = piv
        h.rest['foot' + tag] = heel

    # ---- a point between the eyes for the camera to focus on
    h.focus = empty(n_ + 'focus', tuple(np.array([0.0, P['eye_c'][1] - 0.006, P['eye_c'][2]]) - NECK), neck, 0.004)

    root.scale = (scale, scale, scale)
    pose(h)
    return h


# ------------------------------------------------------------------------------------------------ posing


def pose(h, frame=None, **kw):
    """Sets (and with frame=N also keys) the controls. Values not given keep their current state.

    body_pitch  sit up (52 = sitting on his bottom), body_roll, body_yaw, lift (m), squash (1 = none; 0.9 = squashed,
                1.1 = stretched; volume is kept)
    head_pitch, head_yaw, head_roll, head_tuck (m: pulls the head into the body, for curling up), nose (twitch up)
    blink 0..1, happy 0..1 (where the lids meet: 0 = sleepy low line, 1 = happy arch), smile 0..1 (lower lids rise)
    look_yaw, look_pitch (eyes), paw_l, paw_r (front legs swing forward), ear_l, ear_r (flick back), cowlick (tips back)
    feet_pitch (toes up), feet_fwd (m: hind feet slide forward, for sitting)
    """
    v = dict(h.state)
    v.update(kw)
    h.state = v
    r = math.radians
    j = h.j
    j['hips'].location = (HIPS[0], HIPS[1], HIPS[2] + v['lift'])
    j['hips'].rotation_euler = (-r(v['body_pitch']), r(v['body_roll']), r(v['body_yaw']))
    sq = max(0.3, v['squash'])
    j['hips'].scale = (sq ** -0.5, sq ** -0.5, sq)
    rel = NECK - HIPS
    j['neck'].location = (rel[0], rel[1] + v['head_tuck'], rel[2] - 0.35 * v['head_tuck'])
    j['neck'].rotation_euler = (-r(v['head_pitch']), r(v['head_roll']), r(v['head_yaw']))
    j['nose'].rotation_euler = (-r(v['nose']), 0.0, 0.0)
    j['cowlick'].rotation_euler = (-r(v['cowlick']), 0.0, 0.0)
    close = -0.18 + 0.48 * v['happy']                    # where the lids meet (radians above the gaze line)
    up_open, low_open = 0.74, -0.95 + 0.25 * v['smile']
    e_up = up_open + (close - up_open) * v['blink']
    e_low = low_open + (close - low_open) * v['blink']
    for tag in ('L', 'R'):
        j['lidU' + tag].rotation_euler = (-e_up, 0.0, 0.0)
        j['lidD' + tag].rotation_euler = (-e_low, 0.0, 0.0)
        j['eye' + tag].rotation_euler = (-r(v['look_pitch']), r(v['look_yaw']), 0.0)
    j['pawL'].rotation_euler = (-r(v['paw_l']), 0.0, 0.0)
    j['pawR'].rotation_euler = (-r(v['paw_r']), 0.0, 0.0)
    j['earL'].rotation_euler = (-r(v['ear_l']), 0.0, 0.0)
    j['earR'].rotation_euler = (-r(v['ear_r']), 0.0, 0.0)
    for s, tag in ((1, 'L'), (-1, 'R')):
        heel = h.rest['foot' + tag]
        j['foot' + tag].location = (heel[0], heel[1] - v['feet_fwd'], heel[2] + 0.004 * math.sin(r(v['feet_pitch'])))
        j['foot' + tag].rotation_euler = (-r(v['feet_pitch']), 0.0, s * 0.35)
    if frame is not None:
        for o in j.values():
            o.keyframe_insert('rotation_euler', frame=frame)
        for k in ('hips', 'neck', 'footL', 'footR'):
            j[k].keyframe_insert('location', frame=frame)
        j['hips'].keyframe_insert('scale', frame=frame)
    return v
