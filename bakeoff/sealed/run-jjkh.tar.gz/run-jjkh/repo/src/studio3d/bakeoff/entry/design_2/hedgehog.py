"""Little Hedgehog, design proposal 2: materials and light first.

Everything is made in code (Blender 5.2, Cycles): two soft solids shaped by distance functions (body, head), real
strands for the fur (Principled Hair, so low sun passes through the pale fur and rims it), banded quills as wide
strands with a translucent share (cream root, brown band, pale tip: they glow amber against the light), ears with
strong subsurface scattering (they light up red-orange in front of the sun), wet nose, glossy dark eyes with lids.

How to use it from a film:

    import hedgehog                      # this file's folder must be on sys.path
    rig = hedgehog.build_hedgehog()      # builds Little Hedgehog into the current scene, standing at the origin
    hedgehog.pose(rig, **hedgehog.CURL)                       # a still pose
    hedgehog.pose(rig, frame=205, **hedgehog.STAND)           # the same, keyed at film frame 205
    hedgehog.pose(rig, frame=230, **hedgehog.mix_pose(hedgehog.STAND, hedgehog.SNIFF, 0.6))

The character is a tree of rigid parts (root > body > head > eyes, lids, ears, nose; four hips under the body). The
fur and the quills are children of the body and the head, so every pose is plain object transforms: no simulation,
no frame depends on an earlier one. He faces -Y, stands on z = 0, and is about 16 cm long at scale 1.
`rig.focus` is an empty between the eyes (use it as the camera's focus object), `rig.nose` is the nose.

Measured on this machine (4 cores, Cycles, the patch of garden.py around him, 1280x720):
  building him: about 1 second.
  medium shot: 64 s at 32 samples, 26 s at 12 samples. Face close-up: 90 s at 32 samples.
  curled up with round quills (scene.cycles_curves.shape = 'THICK'): 100 s at 32 samples.
  the grass was about a sixth of a medium shot; he and the soil are the rest.
So a film at about 26 s a picture needs fewer samples and probably fewer strands than these stills
(n_face, n_coat in the spec; 82,000 strands here).

What to know before animating him:
  - Seen from above, open eyelids slant inward and read stern. Add lid_tilt=20..25 (CURL does) for high cameras.
  - Quills are flat ribbons by default: fine from the side, thin when they point at the lens. Use 'THICK' there.
  - The mouth is a fixed small smile (no open mouth, no teeth): giggles are played with body, eyes and nose.
  - Parts are rigid: squash and stretch is body scale; the head turns about 25 degrees each way before the hood
    quills of head and body visibly cross.
  - MAMA was only test-drawn once at 640x360 (it builds and reads as a bigger, longer-nosed, darker hedgehog).
  - ASLEEP (closed lids) was not test-drawn. cheap_fur=True is not worth using as it is (see fur_material).
"""
import math
import os
import sys

import bpy
import numpy as np
from mathutils import kdtree

HERE = os.path.dirname(os.path.abspath(__file__))
_BL = os.path.abspath(os.path.join(HERE, '..', '..', '..', 'blender'))
if _BL not in sys.path:
    sys.path.insert(0, _BL)
import lib  # noqa: E402
from lib import lin  # noqa: E402

# ---------------------------------------------------------------------------------------------- the two hedgehogs

LITTLE = dict(
    name='Little', scale=1.0, seed=7,
    face='#e8d2b0', chest='#f2e6cf', spine='#7a5a3e', paw='#5a3a2a',   # the colours of the story's cast sheet
    fur_warmth=0.55,                   # pale hair renders cooler than its swatch in blue shade: deepen it a little
    body_r=(0.047, 0.060, 0.043),      # half width, half length, half height of the body (metres at scale 1)
    snout=1.0,                         # snout length factor
    eye_r=0.0098,
    n_face=42000, n_coat=40000, n_spines=5600, n_crown=2000,
    spine_len=0.019,
)
# Mama: bigger, rounder, darker quills, longer nose, smaller eyes. Same builder; NOT test-rendered in this proposal.
MAMA = dict(LITTLE, name='Mama', scale=1.5, seed=11, face='#e2c8a4', spine='#6a4a32', paw='#4a3020',
            body_r=(0.050, 0.061, 0.046), snout=1.28, eye_r=0.0080, spine_len=0.017)

SKULL_C = np.array([0.0, -0.020, 0.0])     # skull centre in the head's frame
SKULL_R = 0.034
NECK = np.array([0.0, -0.022, -0.004])     # the head joint in the body's frame
BODY_C = (0.0, 0.012, 0.050)               # body centre above the ground when standing
EYE = (0.0173, -0.0428, 0.0049)            # left eye centre in the head's frame (x is mirrored for the right)
EAR_DIR = (0.74, -0.34, 0.58)             # where the left ear sits, as a direction from the skull centre
EAR_UP = (0.50, -0.05, 0.86)
HIPS = {'FL': (0.026, -0.030, -0.027), 'FR': (-0.026, -0.030, -0.027),
        'HL': (0.031, 0.032, -0.027), 'HR': (-0.031, 0.032, -0.027)}

# ---------------------------------------------------------------------------------------------- small helpers


def _ss(a, b, x):
    t = np.clip((np.asarray(x, dtype=np.float64) - a) / (b - a), 0.0, 1.0)
    return t * t * (3 - 2 * t)


def _unit(v):
    v = np.asarray(v, dtype=np.float64)
    return v / np.maximum(np.linalg.norm(v, axis=-1, keepdims=True), 1e-12)


def _rgb(h):
    return np.array(lin(h)[:3])


def _mixc(a, b, t):
    t = np.asarray(t, dtype=np.float64)
    if t.ndim:
        t = t[:, None]
    return np.asarray(a) * (1 - t) + np.asarray(b) * t


def _c4(c):
    c = tuple(float(x) for x in c)
    return c if len(c) == 4 else (c[0], c[1], c[2], 1.0)


def _normals(sdf, p, e=2e-4):
    g = np.empty_like(p)
    for i in range(3):
        d = np.zeros(3)
        d[i] = e
        g[:, i] = sdf(p + d) - sdf(p - d)
    return _unit(g)


def _sample(verts, faces, n, rng):
    """n random points on a triangle mesh, even by area."""
    a, b, c = verts[faces[:, 0]], verts[faces[:, 1]], verts[faces[:, 2]]
    area = np.linalg.norm(np.cross(b - a, c - a), axis=1)
    idx = rng.choice(len(faces), size=n, p=area / area.sum())
    u, v = rng.random(n), rng.random(n)
    flip = u + v > 1
    u[flip], v[flip] = 1 - u[flip], 1 - v[flip]
    return a[idx] + (b[idx] - a[idx]) * u[:, None] + (c[idx] - a[idx]) * v[:, None]


def _project(sdf, center, pts, rmax=0.075):
    """Push points onto the surface along the ray from the solid's centre."""
    d = _unit(np.asarray(pts, dtype=np.float64) - center)
    return lib.march(sdf, center, d, rmax=rmax, steps=90, iters=18)


def _ray(sdf, origin, direction, rmax=0.03):
    """The surface point reached from a point inside the solid along a direction."""
    d = _unit(np.asarray([direction], dtype=np.float64))
    return lib.march(sdf, np.asarray(origin, dtype=np.float64), d, rmax=rmax, steps=120, iters=18)[0]


def _poly_dist(p, poly):
    d = np.full(len(p), 1e9)
    for a, b in zip(poly[:-1], poly[1:]):
        ab = b - a
        t = np.clip(((p - a) @ ab) / max(ab.dot(ab), 1e-12), 0, 1)
        d = np.minimum(d, np.linalg.norm(p - (a + t[:, None] * ab), axis=1))
    return d


def _strands(roots, d0, d1, length, k):
    """Strands that leave the skin along d0 and bend toward d1. Returns (n, k, 3)."""
    t = np.linspace(0, 1, k)[None, :, None]
    L = np.asarray(length)[:, None, None]
    return roots[:, None, :] + L * (d0[:, None, :] * t + 0.5 * (d1 - d0)[:, None, :] * t * t)


def _clump(pts, rng, every=14, pull=0.38):
    """Gentle clumps: every strand leans its tip toward a nearby leader strand."""
    n, k = pts.shape[0], pts.shape[1]
    m = max(1, n // every)
    lead = rng.choice(n, size=m, replace=False)
    kd = kdtree.KDTree(m)
    roots = pts[:, 0].tolist()
    for i, j in enumerate(lead.tolist()):
        kd.insert(roots[j], i)
    kd.balance()
    near = np.fromiter((kd.find(r)[1] for r in roots), dtype=np.int64, count=n)
    tgt = pts[lead[near]]
    w = (np.linspace(0, 1, k) ** 2)[None, :, None] * pull * rng.uniform(0.45, 1.0, (n, 1, 1))
    return pts + (tgt - pts) * w


def _curves(name, pts, r_root, r_tip, mat, parent, col=None, rnd=None, shape=1.0):
    """A Curves object from (n, k, 3) points; per-strand colour 'col' and random 'rnd' for the shaders."""
    n, k = pts.shape[0], pts.shape[1]
    hc = bpy.data.hair_curves.new(name)
    hc.add_curves([k] * n)
    hc.position_data.foreach_set('vector', np.ascontiguousarray(pts, dtype=np.float32).ravel())
    t = np.linspace(0, 1, k) ** shape
    r_root = np.broadcast_to(np.asarray(r_root, dtype=np.float64), (n,))
    rad = r_root[:, None] * (1 - t)[None, :] + r_tip * t[None, :]
    a = hc.attributes.get('radius') or hc.attributes.new('radius', 'FLOAT', 'POINT')
    a.data.foreach_set('value', np.ascontiguousarray(rad, dtype=np.float32).ravel())
    if col is not None:
        c = hc.attributes.new('col', 'FLOAT_COLOR', 'CURVE')
        c4 = np.concatenate([col, np.ones((n, 1))], axis=1)
        c.data.foreach_set('color', np.ascontiguousarray(c4, dtype=np.float32).ravel())
    if rnd is not None:
        r = hc.attributes.new('rnd', 'FLOAT', 'CURVE')
        r.data.foreach_set('value', np.ascontiguousarray(rnd, dtype=np.float32))
    hc.materials.append(mat)
    o = bpy.data.objects.new(name, hc)
    lib.link(o)
    o.parent = parent
    return o


# ---------------------------------------------------------------------------------------------- shapes


def _head_sdf(sp):
    k = sp['snout']

    def f(p):
        d = lib.sd_sphere(p, SKULL_C, SKULL_R)
        d = lib.smin(d, lib.sd_ellipsoid(p, (0, -0.046, -0.0070), (0.0190, 0.0200, 0.0165)), 0.014)
        d = lib.smin(d, lib.sd_sphere(p, (0, -0.046 - 0.0140 * k, -0.0060), 0.0125), 0.012)
        d = lib.smin(d, lib.sd_sphere(p, (0, -0.046 - 0.0235 * k, -0.0035), 0.0088), 0.010)
        for s in (-1, 1):
            d = lib.smin(d, lib.sd_sphere(p, (s * 0.0215, -0.034, -0.0150), 0.0150), 0.012)
        return d
    return f


def _body_sdf(sp):
    rx, ry, rz = sp['body_r']

    def f(p):
        d = lib.sd_ellipsoid(p, (0, 0, 0), (rx, ry, rz))
        d = lib.smin(d, lib.sd_ellipsoid(p, (0, 0.33 * ry, -0.07 * rz), (0.98 * rx, 0.70 * ry, 0.93 * rz)), 0.02)
        d = lib.smin(d, lib.sd_ellipsoid(p, (0, -0.50 * ry, -0.23 * rz), (0.77 * rx, 0.50 * ry, 0.70 * rz)), 0.02)
        return lib.smax(d, -(p[..., 2] + 0.93 * rz), 0.012)
    return f


def _skirt(sp, p):
    """> 0 where quills grow on the body, < 0 where fur grows (the line rises toward the face)."""
    _, ry, rz = sp['body_r']
    u = p[:, 1] / ry
    w = p[:, 2] / rz
    return w - (-0.38 + 0.50 * np.clip(-u, 0, 1) ** 1.4), u


def _crown(p):
    """> 0 where the quills of the hood grow on the head: the top from the brow back, and down the sides
    behind the ears (so the face is framed by quills when he tucks his head in)."""
    n = _unit(p - SKULL_C)
    top = n[:, 2] - 0.72 + 0.9 * np.maximum(0.0, n[:, 1] + 0.35)
    back = 1.4 * (n[:, 1] + 0.22) + 0.25 * n[:, 2] - 0.27 - 1.2 * np.maximum(0.0, -0.2 - n[:, 2])
    return np.maximum(top, back)


def _mesh_from_sdf(name, sdf, center, level, rmax, mat, parent, subsurf=0):
    dirs, faces = lib.icosphere_dirs(level)
    pts = lib.march(sdf, np.asarray(center, dtype=np.float64), dirs, rmax=rmax, steps=72, iters=18)
    o = lib.mesh_obj(name, pts, faces, mat, parent, True, subsurf)
    return o, pts, np.asarray(faces, dtype=np.int64)


# ---------------------------------------------------------------------------------------------- materials


def _clear(m):
    m.use_nodes = True
    nt = m.node_tree
    for n in list(nt.nodes):
        if n.bl_idname != 'ShaderNodeOutputMaterial':
            nt.nodes.remove(n)
    outs = [n for n in nt.nodes if n.bl_idname == 'ShaderNodeOutputMaterial']
    return nt, (outs[0] if outs else nt.nodes.new('ShaderNodeOutputMaterial'))


def _ramp(nt, stops, interp='LINEAR'):
    r = nt.nodes.new('ShaderNodeValToRGB')
    cr = r.color_ramp
    cr.interpolation = interp
    cr.elements[0].position, cr.elements[0].color = stops[0][0], _c4(stops[0][1])
    cr.elements[1].position, cr.elements[1].color = stops[1][0], _c4(stops[1][1])
    for p, c in stops[2:]:
        e = cr.elements.new(p)
        e.color = _c4(c)
    return r


def _math(nt, op, a=None, b=None, c=None):
    n = nt.nodes.new('ShaderNodeMath')
    n.operation = op
    for i, v in enumerate((a, b, c)):
        if v is None:
            continue
        if isinstance(v, (int, float)):
            n.inputs[i].default_value = v
        else:
            nt.links.new(v, n.inputs[i])
    return n.outputs[0]


def _mixrgb(nt, blend, fac, c1, c2):
    n = nt.nodes.new('ShaderNodeMixRGB')
    n.blend_type = blend
    for i, v in enumerate((fac, c1, c2)):
        if isinstance(v, (int, float)):
            n.inputs[i].default_value = v
        elif isinstance(v, (tuple, list, np.ndarray)):
            n.inputs[i].default_value = _c4(v)
        else:
            nt.links.new(v, n.inputs[i])
    return n.outputs[0]


def fur_material(name, cheap=False):
    """Soft fur. Colour comes from the strand's 'col'; roots are darker. cheap=True swaps the hair shader for a
    Principled + Translucent mix. Measured once (medium shot, 12 samples): it saved no time and the pale face
    turned browner, so it is only a starting point; the hair shader is what the stills use."""
    m = bpy.data.materials.new(name)
    nt, out = _clear(m)
    at = nt.nodes.new('ShaderNodeAttribute')
    at.attribute_type = 'GEOMETRY'
    at.attribute_name = 'col'
    info = nt.nodes.new('ShaderNodeHairInfo')
    root = _ramp(nt, [(0.0, (0.50, 0.44, 0.38)), (0.65, (1, 1, 1))])
    nt.links.new(info.outputs['Intercept'], root.inputs[0])
    col = _mixrgb(nt, 'MULTIPLY', 1.0, at.outputs['Color'], root.outputs['Color'])
    if cheap:
        b = nt.nodes.new('ShaderNodeBsdfPrincipled')
        nt.links.new(col, b.inputs['Base Color'])
        b.inputs['Roughness'].default_value = 0.7
        b.inputs['Sheen Weight'].default_value = 0.6
        b.inputs['Sheen Roughness'].default_value = 0.4
        b.inputs['Specular IOR Level'].default_value = 0.2
        tr = nt.nodes.new('ShaderNodeBsdfTranslucent')
        nt.links.new(_mixrgb(nt, 'MULTIPLY', 1.0, col, (1.0, 0.86, 0.66)), tr.inputs['Color'])
        mx = nt.nodes.new('ShaderNodeMixShader')
        mx.inputs[0].default_value = 0.4
        nt.links.new(b.outputs[0], mx.inputs[1])
        nt.links.new(tr.outputs[0], mx.inputs[2])
        nt.links.new(mx.outputs[0], out.inputs['Surface'])
    else:
        h = nt.nodes.new('ShaderNodeBsdfHairPrincipled')
        h.parametrization = 'COLOR'
        nt.links.new(col, h.inputs['Color'])
        h.inputs['Roughness'].default_value = 0.42
        h.inputs['Radial Roughness'].default_value = 0.65
        h.inputs['Coat'].default_value = 0.0
        h.inputs['Random Roughness'].default_value = 0.25
        nt.links.new(h.outputs[0], out.inputs['Surface'])
    return m


def spine_material(name, spine_hex, glow=0.38):
    """Banded quill: cream root, brown band, pale tip. A translucent share lets low sun pass through the tips."""
    base = _rgb(spine_hex)
    cream = _rgb('#f3e3c0')
    m = bpy.data.materials.new(name)
    nt, out = _clear(m)
    info = nt.nodes.new('ShaderNodeHairInfo')
    at = nt.nodes.new('ShaderNodeAttribute')
    at.attribute_type = 'GEOMETRY'
    at.attribute_name = 'rnd'
    shift = _math(nt, 'MULTIPLY_ADD', at.outputs['Fac'], 0.12, -0.06)
    t = _math(nt, 'ADD', info.outputs['Intercept'], shift)
    band = _ramp(nt, [(0.0, _mixc(base, cream, 0.45)), (0.24, _mixc(base, cream, 0.55)), (0.38, base * 0.62),
                      (0.70, base * 0.70), (0.83, cream), (1.0, cream * 1.05)])
    nt.links.new(t, band.inputs[0])
    hsv = nt.nodes.new('ShaderNodeHueSaturation')
    nt.links.new(band.outputs['Color'], hsv.inputs['Color'])
    nt.links.new(_math(nt, 'MULTIPLY_ADD', at.outputs['Fac'], 0.40, 0.80), hsv.inputs['Value'])
    b = nt.nodes.new('ShaderNodeBsdfPrincipled')
    nt.links.new(hsv.outputs['Color'], b.inputs['Base Color'])
    b.inputs['Roughness'].default_value = 0.36
    b.inputs['Specular IOR Level'].default_value = 0.55
    tr = nt.nodes.new('ShaderNodeBsdfTranslucent')
    nt.links.new(_mixrgb(nt, 'MULTIPLY', 1.0, hsv.outputs['Color'], (1.0, 0.80, 0.52)), tr.inputs['Color'])
    mx = nt.nodes.new('ShaderNodeMixShader')
    mx.inputs[0].default_value = glow
    nt.links.new(b.outputs[0], mx.inputs[1])
    nt.links.new(tr.outputs[0], mx.inputs[2])
    nt.links.new(mx.outputs[0], out.inputs['Surface'])
    return m


def skin_material(name):
    """The skin under the fur; its colour is painted per vertex ('col') to match what grows on it."""
    m = lib.principled(name, '#e8d2b0', rough=0.65, sss=0.2, sss_radius=(1.0, 0.45, 0.3), sss_scale=0.004,
                       sheen=0.4, sheen_rough=0.5, spec=0.25)
    nt = m.node_tree
    at = nt.nodes.new('ShaderNodeAttribute')
    at.attribute_type = 'GEOMETRY'
    at.attribute_name = 'col'
    nt.links.new(at.outputs['Color'], nt.nodes['Principled BSDF'].inputs['Base Color'])
    return m


def eye_material(name):
    """A big dark glossy eye. The eyeball's local -Y is the gaze: pupil, warm brown iris (lighter in its lower
    half, which reads as depth), a dark edge, a soft off-white beyond. A clear coat gives the wet catchlight.
    Nothing here gives off light."""
    m = lib.principled(name, '#000000', rough=0.22, coat=1.0, coat_rough=0.025, spec=0.5)
    nt = m.node_tree
    b = nt.nodes['Principled BSDF']
    tc = nt.nodes.new('ShaderNodeTexCoord')
    nrm = nt.nodes.new('ShaderNodeVectorMath')
    nrm.operation = 'NORMALIZE'
    nt.links.new(tc.outputs['Object'], nrm.inputs[0])
    sep = nt.nodes.new('ShaderNodeSeparateXYZ')
    nt.links.new(nrm.outputs[0], sep.inputs[0])
    ang = _math(nt, 'ARCCOSINE', _math(nt, 'MULTIPLY', sep.outputs['Y'], -1.0))
    f = _math(nt, 'DIVIDE', ang, 1.6)
    k = 1 / 1.6
    pa, ia = 0.60, 1.05
    pupil = (0.004, 0.003, 0.003)
    disc = _ramp(nt, [(0.0, pupil), (pa * k, pupil), (pa * k + 0.02, _rgb('#2c190f')), (ia * k - 0.07, _rgb('#4d2e19')),
                      (ia * k - 0.012, (0.012, 0.008, 0.006)), (ia * k + 0.014, _rgb('#b9ab98')), (1.0, _rgb('#a59684'))])
    nt.links.new(f, disc.inputs[0])
    ring = _ramp(nt, [(0.0, (0, 0, 0)), (pa * k, (0, 0, 0)), (pa * k + 0.035, (1, 1, 1)), (ia * k - 0.05, (1, 1, 1)),
                      (ia * k - 0.01, (0, 0, 0))])
    nt.links.new(f, ring.inputs[0])
    low = nt.nodes.new('ShaderNodeMapRange')
    nt.links.new(sep.outputs['Z'], low.inputs[0])
    low.inputs[1].default_value, low.inputs[2].default_value = 0.15, -0.55
    low.inputs[3].default_value, low.inputs[4].default_value = 0.0, 1.0
    glow = _math(nt, 'MULTIPLY', ring.outputs['Color'], low.outputs[0])
    col = _mixrgb(nt, 'ADD', glow, disc.outputs['Color'], tuple(_rgb('#8a5326') * 0.9))
    nt.links.new(col, b.inputs['Base Color'])
    return m


def lid_material(name, face_rgb):
    """Eyelids in the face colour (linear RGB) with a dark rim along the edge (hedgehogs have dark-rimmed eyes)."""
    m = lib.principled(name, _c4(face_rgb), rough=0.7, sheen=0.7, sheen_rough=0.5, spec=0.2, sss=0.15, sss_scale=0.003)
    nt = m.node_tree
    tc = nt.nodes.new('ShaderNodeTexCoord')
    sep = nt.nodes.new('ShaderNodeSeparateXYZ')
    nt.links.new(tc.outputs['Object'], sep.inputs[0])
    az = _math(nt, 'ABSOLUTE', sep.outputs['Z'])
    edge = nt.nodes.new('ShaderNodeMapRange')
    nt.links.new(az, edge.inputs[0])
    edge.inputs[1].default_value, edge.inputs[2].default_value = 0.0003, 0.0013
    col = _mixrgb(nt, 'MIX', edge.outputs[0], tuple(_rgb('#3a2418')), tuple(np.asarray(face_rgb) * 0.95))
    nt.links.new(col, nt.nodes['Principled BSDF'].inputs['Base Color'])
    return m


def nose_material(name):
    m = lib.principled(name, '#20130f', rough=0.3, coat=0.7, coat_rough=0.12, spec=0.5)
    nt = m.node_tree
    tc = nt.nodes.new('ShaderNodeTexCoord')
    nz = nt.nodes.new('ShaderNodeTexNoise')
    nz.inputs['Scale'].default_value = 1800.0
    nt.links.new(tc.outputs['Object'], nz.inputs['Vector'])
    bump = nt.nodes.new('ShaderNodeBump')
    bump.inputs['Strength'].default_value = 0.25
    bump.inputs['Distance'].default_value = 0.0002
    nt.links.new(nz.outputs[0], bump.inputs['Height'])
    nt.links.new(bump.outputs['Normal'], nt.nodes['Principled BSDF'].inputs['Normal'])
    return m


# ---------------------------------------------------------------------------------------------- the character


class Rig:
    """Handles of one built hedgehog. All objects are in `objects`; `glints` are the eyes and the nose."""


def build_hedgehog(spec=None, cheap_fur=False):
    """Builds a hedgehog into the current scene, standing at the origin, facing -Y. Returns a Rig.
    spec: overrides of LITTLE (pass hedgehog.MAMA for Mama). cheap_fur: see fur_material."""
    sp = dict(LITTLE)
    sp.update(spec or {})
    nm = sp['name']
    rng = np.random.default_rng(sp['seed'])
    face, white, brown = _rgb(sp['face']), _rgb(sp['chest']), _rgb(sp['spine'])
    warm = np.array([1.0, 0.80, 0.56])
    face = _mixc(face, face * warm, sp['fur_warmth'])
    white = _mixc(white, white * warm, sp['fur_warmth'] * 0.6)
    tan = _mixc(face, brown, 0.45)
    hide = brown * 0.42                       # skin under the quills
    rx, ry, rz = sp['body_r']
    r_eye = sp['eye_r']
    ksn = sp['snout']
    nose_c = np.array([0.0, -0.046 - 0.0235 * ksn - 0.0085, -0.0012])
    eye_out = 0.0056 * (1 - r_eye / 0.0098)  # smaller eyes sit further out, so they bulge by the same share
    eyes_c = [np.array([s * EYE[0], EYE[1], EYE[2]]) + eye_out * np.array([s * 0.697, -0.649, 0.306]) for s in (1, -1)]

    mats = dict(
        skin=skin_material(nm + '.skin'),
        fur=fur_material(nm + '.fur', cheap_fur),
        spine=spine_material(nm + '.quill', sp['spine']),
        eye=eye_material(nm + '.eye'),
        lid=lid_material(nm + '.lid', face),
        nose=nose_material(nm + '.nose'),
        paw=lib.principled(nm + '.paw', sp['paw'], rough=0.55, sheen=0.5, sheen_rough=0.5, sss=0.15, sss_scale=0.003),
        leg=lib.principled(nm + '.leg', _c4(white), rough=0.7, sheen=0.9, sheen_rough=0.45, spec=0.2),
        ear=lib.principled(nm + '.ear', '#d8947a', rough=0.55, sss=1.0, sss_radius=(1.0, 0.30, 0.16),
                           sss_scale=0.012, sheen=0.6, sheen_rough=0.5, spec=0.3),
        ear_in=lib.principled(nm + '.earin', '#c0705e', rough=0.6, sss=1.0, sss_radius=(1.0, 0.30, 0.16),
                              sss_scale=0.012, sheen=0.4, spec=0.25),
        mouth=lib.principled(nm + '.mouth', '#5a3026', rough=0.6, spec=0.3),
    )

    rig = Rig()
    rig.spec, rig.mats = sp, mats
    rig.root = lib.empty(nm + '.root', (0, 0, 0), None, 0.1)
    rig.root.scale = (sp['scale'],) * 3
    rig.body = lib.empty(nm + '.body', BODY_C, rig.root, 0.05)
    rig.head = lib.empty(nm + '.head', tuple(NECK), rig.body, 0.04)
    body, head = rig.body, rig.head

    # ---- body: solid, quills, coat
    bsdf, hsdf = _body_sdf(sp), _head_sdf(sp)
    bmesh_o, bv, bf = _mesh_from_sdf(nm + '.bodymesh', bsdf, (0, 0, 0), 5, 0.09, mats['skin'], body, subsurf=1)
    m_v, _ = _skirt(sp, bv)
    bcol = _mixc(_mixc(white, face, 0.3), hide, _ss(-0.02, 0.06, m_v))
    lib.set_point_attr(bmesh_o, 'col', np.concatenate([bcol, np.ones((len(bv), 1))], axis=1), 'FLOAT_COLOR')

    p = _sample(bv, bf, int(sp['n_spines'] * 2.1), rng)
    m_p, u_p = _skirt(sp, p)
    hd = hsdf(p - NECK)                       # < 0 where the body lies inside the head (standing pose)
    keep = (rng.random(len(p)) < _ss(0.0, 0.09, m_p)) & ((hd > 0.004) | (hd < -0.006))
    n_q = sp['n_spines']
    p, m_p, u_p, hd = p[keep][:n_q], m_p[keep][:n_q], u_p[keep][:n_q], hd[keep][:n_q]
    nrm = _normals(bsdf, p)
    back = np.array([0.0, 1.0, 0.0]) - nrm * nrm[:, 1:2]
    lean = 0.18 + 0.42 * _ss(-0.8, 0.0, u_p)
    d = _unit(nrm + back * lean[:, None] + rng.normal(0, 0.24, p.shape))
    L = sp['spine_len'] * rng.uniform(0.8, 1.1, len(p)) * (0.6 + 0.4 * _ss(0.0, 0.25, m_p)) \
        * (0.72 + 0.28 * _ss(-1.0, -0.45, u_p))
    L = np.where(hd < 0, np.minimum(L, -hd * 0.85), L)   # short quills hidden under the head show when he tucks it in
    pts = (p - nrm * 0.0006)[:, None, :] + (L[:, None] * np.linspace(0, 1, 4)[None, :])[:, :, None] * d[:, None, :]
    rig.spines = _curves(nm + '.quills', pts, 0.00078 * rng.uniform(0.85, 1.1, len(p)), 0.00010, mats['spine'], body,
                         rnd=rng.random(len(p)), shape=2.2)

    p = _sample(bv, bf, int(sp['n_coat'] * 3.0), rng)
    m_p, u_p = _skirt(sp, p)
    keep = (rng.random(len(p)) < 1 - _ss(0.02, 0.14, m_p)) & (hsdf(p - NECK) > -0.001)
    p, m_p, u_p = p[keep][:sp['n_coat']], m_p[keep][:sp['n_coat']], u_p[keep][:sp['n_coat']]
    nrm = _normals(bsdf, p)
    flow = np.array([0.0, 0.55, -1.0])[None, :] - nrm * (nrm @ np.array([0.0, 0.55, -1.0]))[:, None]
    flow = _unit(flow + rng.normal(0, 0.12, p.shape))
    lift = 0.50
    d0 = _unit(flow * math.cos(lift) + nrm * math.sin(lift) + rng.normal(0, 0.16, p.shape))
    d1 = _unit(flow * 0.6 + np.array([0.0, 0.1, -0.8])[None, :] - nrm * 0.05)
    L = (0.0090 + 0.0045 * _ss(-0.30, 0.05, m_p) + 0.0020 * _ss(-0.2, -0.7, u_p)) * rng.uniform(0.75, 1.15, len(p))
    pts = _clump(_strands(p, d0, d1, L, 5), rng, every=12, pull=0.40)
    col = _mixc(white, tan, 0.85 * _ss(-0.32, 0.02, m_p))
    col = _mixc(col, brown * 0.8, _ss(0.02, 0.12, m_p)) * rng.uniform(0.9, 1.08, (len(p), 1))
    rig.coat = _curves(nm + '.coat', pts, 0.00014, 0.00003, mats['fur'], body, col=col)

    # ---- head: solid, face fur, hood quills
    hc = np.array([0.0, -0.030, -0.003])
    hmesh_o, hv, hf = _mesh_from_sdf(nm + '.headmesh', hsdf, hc, 6, 0.072, mats['skin'], head)
    s_v = _crown(hv)
    hcol = _mixc(np.broadcast_to(face, hv.shape), hide, _ss(-0.05, 0.06, s_v))
    lib.set_point_attr(hmesh_o, 'col', np.concatenate([hcol, np.ones((len(hv), 1))], axis=1), 'FLOAT_COLOR')

    def sy(y):                                                           # stretch the snout with the snout factor
        return -0.046 + (y + 0.046) * ksn if y < -0.046 else y

    mouth = []                                                           # a small smile under the snout
    for s in (1, -1):
        mouth.append(np.array([_ray(hsdf, (0.0, sy(y), -0.006), (s * math.sin(math.radians(a)), 0.0,
                                                                 -math.cos(math.radians(a))))
                               for y, a in ((-0.0700, 0), (-0.0676, 18), (-0.0646, 32), (-0.0616, 43), (-0.0592, 52),
                                            (-0.0578, 60))]))
    philtrum = np.array([_ray(hsdf, (0.0, sy(-0.0700), -0.004), (0.0, -math.cos(math.radians(a)),
                                                                 -math.sin(math.radians(a)))) for a in (35, 60, 90)])
    rig.mouth = []
    for i, poly in enumerate(mouth + [philtrum]):
        out = poly + _normals(hsdf, poly) * 0.0003
        radii = [0.00045, 0.00050, 0.00050, 0.00045, 0.00036, 0.00022] if i < 2 else [0.00026, 0.00032, 0.00040]
        rig.mouth.append(lib.tube_path(f'{nm}.mouth{i}', out, radii, mats['mouth'], head, segs=8, caps=True, subsurf=1))

    p = _sample(hv, hf, int(sp['n_face'] * 1.22), rng)
    dn = np.linalg.norm(p - nose_c, axis=1)
    de = np.minimum(*[np.linalg.norm(p - E, axis=1) for E in eyes_c])
    dm = np.minimum(np.minimum(_poly_dist(p, mouth[0]), _poly_dist(p, mouth[1])), _poly_dist(p, philtrum))
    keep = (dn > 0.0064) & (de > r_eye * 1.12) & (dm > 0.0011)
    p, dn, de, dm = p[keep][:sp['n_face']], dn[keep][:sp['n_face']], de[keep][:sp['n_face']], dm[keep][:sp['n_face']]
    nrm = _normals(hsdf, p)
    flow = _unit(p - nose_c)                                             # combed back from the nose ...
    for E in eyes_c:                                                     # ... and parting around the eyes
        v = p - E
        dist = np.linalg.norm(v, axis=1)
        flow += (1.8 * np.exp(-((dist - r_eye) / 0.006) ** 2))[:, None] * v / dist[:, None]
    flow[:, 2] -= 0.22
    flow = _unit(flow - nrm * np.sum(flow * nrm, axis=1, keepdims=True))
    cheek = np.maximum(*[np.exp(-np.sum((p - np.array([s * 0.0215, -0.034, -0.015])) ** 2, axis=1) / 0.014 ** 2)
                         for s in (1, -1)])
    s_p = _crown(p)
    L = 0.0020 + 0.0062 * _ss(0.010, 0.050, dn) + 0.0048 * cheek
    L = L * (0.5 + 0.5 * _ss(0.0, 0.007, de - r_eye * 1.12)) * (0.4 + 0.6 * _ss(0.0011, 0.006, dm))
    L = L * rng.uniform(0.75, 1.15, len(p))
    lift = (0.42 + 0.32 * cheek)[:, None]
    d0 = _unit(flow * np.cos(lift) + nrm * np.sin(lift) + rng.normal(0, 0.15, p.shape))
    d1 = _unit(flow - nrm * 0.12 + np.array([0.0, 0.0, -0.30])[None, :] * (0.4 + cheek)[:, None])
    pts = _clump(_strands(p, d0, d1, L, 5), rng, every=14, pull=0.36)
    col = _mixc(np.broadcast_to(face, p.shape), white, 0.8 * (1 - _ss(-0.016, 0.004, p[:, 2])))
    col = _mixc(col, tan, 0.55 * _ss(-0.30, -0.05, s_p))
    col = _mixc(col, brown * 0.8, _ss(-0.05, 0.06, s_p)) * rng.uniform(0.9, 1.08, (len(p), 1))
    rig.facefur = _curves(nm + '.facefur', pts, 0.00013, 0.00003, mats['fur'], head, col=col)

    p = _sample(hv, hf, int(sp['n_crown'] * 6), rng)
    s_p = _crown(p)
    keep = rng.random(len(p)) < _ss(0.0, 0.035, s_p)
    for s in (1, -1):                                                    # keep the ears clear
        ear_c = SKULL_C + 0.0315 * _unit(np.array([s * EAR_DIR[0], EAR_DIR[1], EAR_DIR[2]])) \
            + 0.006 * _unit(np.array([s * EAR_UP[0], EAR_UP[1], EAR_UP[2]]))
        keep &= np.linalg.norm(p - ear_c, axis=1) > 0.0105
    p, s_p = p[keep][:sp['n_crown']], s_p[keep][:sp['n_crown']]
    nrm = _normals(hsdf, p)
    d = _unit(nrm * 0.8 + np.array([0.0, 0.42, 0.40])[None, :] + rng.normal(0, 0.20, p.shape))
    L = sp['spine_len'] * (0.60 + 0.36 * _ss(0.0, 0.4, s_p)) * rng.uniform(0.85, 1.1, len(p))
    pts = (p - nrm * 0.0006)[:, None, :] + (L[:, None] * np.linspace(0, 1, 4)[None, :])[:, :, None] * d[:, None, :]
    rig.hood = _curves(nm + '.hood', pts, 0.00070 * rng.uniform(0.85, 1.1, len(p)), 0.00010, mats['spine'], head,
                       rnd=rng.random(len(p)), shape=2.2)

    # ---- whiskers
    wr, wd = [], []
    for s in (1, -1):
        for i in range(6):
            a, b = i % 3, i // 3
            wr.append((s * (0.0085 + 0.0016 * a), nose_c[1] + 0.012 + 0.0036 * a, -0.0040 - 0.0048 * b))
            wd.append((s * 1.0, 0.22 + 0.16 * a, 0.14 - 0.30 * b))
    wr = _project(hsdf, hc, wr)
    wd = _unit(np.array(wd) + rng.normal(0, 0.06, (12, 3)))
    pts = _strands(wr, wd, _unit(wd + np.array([0.0, 0.3, -0.35])), rng.uniform(0.020, 0.030, 12), 6)
    rig.whiskers = _curves(nm + '.whiskers', pts, 0.00016, 0.00004, mats['fur'], head,
                           col=np.broadcast_to(_rgb('#fff6e6'), (12, 3)).copy())

    # ---- nose, ears
    rig.nose = lib.ellipsoid(nm + '.nose', 0.0070, 0.0058, 0.0056, mats['nose'], head, tuple(nose_c), 24, 2)
    rig.ears, rig.ear_rest = [], []
    for s in (1, -1):
        base = SKULL_C + 0.0315 * _unit(np.array([s * EAR_DIR[0], EAR_DIR[1], EAR_DIR[2]]))
        up = _unit(np.array([s * EAR_UP[0], EAR_UP[1], EAR_UP[2]]))
        fwd = _unit(np.array([s * 0.45, -0.89, 0.10]))
        xa = _unit(np.cross(-fwd, up))
        ya = np.cross(up, xa)
        piv = lib.empty(f'{nm}.ear{"L" if s > 0 else "R"}', tuple(base), head, 0.01)
        piv.rotation_euler = _euler_from_axes(xa, ya, up)
        lib.ellipsoid(piv.name + '.mesh', 0.0112, 0.0017, 0.0128, mats['ear'], piv, (0, 0, 0.0088), 24, 2)
        lib.ellipsoid(piv.name + '.inner', 0.0080, 0.0012, 0.0094, mats['ear_in'], piv, (0, -0.0009, 0.0084), 20, 2)
        rig.ears.append(piv)
        rig.ear_rest.append(tuple(piv.rotation_euler))

    # ---- eyes: socket > eyeball, upper lid, lower lid
    rig.eyes = []
    r_lid = r_eye * 1.07
    rings = [(r_lid * math.sin(t), r_lid * math.cos(t), r_lid * math.cos(t), 0.0, 0.0)
             for t in np.linspace(0, math.pi / 2, 13)]
    rings[-1] = (r_lid, 0.0, 0.0, 0.0, 0.0)
    lv, lf = lib.rings_mesh(rings, 28)
    for s, E in zip((1, -1), eyes_c):
        tag = 'L' if s > 0 else 'R'
        sock = lib.empty(f'{nm}.eye{tag}', tuple(E), head, 0.01, rot=(-math.radians(14), s * math.radians(5), s * math.radians(40)))
        ball = lib.ellipsoid(f'{nm}.eyeball{tag}', r_eye, r_eye, r_eye, mats['eye'], sock, (0, 0, 0), 32, 2)
        up_o = lib.mesh_obj(f'{nm}.lidU{tag}', lv, lf, mats['lid'], sock, True, 1)
        lo_o = lib.mesh_obj(f'{nm}.lidD{tag}', [(x, y, -z) for x, y, z in lv], [f[::-1] for f in lf], mats['lid'],
                            sock, True, 1)
        for o in (up_o, lo_o):
            md = o.modifiers.new('rim', 'SOLIDIFY')
            md.thickness = 0.0007
            md.offset = 1.0
        rig.eyes.append(dict(side=s, socket=sock, ball=ball, upper=up_o, lower=lo_o))
    rig.focus = lib.empty(nm + '.focus', (0.0, EYE[1] - r_eye * 0.6, EYE[2]), head, 0.01)

    # ---- legs: hip > thigh, paw, toes
    rig.legs, paws = {}, []
    for key, hip in HIPS.items():
        piv = lib.empty(f'{nm}.hip{key}', hip, body, 0.01)
        lib.ellipsoid(f'{nm}.thigh{key}', 0.0098, 0.0105, 0.0135, mats['leg'], piv, (0, 0, -0.0085), 20, 1)
        paws.append(lib.ellipsoid(f'{nm}.paw{key}', 0.0082, 0.0125, 0.0052, mats['paw'], piv, (0, -0.0055, -0.0178), 20, 1))
        for i in range(4):
            x = (i - 1.5) * 0.0042
            lib.ellipsoid(f'{nm}.toe{key}{i}', 0.0026, 0.0034, 0.0026, mats['paw'], piv,
                          (x, -0.0168 + abs(i - 1.5) * 0.0012, -0.0186), 12, 1)
        rig.legs[key] = piv
        dl = _unit(rng.normal(size=(1700, 3)))
        dl = dl[dl[:, 2] < 0.45]                                         # the top of the thigh is inside the body
        rl = np.array([0.0098, 0.0105, 0.0135])
        pl, nl = np.array([0.0, 0.0, -0.0085]) + dl * rl, _unit(dl / rl)
        fl = np.array([0.0, 0.25, -1.0])[None, :] - nl * (nl @ np.array([0.0, 0.25, -1.0]))[:, None]
        fl = _unit(fl + rng.normal(0, 0.12, pl.shape))
        d0 = _unit(fl * math.cos(0.5) + nl * math.sin(0.5) + rng.normal(0, 0.15, pl.shape))
        d1 = _unit(fl * 0.7 + np.array([0.0, 0.0, -0.6])[None, :])
        _curves(f'{nm}.legfur{key}', _strands(pl, d0, d1, rng.uniform(0.004, 0.007, len(pl)), 4), 0.00013, 0.00003,
                mats['fur'], piv, col=white[None, :] * rng.uniform(0.9, 1.05, (len(pl), 1)))

    rig.glints = [e['ball'] for e in rig.eyes] + [rig.nose]
    rig.ground_objs = [bmesh_o] + paws
    rig.objects = _family(rig.root)
    rig.counts = dict(quills=len(rig.spines.data.curves), hood=len(rig.hood.data.curves),
                      coat=len(rig.coat.data.curves), face=len(rig.facefur.data.curves))
    pose(rig)
    return rig


def _euler_from_axes(x, y, z):
    from mathutils import Matrix
    m = Matrix(((x[0], y[0], z[0]), (x[1], y[1], z[1]), (x[2], y[2], z[2])))
    return m.to_euler()


def _family(root):
    out, stack = [], [root]
    while stack:
        o = stack.pop()
        out.append(o)
        stack.extend(o.children)
    return out


# ---------------------------------------------------------------------------------------------- posing

# Angles in degrees, lengths in metres at scale 1. pitch > 0 = nose down; yaw > 0 = nose toward +X (his left).
# lid_upper / lid_lower: how high the lid's edge sits over the middle of the eye. Upper: 50 wide open, 40 relaxed,
# 10 sleepy. Lower: -42 relaxed, -28 smiling. Both equal = shut (both -18: asleep; both +14: a laughing squeeze).
REST = dict(
    x=0.0, y=0.0, yaw=0.0,              # where he stands, which way he faces
    lift=0.0, pitch=0.0, roll=0.0,      # body: hop height, pitch, roll
    squash=(1.0, 1.0, 1.0),             # body scale (width, length, height) for squash and stretch
    head_pitch=0.0, head_yaw=0.0, head_roll=0.0, head_tuck=0.0,
    gaze_yaw=0.0, gaze_pitch=0.0,       # eyes: + = toward his left, + = up
    lid_upper=40.0, lid_lower=-42.0,
    lid_tilt=0.0,                       # + lowers the outer corners (kinder). Seen from above the lids read stern: add 20
    ear=0.0,                            # + perks the ears, - lays them back
    nose=1.0,                           # nose size (twitch between 0.92 and 1.12)
    # legs: (swing in degrees, + = back; lift in metres, - = reach down; optional size, 1 = normal, 0.05 = tucked away)
    legs={'FL': (0.0, 0.0), 'FR': (0.0, 0.0), 'HL': (0.0, 0.0), 'HR': (0.0, 0.0)},
)
STAND = dict(REST, head_pitch=-4.0, lid_upper=42.0, lid_lower=-34.0, ear=6.0)
SNIFF = dict(REST, pitch=-11.0, head_pitch=-30.0, lid_upper=12.0, lid_lower=-30.0, ear=14.0, nose=1.12,
             legs={'FL': (-28.0, 0.004), 'FR': (0.0, -0.009), 'HL': (0.0, 0.0), 'HR': (0.0, 0.0)})
CURL = dict(REST, pitch=-58.0, squash=(1.06, 0.90, 1.06), head_pitch=66.0, head_tuck=0.006, lift=0.006,
            lid_upper=50.0, lid_lower=-34.0, lid_tilt=24.0, gaze_pitch=18.0, ear=-14.0,
            # front paws tucked away, hind paws stick out in front
            legs={'FL': (0.0, 0.016, 0.05), 'FR': (0.0, 0.016, 0.05), 'HL': (-40.0, -0.012), 'HR': (-40.0, -0.012)})
ASLEEP = dict(CURL, lid_upper=-18.0, lid_lower=-18.0, lid_tilt=0.0, gaze_pitch=0.0, head_pitch=74.0)   # not test-drawn


def mix_pose(a, b, t):
    """Blend two poses (0 = a, 1 = b), for in-betweens."""
    out = {}
    for k in REST:
        va, vb = a.get(k, REST[k]), b.get(k, REST[k])
        if k == 'legs':
            full = lambda v: (tuple(v) + (1.0,))[:3] if len(v) < 3 else tuple(v)   # noqa: E731
            out[k] = {n: tuple(x * (1 - t) + y * t for x, y in zip(full(va.get(n, (0, 0))), full(vb.get(n, (0, 0)))))
                      for n in HIPS}
        elif isinstance(va, tuple):
            out[k] = tuple(x * (1 - t) + y * t for x, y in zip(va, vb))
        else:
            out[k] = va * (1 - t) + vb * t
    return out


def pose(rig, frame=None, **kw):
    """Sets a pose. Missing values come from REST. With frame=N every value is keyed at film frame N."""
    p = dict(REST)
    p.update(kw)
    rad = math.radians
    keyed = []

    def put(o, loc=None, rot=None, scale=None):
        if loc is not None:
            o.location = loc
            keyed.append((o, 'location'))
        if rot is not None:
            o.rotation_euler = rot
            keyed.append((o, 'rotation_euler'))
        if scale is not None:
            o.scale = scale
            keyed.append((o, 'scale'))

    put(rig.root, loc=(p['x'], p['y'], rig.root.location.z), rot=(0, 0, rad(p['yaw'])))
    put(rig.body, loc=(BODY_C[0], BODY_C[1], BODY_C[2] + p['lift']), rot=(rad(p['pitch']), rad(p['roll']), 0),
        scale=tuple(p['squash']))
    put(rig.head, loc=(NECK[0], NECK[1] + p['head_tuck'], NECK[2]),
        rot=(rad(p['head_pitch']), rad(p['head_roll']), rad(p['head_yaw'])))
    for e in rig.eyes:
        s = e['side']
        put(e['ball'], rot=(rad(12.0 - p['gaze_pitch']), 0, rad(-s * 20.0 + p['gaze_yaw'])))
        put(e['upper'], rot=(-rad(p['lid_upper']), s * rad(p['lid_tilt']), 0))
        put(e['lower'], rot=(-rad(p['lid_lower']), s * rad(p['lid_tilt']), 0))
    for piv, r in zip(rig.ears, rig.ear_rest):
        put(piv, rot=(r[0] - rad(p['ear']) * 0.6, r[1], r[2]))
    put(rig.nose, scale=(p['nose'],) * 3)
    for key, piv in rig.legs.items():
        leg = tuple(p['legs'].get(key, (0.0, 0.0)))
        swing, lift, size = leg[0], leg[1], (leg[2] if len(leg) > 2 else 1.0)
        h = HIPS[key]
        put(piv, loc=(h[0], h[1], h[2] + lift), rot=(rad(swing), 0, 0), scale=(size,) * 3)
    if frame is not None:
        for o, path in keyed:
            o.keyframe_insert(path, frame=frame)
    return p


def settle(rig, extra=0.0):
    """For stills: moves the root up or down so the lowest of body and paws rests on z = extra."""
    bpy.context.view_layer.update()
    zmin = 1e9
    for o in rig.ground_objs:
        co = np.empty(len(o.data.vertices) * 3)
        o.data.vertices.foreach_get('co', co)
        M = np.array(o.matrix_world)
        zmin = min(zmin, float((co.reshape(-1, 3) @ M[2, :3] + M[2, 3]).min()))
    rig.root.location.z += extra - zmin
    bpy.context.view_layer.update()
    return rig.root.location.z
