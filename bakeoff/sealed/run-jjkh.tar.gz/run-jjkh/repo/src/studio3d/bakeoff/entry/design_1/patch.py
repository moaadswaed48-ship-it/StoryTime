"""A simple patch of the garden at dusk, for the design stills of proposal 1.

Only a stage for the character: short lawn with a mossy clearing, taller grass behind, a bush, the low stone wall,
the shaded house wall with its warm-lit window, a dusk sky. Light: one low golden sun from the side, the cool sky as
fill, a soft warm glow from the window side as a rim, and a catchlight card beside the lens (seen only in
reflections: it puts the sparkle in the eyes and on the nose).

Everything is built in code. Grass is instanced as tufts with a plain Principled BSDF (the cheap rows of the
measured cost table).
"""
import math
import os
import random
import sys

import bpy
import numpy as np
from mathutils import Vector

_HERE = os.path.dirname(os.path.abspath(__file__))
_BLENDER_LIB = os.path.abspath(os.path.join(_HERE, '..', '..', '..', 'blender'))
if _BLENDER_LIB not in sys.path:
    sys.path.insert(0, _BLENDER_LIB)

import hill  # noqa: E402
import lib  # noqa: E402
from lib import ellipsoid, empty, lin, mesh_obj, principled  # noqa: E402

SUN_AZ = 84.0      # degrees from +Y toward +X: the sun stands to the cameras' right
SUN_EL = 8.0       # degrees above the horizon: the last golden light


def _noise_colour(m, a, b, scale, detail=4.0, bump=0.0):
    nt = m.node_tree
    bs = nt.nodes['Principled BSDF']
    tc = nt.nodes.new('ShaderNodeTexCoord')
    nz = nt.nodes.new('ShaderNodeTexNoise')
    nz.inputs['Scale'].default_value = scale
    nz.inputs['Detail'].default_value = detail
    nt.links.new(tc.outputs['Object'], nz.inputs['Vector'])
    cr = nt.nodes.new('ShaderNodeValToRGB')
    e = cr.color_ramp.elements
    e[0].position, e[0].color = 0.35, lin(a)
    e[1].position, e[1].color = 0.68, lin(b)
    nt.links.new(nz.outputs['Fac'], cr.inputs['Fac'])
    nt.links.new(cr.outputs['Color'], bs.inputs['Base Color'])
    if bump:
        bp = nt.nodes.new('ShaderNodeBump')
        bp.inputs['Strength'].default_value = bump
        nt.links.new(nz.outputs['Fac'], bp.inputs['Height'])
        nt.links.new(bp.outputs['Normal'], bs.inputs['Normal'])
    return m


def _grass_material():
    m = principled('Patch.grass', '#5f8a2c', rough=0.55, spec=0.3)
    nt = m.node_tree
    b = nt.nodes['Principled BSDF']
    oi = nt.nodes.new('ShaderNodeObjectInfo')
    cr = nt.nodes.new('ShaderNodeValToRGB')
    e = cr.color_ramp.elements
    e[0].position, e[0].color = 0.0, lin('#3f6a1c')
    e[1].position, e[1].color = 1.0, lin('#8fa83c')
    mid = cr.color_ramp.elements.new(0.55)
    mid.color = lin('#5f8a2c')
    nt.links.new(oi.outputs['Random'], cr.inputs['Fac'])
    tc = nt.nodes.new('ShaderNodeTexCoord')
    sep = nt.nodes.new('ShaderNodeSeparateXYZ')
    nt.links.new(tc.outputs['Generated'], sep.inputs[0])
    mx = nt.nodes.new('ShaderNodeMix')
    mx.data_type = 'RGBA'
    mx.inputs['A'].default_value = lin('#22380f')
    nt.links.new(sep.outputs['Z'], mx.inputs['Factor'])
    nt.links.new(cr.outputs['Color'], mx.inputs['B'])
    nt.links.new(mx.outputs['Result'], b.inputs['Base Color'])
    return m


def _tuft(name, rng, blades, h_lo, h_hi, width, radius, mat, coll):
    """One clump of grass blades merged into a single mesh (instanced many times)."""
    verts, faces = [], []
    n = 5
    for _ in range(blades):
        a, rad = rng.uniform(0, 2 * math.pi), radius * math.sqrt(rng.random())
        bx, by = rad * math.cos(a), rad * math.sin(a)
        hgt, bend, yaw = rng.uniform(h_lo, h_hi), rng.uniform(0.12, 0.6), rng.uniform(0, 2 * math.pi)
        wid = width * rng.uniform(0.7, 1.25)
        cy, sy = math.cos(yaw), math.sin(yaw)
        base = len(verts)
        for i in range(n + 1):
            t = i / n
            off = bend * hgt * t * t
            ww = wid * (1 - t) ** 0.8 + 0.0002
            for sx in (-0.5, 0.5):
                lx = sx * ww
                verts.append((bx + lx * cy - off * sy, by + lx * sy + off * cy, hgt * t))
        for i in range(n):
            q = base + 2 * i
            faces.append((q, q + 1, q + 3, q + 2))
    o = mesh_obj(name, verts, faces, mat, None, True, 0)
    bpy.context.scene.collection.objects.unlink(o)
    coll.objects.link(o)
    return o


def build_patch(seed=5):
    """Ground, grass, bush, wall, house and window. The character stands at the origin facing -Y; the cameras sit
    in the quarter between -Y and +X and look back toward -X/+Y."""
    rng = random.Random(seed)

    # ---- ground
    gm = _noise_colour(principled('Patch.ground', '#3a2e1e', rough=0.95, spec=0.15), '#33281a', '#46512a', 9.0, 5.0, 0.5)
    xs = np.arange(-9.0, 3.01, 0.06)
    ys = np.arange(-1.0, 3.31, 0.06)
    X, Y = np.meshgrid(xs, ys)
    nx, ny = len(xs), len(ys)
    verts = np.stack([X.ravel(), Y.ravel(), np.zeros(X.size)], 1)
    faces = [(j * nx + i, j * nx + i + 1, (j + 1) * nx + i + 1, (j + 1) * nx + i)
             for j in range(ny - 1) for i in range(nx - 1)]
    ground = mesh_obj('Patch.ground', verts, faces, gm, None, True, 0)
    far = mesh_obj('Patch.ground.far', [(-60, -60, -0.002), (60, -60, -0.002), (60, 60, -0.002), (-60, 60, -0.002)],
                   [(0, 1, 2, 3)], gm, None, False, 0)

    x, y = X.ravel(), Y.ravel()
    r = np.hypot(x, y)
    ang = np.abs(np.arctan2(x, -y))                          # 0 = straight toward -Y
    wedge = ((ang < 1.15) & (r < 0.85)) | (r < 0.17)         # the clearing the cameras look across
    seen = (y > -0.75) & (x < 0.9 + 0.25 * np.maximum(y, 0)) & (x > -0.9 - 2.4 * np.maximum(y + 0.3, 0))
    far_fade = np.clip(1.0 - (r - 0.8) / 1.8, 0.12, 1.0)
    g_short = np.where(wedge & seen, np.clip((r - 0.085) / 0.22, 0.0, 1.0), 0.0)
    g_lawn = np.where(~wedge & seen, far_fade, 0.0)
    patchy = 0.5 + 0.5 * np.sin(3.1 * x + 1.3) * np.cos(2.3 * y - 0.4)
    sunway = (x > 0.0) & (np.abs(y - 0.105 * x) < 0.30)      # keep the sun's path to him clear of tall grass
    g_tall = np.where(~wedge & seen & ~sunway & (r > 0.24), patchy * np.clip(1.0 - (r - 0.8) / 2.5, 0.0, 1.0), 0.0)
    for nm, val in (('g_short', g_short), ('g_lawn', g_lawn), ('g_tall', g_tall)):
        lib.set_point_attr(ground, nm, val, 'FLOAT')

    # ---- grass: three sizes of the same tufts
    coll = bpy.data.collections.new('Patch.tufts')
    grm = _grass_material()
    for i in range(7):
        _tuft(f'Patch.tuft{i}', rng, 18, 0.018, 0.034, 0.0024, 0.022, grm, coll)
    hill.instancer(ground, coll, 'g_short', 3600.0, 11, 0.42, 0.70, 'Patch.grass.short', tilt=0.25)
    hill.instancer(ground, coll, 'g_lawn', 2100.0, 21, 0.90, 1.45, 'Patch.grass.lawn', tilt=0.25)
    hill.instancer(ground, coll, 'g_tall', 420.0, 31, 1.9, 2.9, 'Patch.grass.tall', tilt=0.3)

    # ---- a few pebbles on the bare, mossy spot where he stands
    pm = _noise_colour(principled('Patch.pebble', '#8a8072', rough=0.8, spec=0.3), '#6a6258', '#a39a8c', 60.0, 2.0, 0.3)
    for i in range(26):
        a, rad = rng.uniform(-1.3, 1.3), rng.uniform(0.07, 0.42)
        s = rng.uniform(0.003, 0.008)
        ellipsoid(f'Patch.pebble{i}', s, s * rng.uniform(0.7, 1.2), s * 0.6, pm, None,
                  (rad * math.sin(a), -rad * math.cos(a), s * 0.25), 10, 1)

    # ---- a bush behind him (dark, so the lit spines stand out against it), two more for the other views
    bm = _noise_colour(principled('Patch.bush', '#2a4a20', rough=0.7, spec=0.3), '#1c3516', '#4c6e2c', 26.0, 3.0, 0.8)
    k = 0
    for (cx, cy, cz, rad, cnt) in ((-2.2, 2.3, 0.36, 0.42, 22), (-3.5, 2.5, 0.38, 0.46, 22),
                                   (-0.2, 2.9, 0.32, 0.40, 14)):
        for _ in range(cnt):
            a, b = rng.uniform(0, 2 * math.pi), rng.uniform(-0.6, 1.2)
            rr = rad * rng.uniform(0.55, 1.0)
            px, py = cx + rr * math.cos(a) * math.cos(b), cy + rr * math.sin(a) * math.cos(b) * 0.7
            pz = max(0.12, cz + rr * math.sin(b) * 0.8)
            s = rng.uniform(0.16, 0.30)
            ellipsoid(f'Patch.bush{k}', s, s * rng.uniform(0.8, 1.1), s * rng.uniform(0.7, 1.0), bm, None,
                      (px, py, pz), 16, 1)
            k += 1

    # ---- the low stone wall
    sm = _noise_colour(principled('Patch.stone', '#8a7f70', rough=0.9, spec=0.2), '#6f665a', '#a2968a', 14.0, 4.0, 0.6)
    k = 0
    for course in range(2):
        px = -10.0 + 0.17 * course
        while px < 4.0:
            wdt = rng.uniform(0.15, 0.24)
            ellipsoid(f'Patch.stone{k}', wdt, rng.uniform(0.11, 0.14), rng.uniform(0.095, 0.115), sm, None,
                      (px + wdt, 5.2 + rng.uniform(-0.02, 0.02), 0.10 + 0.19 * course), 12, 1)
            px += 2 * wdt * 0.93
            k += 1

    # ---- the house: a shaded wall and one warm-lit window
    hm = principled('Patch.house', '#b9a58c', rough=0.9, spec=0.1)
    mesh_obj('Patch.house', [(-15, 9.5, 0), (-3.6, 9.5, 0), (-3.6, 9.5, 3.6), (-15, 9.5, 3.6)], [(0, 1, 2, 3)], hm,
             None, False, 0)
    wm = bpy.data.materials.new('Patch.window')
    wm.use_nodes = True
    nt = wm.node_tree
    for nd in list(nt.nodes):
        if nd.type != 'OUTPUT_MATERIAL':
            nt.nodes.remove(nd)
    em = nt.nodes.new('ShaderNodeEmission')
    em.inputs['Color'].default_value = lin('#ffb256')
    em.inputs['Strength'].default_value = 7.0
    nt.links.new(em.outputs[0], nt.nodes['Material Output'].inputs['Surface'])
    for (wx, wz) in ((-6.0, 1.0), (-9.6, 1.0)):
        mesh_obj(f'Patch.window{wx}', [(wx, 9.47, wz), (wx + 0.75, 9.47, wz), (wx + 0.75, 9.47, wz + 0.8),
                                       (wx, 9.47, wz + 0.8)], [(0, 1, 2, 3)], wm, None, False, 0)

    # ---- far trees: a soft dark line under the sky
    tm = principled('Patch.trees', '#24382e', rough=0.9, spec=0.1)
    for i in range(13):
        ellipsoid(f'Patch.tree{i}', rng.uniform(2.8, 4.6), 2.5, rng.uniform(3.0, 5.6), tm, None,
                  (-40 + 5.4 * i + rng.uniform(-1.2, 1.2), rng.uniform(32, 40), 0.6), 16, 1)
    return dict(ground=ground, far=far)


def build_light(sun_energy=3.4, sky_strength=0.22, glow_watts=60.0):
    """Dusk: a low golden sun, the sky as cool fill, a warm glow from the house side as rim."""
    sc = bpy.context.scene
    w = bpy.data.worlds.new('Dusk')
    w.use_nodes = True
    nt = w.node_tree
    bg = nt.nodes['Background']
    sky = nt.nodes.new('ShaderNodeTexSky')
    sky.sky_type = 'MULTIPLE_SCATTERING'
    sky.sun_disc = False
    sky.sun_elevation = math.radians(SUN_EL)
    sky.sun_rotation = math.radians(SUN_AZ) % (2 * math.pi)
    sky.aerosol_density = 1.4
    sky.altitude = 100
    nt.links.new(sky.outputs['Color'], bg.inputs['Color'])
    bg.inputs['Strength'].default_value = sky_strength
    # what the lens sees of the sky: peach at the horizon, rose, then a deepening blue
    geo = nt.nodes.new('ShaderNodeNewGeometry')
    sep = nt.nodes.new('ShaderNodeSeparateXYZ')
    nt.links.new(geo.outputs['Incoming'], sep.inputs[0])
    neg = nt.nodes.new('ShaderNodeMath')
    neg.operation = 'MULTIPLY'
    neg.inputs[1].default_value = -1.0
    nt.links.new(sep.outputs['Z'], neg.inputs[0])
    ramp = nt.nodes.new('ShaderNodeValToRGB')
    e = ramp.color_ramp.elements
    e[0].position, e[0].color = 0.0, lin('#f6bb80')
    e[1].position, e[1].color = 0.50, lin('#3f5c96')
    for pos, c in ((0.07, '#e59c86'), (0.20, '#9d90b6')):
        el = ramp.color_ramp.elements.new(pos)
        el.color = lin(c)
    nt.links.new(neg.outputs[0], ramp.inputs['Fac'])
    bg2 = nt.nodes.new('ShaderNodeBackground')
    bg2.inputs['Strength'].default_value = 0.85
    nt.links.new(ramp.outputs['Color'], bg2.inputs['Color'])
    lp = nt.nodes.new('ShaderNodeLightPath')
    mix = nt.nodes.new('ShaderNodeMixShader')
    nt.links.new(lp.outputs['Is Camera Ray'], mix.inputs['Fac'])
    nt.links.new(bg.outputs[0], mix.inputs[1])
    nt.links.new(bg2.outputs[0], mix.inputs[2])
    nt.links.new(mix.outputs[0], nt.nodes['World Output'].inputs['Surface'])
    sc.world = w

    ld = bpy.data.lights.new('Sun', 'SUN')
    ld.energy = sun_energy
    ld.angle = math.radians(2.5)
    ld.color = lin('#ff9d4d')[:3]
    sun = bpy.data.objects.new('Sun', ld)
    lib.link(sun)
    az, el = math.radians(SUN_AZ), math.radians(SUN_EL)
    to_sun = Vector((math.sin(az) * math.cos(el), math.cos(az) * math.cos(el), math.sin(el)))
    sun.rotation_euler = (-to_sun).to_track_quat('-Z', 'Y').to_euler()

    gl = bpy.data.lights.new('WindowGlow', 'AREA')
    gl.energy = glow_watts
    gl.size = 0.7
    gl.color = lin('#ffad5c')[:3]
    glow = bpy.data.objects.new('WindowGlow', gl)
    lib.link(glow)
    glow.location = (-1.0, 1.25, 0.50)
    aim = Vector((0.0, 0.0, 0.06)) - Vector(glow.location)
    glow.rotation_euler = aim.to_track_quat('-Z', 'Y').to_euler()
    glow.visible_camera = False
    return dict(sun=sun, glow=glow, world=w)


def build_camera(name='Cam'):
    """One camera that always looks at its target empty; a catchlight card rides beside the lens."""
    sc = bpy.context.scene
    cam = bpy.data.cameras.new(name)
    cam.sensor_width = 36
    cam.dof.use_dof = True
    cam.dof.aperture_blades = 7
    cam.clip_start = 0.02
    cam.clip_end = 200
    co = bpy.data.objects.new(name, cam)
    lib.link(co)
    sc.camera = co
    tgt = empty(name + '.target', (0, 0, 0.05), None, 0.02)
    tr = co.constraints.new('TRACK_TO')
    tr.target = tgt
    tr.track_axis = 'TRACK_NEGATIVE_Z'
    tr.up_axis = 'UP_Y'
    em = bpy.data.materials.new('CatchCard')
    em.use_nodes = True
    nt = em.node_tree
    for nd in list(nt.nodes):
        if nd.type != 'OUTPUT_MATERIAL':
            nt.nodes.remove(nd)
    e = nt.nodes.new('ShaderNodeEmission')
    e.inputs['Color'].default_value = lin('#fff1dc')
    e.inputs['Strength'].default_value = 90.0
    nt.links.new(e.outputs[0], nt.nodes['Material Output'].inputs['Surface'])
    card = ellipsoid('CatchCard', 0.16, 0.16, 0.008, em, co, (0.26, 0.24, 0.08), 16, 0)
    for vis in ('visible_camera', 'visible_diffuse', 'visible_shadow', 'visible_transmission',
                'visible_volume_scatter'):
        setattr(card, vis, False)
    return co, tgt, card


def aim_camera(co, tgt, loc, look_at, lens, fstop, focus_obj):
    co.location = loc
    tgt.location = look_at
    co.data.lens = lens
    co.data.dof.aperture_fstop = fstop
    co.data.dof.focus_object = focus_obj


def render_settings(samples=32, res=(1280, 720), exposure=0.5, denoise_quality='HIGH'):
    sc = bpy.context.scene
    c = sc.cycles
    sc.render.engine = 'CYCLES'
    c.device = 'CPU'
    c.samples = samples
    c.use_adaptive_sampling = True
    c.adaptive_threshold = 0.02
    c.use_denoising = True
    c.denoiser = 'OPENIMAGEDENOISE'
    c.denoising_quality = denoise_quality
    c.max_bounces = 6
    c.diffuse_bounces = 3
    c.glossy_bounces = 2
    c.transmission_bounces = 4
    c.transparent_max_bounces = 8
    c.caustics_reflective = False
    c.caustics_refractive = False
    c.sample_clamp_indirect = 6.0
    sc.cycles_curves.shape = 'RIBBONS'
    sc.render.use_persistent_data = True
    sc.render.use_motion_blur = False
    sc.render.resolution_x, sc.render.resolution_y = res
    sc.render.resolution_percentage = 100
    sc.render.compositor_device = 'CPU'
    sc.render.film_transparent = False
    sc.view_settings.view_transform = 'AgX'
    sc.view_settings.look = 'AgX - Punchy'
    sc.view_settings.exposure = exposure
    sc.render.image_settings.file_format = 'PNG'
    sc.render.image_settings.color_mode = 'RGB'
    sc.render.image_settings.color_depth = '8'
