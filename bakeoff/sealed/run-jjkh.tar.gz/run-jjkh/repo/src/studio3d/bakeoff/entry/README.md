# Where Is Little Hedgehog? (30-second film, built in code)

A hide-and-seek game in a small garden, from the last golden light to a starry night. Seven shots, 720 frames,
pictures drawn by Blender 5.2 (Cycles on the processor) from the Python in this folder, sound made by `sound.mjs`.
Nothing is downloaded and there is no image, model, font or sound file: every shape, colour, movement and note is
arithmetic in these files.

## What is in the folder

| File | What it does |
|---|---|
| `film.py` | The film contract (`build_shot(ctx)`): the seven shots, their cameras, light, acting and timing. |
| `hedgehog.py`, `hh_geom.py` | Little Hedgehog and Mama: shape maths, fur, quills, eyes, the puppet and its poses. |
| `critters.py` | The owl, the snail and the mossy stone. |
| `garden.py` | Ground, grass, bush, stone wall, house with its lit window, far hedges, the old boot, the watering can, the sky (dusk to night with stars), the evening air, fireflies. |
| `kit.py` | Small helpers: meshes, strands, materials, easing, keys, camera, lamps, render settings, the soft glow. |
| `sound.mjs` | The 30 seconds of sound (`node sound.mjs --out FILE`). |
| `lookdev.py` | Test stills of the cast (not part of the film). |
| `design_1`, `design_2`, `design_3` | The three character proposals of the design stage (kept for reference; the film does not import them). |

Test pictures: `film.py --quality preview` halves the samples and the fur and uses a quicker-built acceleration
structure. `--quality final` is the film.

## How it was made

**The team.** Three designers each proposed a Little Hedgehog; two judges (a parent and an art director) chose
design 3 and listed what to change and what to take from the others. One builder made the film from design 3.
Two reviewers (child safety and charm; film craft) then listed ten blockers, and a last pass fixed them: that
pass is described under "What the review changed".

**The hedgehogs.** A puppet of rigid furry pieces (no skinning, no shape keys): body, head, hinged jaw, nose, two
eyeballs, four furry eyelids, ears, two-piece arms with elbows, hind legs, paws, and for Little a cowlick on its own
pivot. All posing maths is in `hedgehog.py`, so a frame never depends on another.
- Eyes: the whole eyeball is dark brown, with a wide round pupil and a narrow dark-brown iris ring around it, so
  no white can show and the eye is a dark wet bead from every side (never a slit in a bright ring). The eyes sit
  deep so the furry lids hug them, and both eyes meet on what they look at.
- Sparkle: nothing in an eye gives off light. The catchlight is the real reflection of a soft lamp beside the lens
  that only eyeballs and noses receive (light linking).
- Lids: a touch warmer and darker than the fur around them, with a dark lash line along their margins and a dark
  lash ridge on the upper lid. An open eye has a fine lash line along its top; a sleeping eye is a dark downward
  arc; a laughing eye is a dark upward arc.
- A hedgehog from the front: thick banded quills (cream root, brown band, pale tip) grow as a hood around a paler
  face and forward over the shoulders; the chest is white.
- Mouth: closed it is a small smile (the mouth line rises to both sides); inside it is one warm pink, with a small
  round tongue; it opens only for giggles. No teeth.
- Paws: four bare toes with pink pads, short fur on the back of the hand, on furry arms that bend at an elbow
  (both ends of every arm piece are furred). A wet nose (Little's is a little smaller than his eyes).
- Poses: the sleeping curl, a tight ball, the scurry, Mama hiding her eyes. Mama is 1.5 times Little, longer
  nose, smaller calmer eyes, darker quills, no cowlick.

**The owl** is a small round ball of feather strands with a pale face, big dark amber-brown eyes under sleepy
feathered lids, a little beak, ear tufts and feet. It stays small in the picture: about 13% of the picture's
height in S5 (the rule is under 15%; a reviewer measured 12.5 to 13%, and after the last pass it measures about
12.6% at frame 492 on a test picture).
**The snail** has a glossy banded spiral shell, a soft wet body and two eye-stalks that bend at two joints.

**The garden** is one layout for the whole film: the house and its tall warm window to the back right, the low
stone wall across, the bush to the left, the old boot to the right with its opening toward the front, the green can
and the stone to its left. Grass is built per shot, only where that shot's camera can see it. The roof has rows of
tiles drawn into its material. Far ground and far hedges fade into the colour of the sky at the horizon with
distance from the lens (a fade written into those two materials, not real fog).

**Light.** Evening: a low golden sun from the left, a peach rim from behind, a cool sky and a soft warm bounce from
the lens side so no face sits in shade. Night: a soft cool moon from the front left, a deep blue sky, the window as
the warm lamp, fireflies with tiny lamps, and one soft warm lamp on the hedgehogs in S6 and S7 (the glow of the
fireflies and the window), so their faces are warm and never grey. In S5 all of these are keyed together in one
continuous shot: the sun fades and reddens, the sky turns, the stars come out one by one (each has its own
moment), the window grows; a soft light that only the owl receives lifts it off the wall.
AgX "Punchy", a light glow on the brightest things. No compositing tricks beyond that glow.

**The shots** follow the brief's table. Fixed frames: Mama's eye peeks from about frame 158 and is clear at 168;
the focus in S4 leaves the snail at 372 and rests on the boot from 396; the owl's eyes are shut from 490 to 494;
the two nose tips are solved to the same point from frame 600 on; nothing in the cast or camera moves from 682
(fireflies and star twinkle go on). S6 is keyed to 630 and S7 from 619 for the shared dissolve.

**Sound.** Crickets and a breath of air, a small lullaby in F on a soft plucked voice over a warm pad (60 beats a
minute, every cut on a half beat), pips for Little's bounces, three plucks while Mama counts and a two-note "peek",
pitter-patter and grass rustles for the scurry, sniffs, a slow low tune for the snail, a shimmer on the focus pull,
twinkles as the stars appear, one soft owl hoot at the blink, a bird-like synthetic giggle and soft thumps from the
boot, a second giggle when Little peeps out laughing, a "boop" when the noses touch, and the lullaby coming home.
No voice, no words.

## What the review changed (the last pass)

1. **Closed eyes** were blank pale discs. Lids now carry a dark lash line and are no paler than the face, so a
   sleeping eye is a dark arc. After the nose touch Little's eyes squeeze shut for a moment in two upward arcs
   and open again.
2. **S6 "Found you"** read as something big creeping up on a small pale face. The lens now stands behind Mama's
   shoulder and well to her side: she comes in from the left with her face in view (eye, lashes, smile), Little
   puts his head out of the boot with wide eyes and an open-mouth laugh, both are lit warm, and at 600 the two
   faces meet nose to nose in profile. The camera pushes in and drifts round from 40 to 63 degrees off the boot.
3. **S2 "Counting"**: Mama's paws are now held on the lines from her eyes to the lens, so both eyes are hidden,
   and her lids are shut under them; only the peeking eye opens (wide) and its paw slides down to her cheek. She
   rocks gently and bounces a little with each count.
4. **Odd parts in the close-up**: the pale knobs at her elbows were the bare ends of the arm pieces; both ends
   are furred now. The paws have short fur on the back of the hand and bare toes.
5. **Little's eyes in S3**: a wide pupil with a narrow dark iris (no slit from the side), lids open wider with
   level corners, a smaller and lower nose, a small head lift in the sniffs (his eyes close for a moment into
   happy arcs in the second one), and no blink on his one look at the lens.
6. **S7 "Goodnight"**: the two now lie curled toward each other, heads together and both faces toward the lens,
   in a warm pool of light. The camera starts close above them, rises and pulls back, and settles with the pair
   large in the lower part of the picture and the wall, the owl, the lit window and the stars above. The can is
   outside this shot's picture.
7. **S1**: tiled roof, evening air on the far ground and hedges (no hard line where the ground met the sky), a
   warmer window, and the owl has left the picture whole before the crane ends.
8. **S5**: a firefly that has not lit yet is no longer drawn (the black specks), and the owl has its own soft
   light, a bigger head turn and a bigger ruffle.

## Decisions taken where the brief left them open

- Sun from the left front, not from behind: the judges wanted readable faces first.
- The boot is rolled a little so its toe points up; lying flat it read as a pipe from low cameras.
- The window is tall with a low sill, so its glow reaches low cameras and the lawn.
- S6: the brief says "over Mama's shoulder". A view straight over her shoulder showed only her dark back closing
  in on Little (the reviewers' second blocker), so the lens stands behind her shoulder line and to her side. At
  the start the boot is alone in the picture; she enters from the left and is seen from a rear three-quarter
  as she walks in; at the touch she is in profile. The boot's pull loop is left off in this shot only (from this
  side it sat exactly at her mouth). A firefly hovers just inside the boot.
- S7 uses a 20 mm lens (the guide is 28 mm; the limit is a third either way). The rise is small (9 cm) and the
  pull-back is 21 cm; most of the move is the tilt up from the pair to the garden. It ends about 13 degrees
  below level, 33 cm above the grass: the pair is seen from above, the garden nearly level. A higher or steeper
  end would lose either the pair's size or the sky and the window. The far hedge row is built at half height in
  this shot so the stars show above the wall. The can and the stone are not built in this shot.
- No subdivision modifiers anywhere: on this machine each one cost about two seconds on the first picture of a shot
  (about forty seconds with two hedgehogs). Shapes are built fine enough instead.
- Final samples per shot: S1 13, S2 12, S3 12 (with motion blur), S4 15, S5 17, S6 14, S7 14; fur share per shot
  between 0.35 and 1.0 of the design's strand count (strands get thicker as they get fewer).

## Speed check

The third and last attempt, run after the last change, did not pass: predicted 20,484 s against the 19,440 s
limit (5.4% over); its pictures are `WS/gate/sheet-3.jpg`. The machine was shared with another job during the
attempt: Blender did 2.7% more work than in the passing second attempt but needed 19% more clock time, and the
shots the last pass hardly touched came out about 20% slower. On a quiet machine the estimate is about 17,000 s
(an estimate, not a measurement; `PROGRESS.md` has the numbers). By the rule, the film is drawn with about 5%
fewer samples than listed above unless it is measured again.

## Known flaws (honest list)

1. The hedgehogs are rigid puppets. Arms are two capsules with an elbow, legs are one capsule, the mouth is a hinge:
   there is no bending skin, no lip shapes, and a reach can look rubbery.
2. A closed eye is still a lid over a round eyeball: close up, the round outline of the socket shows around the
   lash arc (clearest on the sleeping pair at the start of S7).
3. The scurry is a simple six-frame trot: the paws slide a little against the ground (hidden by grass and blur).
4. S6 is not a strict over-the-shoulder shot (see the decisions). In the nose touch the two noses overlap by
   about a millimetre.
5. Fur is drawn with 12 to 15 samples and denoised: it is slightly smeared close up, and the noise pattern is fixed
   to the screen, which can read as a faint veil when the camera moves. Next to the reference it is closer to
   felt than to fine fur.
6. The house, the far hedges and trees are simple shapes; the evening air is a fade with distance, not fog; the
   grass is one kind of short lawn; the boot is plain and can read as a clay pot in S4.
7. The snail's body is smooth and plain (its small smile hardly shows).
8. The owl is small by rule, so its waking, head turn and blink are still modest on a phone.
9. In S7 the window is cut by the top edge of the last picture and the starry sky is a band, not a wide sky.
10. In S2 Little, out of focus behind Mama, shows as a pale face with two dark eye patches.
11. The film has not been watched moving since the last pass: the changes were checked on still pictures only
    (S4 only on the speed-check sheet). The motion strips in `WS/out/t/m1` are older than every change listed
    above.
12. The sound was made and measured (level, peaks, timing against frames) but never listened to: this build has
    no way to hear it. Balance and timbre are untested by ear.

## Scores against the reference (1 to 10, honest)

| Heading | Score | Why |
|---|---|---|
| Characters | 7 | Dark sparkling eyes with lashes, faces in view at every key moment (peek, laugh, nose touch, sleep); still puppets, not skinned bodies. |
| Materials and light | 6.5 | Fur, quills, warm dusk and a blue night with warm faces and real depth of field hold up; below the reference in strand fineness, skin and air. |
| Acting and movement | 6 | Clear single actions with overshoot, blinks, nose twitches, a count-bounce, a laugh; body mechanics are simple and the last pass was not watched moving. |
| Film craft | 7 | Every shot reads at once; the crane, peekaboo, tracking run, focus pull, day-to-night, push-in and the last tableau serve the story. |
| Sound | 5 | Complete and timed to the picture, gentle; unheard, so unproven. |
