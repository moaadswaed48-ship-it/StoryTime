"""Design proposal 2: draws the stills of Little Hedgehog in the evening garden patch.

Run through the wrapper only (REPO is the team's copy of the project, WS the workspace):

    bash REPO/studio/scripts/bakeoff/blender.sh d2 --sub design_2 --sub-cap 720 -- \
        --python REPO/src/studio3d/bakeoff/entry/design_2/stills.py -- --out WS/out/design_2 --views a,b,c

--views  a medium shot, b close-up of the face, c curled up and peeking, d sniffing the air (a fourth still)
--res 1280x720  --samples 32  --exposure 0.5  --bloom 1  --cheap 0 (1 = the cheaper fur shader)  --mama 0 (1 = Mama)
"""
import argparse
import math
import os
import sys
import time

import bpy
from mathutils import Vector

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)
import garden  # noqa: E402
import hedgehog  # noqa: E402

SUN_AZ, SUN_EL = 64.0, 8.0

VIEWS = {
    'a': dict(file='a_medium', target='body', off=(-0.030, 0.0, 0.004), az=12.0, el=2.5, dist=0.72, lens=70.0, fstop=5.6,
              pose=dict(hedgehog.STAND, yaw=-32.0, head_yaw=22.0, head_roll=5.0, gaze_yaw=8.0)),
    'b': dict(file='b_closeup', target='head', off=(0.002, 0.0, 0.008), az=4.0, el=-1.0, dist=0.47, lens=90.0, fstop=13.0,
              pose=dict(hedgehog.STAND, yaw=-32.0, head_yaw=18.0, head_roll=7.0, head_pitch=-6.0, gaze_yaw=8.0,
                        gaze_pitch=4.0, lid_upper=46.0, ear=10.0)),
    'c': dict(file='c_curl', target='body', off=(0.0, 0.0, 0.0), az=8.0, el=10.0, dist=0.62, lens=70.0, fstop=6.3, thick=True,
              pose=dict(hedgehog.CURL, yaw=8.0)),
    'd': dict(file='d_sniff', target='body', off=(-0.030, 0.0, 0.014), az=14.0, el=3.0, dist=0.72, lens=70.0, fstop=5.6,
              pose=dict(hedgehog.SNIFF, yaw=-48.0, head_yaw=8.0)),
}


def direction(az, el):
    """Unit vector from the subject toward a lens at azimuth az (0 = straight in front, + = toward +X), elevation el."""
    a, e = math.radians(az), math.radians(el)
    return Vector((math.sin(a) * math.cos(e), -math.cos(a) * math.cos(e), math.sin(e)))


def main():
    argv = sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else []
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', required=True)
    ap.add_argument('--views', default='a,b,c')
    ap.add_argument('--res', default='1280x720')
    ap.add_argument('--samples', type=int, default=32)
    ap.add_argument('--exposure', type=float, default=0.5)
    ap.add_argument('--bloom', type=int, default=1)
    ap.add_argument('--cheap', type=int, default=0)
    ap.add_argument('--fill', type=float, default=2.4)
    ap.add_argument('--eye', type=float, default=2.5)
    ap.add_argument('--grass', type=int, default=1)
    ap.add_argument('--mama', type=int, default=0)
    a = ap.parse_args(argv)
    w, h = (int(v) for v in a.res.lower().split('x'))
    os.makedirs(a.out, exist_ok=True)

    t0 = time.time()
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = garden.render_settings((w, h), a.samples, a.exposure)
    sun, sdir = garden.build_evening_light(SUN_AZ, SUN_EL)
    garden.build_patch(sdir, grass=bool(a.grass))
    t1 = time.time()
    rig = hedgehog.build_hedgehog(hedgehog.MAMA if a.mama else None, cheap_fur=bool(a.cheap))
    k = rig.spec['scale']                      # lens distances grow with the character
    fill = garden.add_fill(a.fill)
    eye = garden.add_eye_light(rig.glints, a.eye)
    if a.bloom:
        print('BLOOM %s' % garden.add_bloom(), flush=True)
    print('BUILD patch %.1f s, hedgehog %.1f s, strands %s' % (t1 - t0, time.time() - t1, rig.counts), flush=True)

    for key in [v.strip() for v in a.views.split(',') if v.strip()]:
        v = VIEWS[key]
        rig.root.location.z = 0.0
        hedgehog.pose(rig, **v['pose'])
        hedgehog.settle(rig)
        base = rig.body if v['target'] == 'body' else rig.focus
        tgt = base.matrix_world.translation + Vector(v['off']) * k
        head = rig.focus.matrix_world.translation.copy()
        pos = tgt + direction(v['az'], v['el']) * v['dist'] * k
        pos.z = max(pos.z, 0.025)
        cam = garden.add_camera('Cam.' + key, pos, tgt, v['lens'], v['fstop'], rig.focus)
        sc.camera = cam
        sc.cycles_curves.shape = 'THICK' if v.get('thick') else 'RIBBONS'   # round quills where they point at the lens
        garden.aim(fill, tgt + direction(v['az'] - 62.0, 16.0) * 1.15, tgt)
        garden.aim(eye, head + direction(v['az'] - 24.0, 26.0) * 0.60 * k, head)
        ts = time.time()
        sc.render.filepath = os.path.join(a.out, v['file'] + ('_mama' if a.mama else '') + '.png')
        bpy.ops.render.render(write_still=True)
        print('STILL %s %.1f s' % (v['file'], time.time() - ts), flush=True)
    print('DONE %.1f s' % (time.time() - t0), flush=True)


if __name__ == '__main__':
    main()
